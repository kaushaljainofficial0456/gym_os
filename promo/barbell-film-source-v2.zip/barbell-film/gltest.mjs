import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b = await chromium.launch({ args: ['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const p = await b.newPage();
await p.setContent('<canvas id=c width=200 height=200></canvas>');
const r = await p.evaluate(() => { const gl = document.getElementById('c').getContext('webgl2'); if(!gl) return 'no webgl2'; const d=gl.getExtension('WEBGL_debug_renderer_info'); return gl.getParameter(d?d.UNMASKED_RENDERER_WEBGL:gl.RENDERER) + ' / maxtex ' + gl.getParameter(gl.MAX_TEXTURE_SIZE); });
console.log(r, b.version());
await b.close();
