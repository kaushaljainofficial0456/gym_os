# Barbell — pitch film (source)

A 64-second, 1080p60 launch/pitch film for Barbell. Every frame is a pure
function of time (the Remotion approach): React scenes + three.js for the 3D
pieces, captured frame-by-frame in headless Chromium, with an original score
and sound design synthesised in Python.

## Structure
- `src/Video.jsx` — the timeline (which scene plays when)
- `src/scenes/*` — one file per scene (Hook, Guessing, Questions, Blindspot,
  Chaos, Reveal, Member, Coach, Owner, Montage, Tagline)
- `src/lib/objects.js` — 3D: extruded font text, the Barbell badge (ring + bar
  + real plates), the BARBELL wordmark from the app's own Cinzel outlines
- `audio/make_audio.py` — the score (120 BPM, F minor → Ab major) + all SFX,
  cue times match the scenes. Writes `score.wav`, `music.wav`, `sfx.wav`
- `render.mjs` — renderer (stills for review, or full video)
- `finish.sh` — grain + audio mux + loudness (-14 LUFS)

## Re-render
Needs Node 20+, Playwright's Chromium, ffmpeg, Python 3 with numpy + scipy.
```
node build.mjs                                   # bundle scenes
node render.mjs stills 9.5,31.6 --scale 0.5      # check a few frames
python3 audio/make_audio.py                      # rebuild the soundtrack
node render.mjs video --fps 60 --out out/video_60.mp4
bash finish.sh
```
Edit copy in the scene files (e.g. `COPY` in `scenes/Member.jsx`), colours
in `src/lib/ui.jsx` (`C`, `GRAD`), timing in `src/Video.jsx`. If you move a
scene, move its cues in `audio/make_audio.py` by the same amount.

The renderer needs `--disable-gpu-compositing` (already set) for speed in
headless mode; on a machine with a GPU you can drop the SwiftShader flags.
