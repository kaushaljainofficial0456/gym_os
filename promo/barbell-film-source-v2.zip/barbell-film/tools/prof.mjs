import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const ROOT = path.resolve('public');
const srv = http.createServer((q, r) => { fs.readFile(path.join(ROOT, q.url.split('?')[0]), (e, d) => { if (e) { r.writeHead(404); r.end(); return; } r.writeHead(200, { 'content-type': q.url.endsWith('.js') ? 'text/javascript' : q.url.endsWith('.woff2') ? 'font/woff2' : 'text/html' }); r.end(d); }); }).listen(0);
await new Promise(r => setTimeout(r, 100));
const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', ...(process.env.FLAGS ? process.env.FLAGS.split(' ') : [])] });
const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
await p.goto(`http://127.0.0.1:${srv.address().port}/index.html?fps=30`);
await p.evaluate(() => window.__ready); if (process.env.NOGRAIN) await p.evaluate(() => { window.__noGrain = true; });
for (const [a, z] of [[960, 975], [750, 765], [8 * 30, 8 * 30 + 15], [1560, 1575]]) {
  let ts = 0, tc = 0, tj = 0, tp = 0;
  for (let f = a; f < z; f++) {
    let t0 = Date.now(); await p.evaluate((fr) => window.__seek(fr), f); ts += Date.now() - t0;
    t0 = Date.now(); await p.screenshot({ type: 'jpeg', quality: 93 }); tj += Date.now() - t0;
  }
  console.log(`frames ${a}-${z}: seek ${(ts / 15).toFixed(0)}ms, jpeg ${(tj / 15).toFixed(0)}ms`);
}
await b.close(); srv.close();
