# Extract glyph outlines (y-up font units) as SVG path data for 3D extrusion.
import json, sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen

def text_paths(font_path, text, tracking=0):
    f = TTFont(font_path)
    gs = f.getGlyphSet(); cmap = f.getBestCmap(); hmtx = f['hmtx']
    upm = f['head'].unitsPerEm
    cap = getattr(f['OS/2'], 'sCapHeight', int(upm * 0.7))
    x = 0; out = []
    kern = None
    for ch in text:
        gn = cmap.get(ord(ch))
        if gn is None: continue
        pen = SVGPathPen(gs)
        gs[gn].draw(pen)
        adv = hmtx[gn][0]
        out.append({'ch': ch, 'x': x, 'adv': adv, 'd': pen.getCommands()})
        x += adv + tracking * upm
    return {'upm': upm, 'cap': cap, 'width': x - tracking * upm, 'glyphs': out}

if __name__ == '__main__':
    spec = json.loads(sys.argv[1])
    res = {}
    for key, (font, text, tracking) in spec.items():
        res[key] = text_paths(font, text, tracking)
    print('export const GLYPHS = ' + json.dumps(res) + ';')
