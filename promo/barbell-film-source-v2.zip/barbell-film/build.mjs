import * as esbuild from '/opt/npm-tools/node_modules/esbuild/lib/main.js';
import path from 'node:path';

await esbuild.build({
  entryPoints: ['src/main.jsx'],
  bundle: true,
  outfile: 'public/bundle.js',
  jsx: 'automatic',
  loader: { '.js': 'jsx' },
  nodePaths: ['/opt/npm-tools/node_modules'],
  alias: { three: path.resolve('src/lib/three/three.module.js') },
  define: { 'process.env.NODE_ENV': '"production"' },
  minify: false,
  sourcemap: false,
  target: 'chrome120',
  logLevel: 'warning',
});
console.log('built');
