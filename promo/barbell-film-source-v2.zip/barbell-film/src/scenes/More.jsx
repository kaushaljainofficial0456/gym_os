import React from 'react';
import { useT, prog, Ease, clamp, spring, SPR } from '../lib/anim.js';
import { Abs, C, F, DarkBg, heavy, outline, Flash } from '../lib/ui.jsx';

const WORDS = ['Streaks.', 'Water.', 'Sleep.', 'Reports.'];

/** four beats, one giant word each — the "and there's more" burst */
export function More() {
  const t = useT();
  const beat = Math.min(3, Math.floor(t / 0.5));
  const bt = t - beat * 0.5;
  const s = spring(bt + 0.03, SPR.pop);
  const out = prog(t, 1.85, 2.0, Ease.in);
  const voltBeat = beat % 2 === 1;
  return (
    <Abs>
      {voltBeat ? <Abs style={{ background: C.volt }} /> : <DarkBg seed={50 + beat} />}
      <Abs style={{ top: 120 }}>
        <div style={{ textAlign: 'center', font: `900 30px ${F.display}`, letterSpacing: '0.4em', color: voltBeat ? C.black : C.volt, textTransform: 'uppercase' }}>+ More inside</div>
      </Abs>
      <Abs style={{ display: 'grid', placeItems: 'center', opacity: 1 - out }}>
        <div style={{ position: 'relative', transform: `scale(${1.3 - 0.3 * s}) skewX(${(1 - s) * -10}deg)`, opacity: clamp(s * 3) }}>
          <div style={{ position: 'absolute', left: 0, top: 0, ...heavy(330), fontStyle: 'italic', ...outline(3, voltBeat ? 'rgba(0,0,0,.25)' : 'rgba(200,255,46,.35)'), transform: 'translate(18px, 18px)' }}>{WORDS[beat]}</div>
          <div style={{ position: 'relative', ...heavy(330), fontStyle: 'italic', color: voltBeat ? C.black : C.ink }}>{WORDS[beat]}</div>
        </div>
      </Abs>
      <Abs style={{ top: 930 }}>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 16 }}>
          {WORDS.map((_, i) => <span key={i} style={{ width: i === beat ? 60 : 16, height: 16, borderRadius: 4, background: i <= beat ? (voltBeat ? C.black : C.volt) : 'rgba(128,128,128,.4)' }} />)}
        </div>
      </Abs>
    </Abs>
  );
}
