import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble, fmt, rng } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Dust, gradText, GRAD, MicroLabel } from '../lib/ui.jsx';

const SW = 416, SH = 896;
const ui = (w, s, c = C.ink) => ({ font: `${w} ${s}px ${F.ui}`, color: c });

/* ── phone shell ─────────────────────────────────────────────── */
export function Phone({ x, y, rx, ry, rz = 0, s = 1, children, glare = 0 }) {
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: 440, height: 920, transform: `translate(-50%,-50%) perspective(2200px) rotateY(${ry}deg) rotateX(${rx}deg) rotateZ(${rz}deg) scale(${s})` }}>
      <div style={{ position: 'absolute', left: 30, right: 30, bottom: -60, height: 80, borderRadius: '50%', background: 'rgba(0,0,0,.65)', filter: 'blur(30px)' }} />
      <div style={{
        position: 'absolute', inset: 0, borderRadius: 72, padding: 12,
        background: 'linear-gradient(150deg, #4a3c3f 0%, #1b1416 30%, #120d0f 70%, #3b2f31 100%)',
        boxShadow: '0 60px 120px -30px rgba(0,0,0,.95), 0 0 0 1.5px rgba(255,234,229,.16) inset, 22px 0 0 -6px #241b1d, 26px 6px 40px -10px rgba(255,90,60,.25)',
      }}>
        <div style={{ position: 'relative', width: SW, height: SH, borderRadius: 60, overflow: 'hidden', background: C.bg }}>
          {children}
          <div style={{ position: 'absolute', top: 14, left: '50%', width: 124, height: 36, marginLeft: -62, borderRadius: 40, background: '#000' }} />
          <div style={{ position: 'absolute', inset: 0, background: `linear-gradient(115deg, rgba(255,255,255,${0.09 + glare}) 0%, rgba(255,255,255,0) 38%)`, pointerEvents: 'none' }} />
        </div>
      </div>
    </div>
  );
}

function StatusBar() {
  return (
    <div style={{ position: 'absolute', top: 18, left: 34, right: 30, display: 'flex', justifyContent: 'space-between', ...ui(600, 19) }}>
      <span>9:41</span>
      <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        {[8, 11, 14, 17].map((h, i) => <span key={i} style={{ width: 4, height: h, borderRadius: 2, background: C.ink, display: 'inline-block' }} />)}
        <span style={{ width: 28, height: 13, border: `2px solid ${C.ink}`, borderRadius: 4, marginLeft: 6, padding: 1 }}><span style={{ display: 'block', width: '80%', height: '100%', background: C.ink, borderRadius: 1 }} /></span>
      </span>
    </div>
  );
}

function GradRing({ size, stroke, pct, id, children }) {
  const r = (size - stroke) / 2;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#FFA24A" /><stop offset=".5" stopColor="#FF5A3C" /><stop offset="1" stopColor="#FF2E63" /></linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,234,229,.08)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`url(#${id})`} strokeWidth={stroke} strokeLinecap="round" pathLength={1}
          strokeDasharray={`${pct} 1`} transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ filter: 'drop-shadow(0 0 10px rgba(255,80,60,.55))' }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}>{children}</div>
    </div>
  );
}

const Chip = ({ children, c = '#B8F0C8', bg = 'rgba(159,216,176,.12)' }) => (
  <span style={{ font: `700 13px ${F.ui}`, letterSpacing: '0.12em', padding: '5px 9px', borderRadius: 99, color: c, background: bg, textTransform: 'uppercase' }}>{children}</span>
);

/* ── screen A: food, typed like a message ─────────────────────── */
const TYPED = '2 rotis + 150g rice + dal';
const FOODS = [
  { n: 'Roti', q: '× 2', k: 240 }, { n: 'Rice, cooked', q: '150 g', k: 195 }, { n: 'Dal', q: '1 bowl', k: 180 },
];
function FoodScreen({ lt }) {
  const chars = Math.floor(clamp((lt - 0.7) / 1.25) * TYPED.length);
  const sent = lt > 2.05;
  const kcal = interp(lt, [2.35, 3.25], [1225, 1840], Ease.out);
  const caret = !sent && Math.floor(lt * 2.4) % 2 === 0;
  const press = spring(lt - 2.0, SPR.pop);
  return (
    <Abs>
      <StatusBar />
      <div style={{ position: 'absolute', top: 74, left: 30, right: 30 }}>
        <div style={{ ...ui(600, 15, C.faint), letterSpacing: '0.2em' }}>TODAY · LUNCH</div>
        <div style={{ font: `400 40px ${F.serif}`, color: C.ink, marginTop: 4 }}>Fuel</div>
      </div>
      <div style={{ position: 'absolute', top: 150, left: 0, right: 0, display: 'grid', placeItems: 'center' }}>
        <GradRing size={260} stroke={22} pct={kcal / 2200} id="fuelg">
          <div style={{ textAlign: 'center' }}>
            <div style={{ font: `800 58px ${F.display}`, color: C.ink, letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>{fmt(Math.round(kcal))}</div>
            <div style={{ ...ui(500, 18, C.mute) }}>of 2,200 kcal</div>
          </div>
        </GradRing>
      </div>
      <div style={{ position: 'absolute', top: 432, left: 30, right: 30, display: 'flex', gap: 14 }}>
        {[{ l: 'Protein', v: [62, 81], m: 140, c: '#9B93E0' }, { l: 'Carbs', v: [140, 236], m: 280, c: '#FFA24A' }, { l: 'Fat', v: [38, 47], m: 70, c: '#DE9AAE' }].map((m, i) => {
          const v = interp(lt, [2.35, 3.25], m.v, Ease.out);
          return (
            <div key={i} style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', ...ui(500, 15, C.mute) }}><span>{m.l}</span><span style={{ color: C.ink }}>{Math.round(v)}g</span></div>
              <div style={{ height: 7, borderRadius: 9, background: 'rgba(255,234,229,.08)', marginTop: 7 }}><div style={{ height: '100%', width: `${(v / m.m) * 100}%`, borderRadius: 9, background: m.c }} /></div>
            </div>
          );
        })}
      </div>
      {/* the message-style input */}
      <div style={{ position: 'absolute', top: 506, left: 22, right: 22, height: 70, borderRadius: 26, background: 'rgba(255,234,229,.06)', border: `1.5px solid ${lt > 0.6 && !sent ? 'rgba(255,110,80,.55)' : 'rgba(255,234,229,.12)'}`, display: 'flex', alignItems: 'center', padding: '0 12px 0 22px' }}>
        <div style={{ flex: 1, ...ui(500, 22, chars ? C.ink : C.faint), whiteSpace: 'nowrap', overflow: 'hidden' }}>
          {sent ? <span style={{ color: C.faint }}>Log food — just type it</span> : chars ? TYPED.slice(0, chars) : 'Log food — just type it'}
          {caret && <span style={{ display: 'inline-block', width: 2, height: 24, background: C.coral, marginLeft: 2, verticalAlign: 'middle' }} />}
        </div>
        <div style={{ width: 48, height: 48, borderRadius: 99, background: GRAD, display: 'grid', placeItems: 'center', transform: `scale(${1 - 0.15 * Math.sin(Math.PI * clamp(press))})`, boxShadow: '0 6px 20px -4px rgba(255,70,60,.7)' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" /></svg>
        </div>
      </div>
      {/* parsed result */}
      <div style={{ position: 'absolute', top: 596, left: 22, right: 22 }}>
        {sent && (
          <div style={{ ...ui(600, 14, C.faint), letterSpacing: '0.18em', marginBottom: 10, opacity: prog(lt, 2.05, 2.3) }}>
            UNDERSTOOD · 3 FOODS
          </div>
        )}
        {FOODS.map((f, i) => {
          const s = spring(lt - 2.15 - i * 0.14, SPR.pop);
          if (s <= 0.001) return null;
          return (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, height: 66, padding: '0 16px', marginBottom: 10, borderRadius: 18, background: 'rgba(255,234,229,.05)', border: '1px solid rgba(255,234,229,.09)', transform: `translateY(${(1 - s) * 30}px) scale(${0.9 + 0.1 * s})`, opacity: clamp(s * 2) }}>
              <div style={{ width: 10, height: 10, borderRadius: 9, background: GRAD }} />
              <div style={{ flex: 1 }}>
                <div style={{ ...ui(600, 19) }}>{f.n} <span style={{ color: C.mute, fontWeight: 500 }}>{f.q}</span></div>
                <div style={{ marginTop: 4 }}><Chip>Verified</Chip></div>
              </div>
              <div style={{ font: `700 22px ${F.ui}`, color: C.ink, fontVariantNumeric: 'tabular-nums' }}>{f.k}<span style={{ ...ui(500, 14, C.mute), marginLeft: 4 }}>kcal</span></div>
            </div>
          );
        })}
      </div>
    </Abs>
  );
}

/* ── screen B: the set that becomes a PR ───────────────────────── */
const SETS = [
  { n: 1, prev: '120 × 5', kg: 125, r: 5, at: -1 }, { n: 2, prev: '130 × 5', kg: 135, r: 5, at: -1 }, { n: 3, prev: '132.5 × 3', kg: 140, r: 3, at: 1.35 },
];
function LiftScreen({ lt }) {
  const pr = spring(lt - 1.55, SPR.bouncy);
  const hist = [118, 122, 125, 128, 130, 132.5, 140];
  return (
    <Abs>
      <StatusBar />
      <div style={{ position: 'absolute', top: 74, left: 30, right: 30 }}>
        <div style={{ ...ui(600, 15, C.faint), letterSpacing: '0.2em' }}>PULL DAY · WEEK 6</div>
        <div style={{ font: `400 44px ${F.serif}`, color: C.ink, marginTop: 4 }}>Deadlift</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          {['Hamstrings', 'Glutes', 'Back'].map((m) => <span key={m} style={{ ...ui(600, 14, '#C9C2FF'), padding: '6px 11px', borderRadius: 99, background: 'rgba(155,147,224,.14)' }}>{m}</span>)}
        </div>
      </div>
      {/* top-set trend */}
      <div style={{ position: 'absolute', top: 222, left: 22, right: 22, height: 150, borderRadius: 22, background: 'rgba(255,234,229,.04)', border: '1px solid rgba(255,234,229,.08)', padding: '14px 18px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', ...ui(500, 15, C.mute) }}><span>Top set · 7 weeks</span><span style={{ color: '#FFB199' }}>↗ trending up</span></div>
        <svg width="336" height="90" viewBox="0 0 336 90" style={{ marginTop: 6 }}>
          <defs><linearGradient id="trend" x1="0" x2="1"><stop offset="0" stopColor="#FFA24A" /><stop offset="1" stopColor="#FF2E63" /></linearGradient></defs>
          <polyline fill="none" stroke="url(#trend)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" pathLength="1" strokeDasharray={`${prog(lt, 0.15, 1.0, Ease.out) * (lt > 1.55 ? 1 : 0.86)} 1`}
            points={hist.map((v, i) => `${8 + i * 53},${82 - ((v - 115) / 27) * 72}`).join(' ')} />
          {lt > 1.55 && <circle cx={8 + 6 * 53} cy={82 - ((140 - 115) / 27) * 72} r={7 * pr} fill="#FF5A3C" />}
        </svg>
      </div>
      {/* sets */}
      <div style={{ position: 'absolute', top: 396, left: 22, right: 22 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '44px 1fr 74px 60px 52px', ...ui(600, 13, C.faint), letterSpacing: '0.16em', padding: '0 12px 10px' }}>
          <span>SET</span><span>PREVIOUS</span><span>KG</span><span>REPS</span><span />
        </div>
        {SETS.map((st, i) => {
          const done = st.at < 0 || lt > st.at;
          const ck = st.at < 0 ? 1 : spring(lt - st.at, SPR.pop);
          const hot = st.at > 0 && lt > st.at;
          return (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '44px 1fr 74px 60px 52px', alignItems: 'center', height: 64, padding: '0 12px', marginBottom: 8, borderRadius: 16, background: hot ? 'rgba(255,90,60,.12)' : 'rgba(255,234,229,.04)', border: `1px solid ${hot ? 'rgba(255,90,60,.4)' : 'rgba(255,234,229,.07)'}` }}>
              <span style={{ ...ui(700, 19, C.mute) }}>{st.n}</span>
              <span style={{ ...ui(500, 17, C.faint) }}>{st.prev}</span>
              <span style={{ ...ui(700, 22) }}>{st.kg}</span>
              <span style={{ ...ui(700, 22) }}>{st.r}</span>
              <span style={{ width: 40, height: 40, borderRadius: 12, display: 'grid', placeItems: 'center', background: done ? (hot ? GRAD : 'rgba(159,216,176,.18)') : 'rgba(255,234,229,.08)', transform: `scale(${done ? 0.8 + 0.2 * ck : 1})` }}>
                {done && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={hot ? '#fff' : '#B8F0C8'} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7" /></svg>}
              </span>
            </div>
          );
        })}
      </div>
      {/* PR banner */}
      {pr > 0.001 && (
        <div style={{ position: 'absolute', left: 22, right: 22, top: 640, height: 150, borderRadius: 24, padding: '18px 22px', background: 'linear-gradient(135deg, #FFB86B, #FF5A3C 55%, #FF2E63)', boxShadow: '0 20px 50px -10px rgba(255,60,70,.6)', transform: `translateY(${(1 - pr) * 60}px) scale(${0.8 + 0.2 * pr})`, opacity: clamp(pr * 2), color: '#fff' }}>
          <div style={{ font: `800 15px ${F.ui}`, letterSpacing: '0.26em' }}>NEW PERSONAL RECORD</div>
          <div style={{ font: `800 56px ${F.display}`, letterSpacing: '-0.03em', marginTop: 4 }}>140 kg</div>
          <div style={{ font: `600 18px ${F.ui}`, opacity: 0.92 }}>+7.5 kg on your best deadlift</div>
        </div>
      )}
    </Abs>
  );
}

/* ── screen C: live crowd ──────────────────────────────────────── */
const CROWD = [0.32, 0.18, 0.14, 0.22, 0.36, 0.48, 0.42, 0.3, 0.24, 0.28, 0.46, 0.74, 0.92, 0.86, 0.6, 0.34];
function CrowdScreen({ lt }) {
  const pulse = (lt * 1.2) % 1;
  return (
    <Abs>
      <StatusBar />
      <div style={{ position: 'absolute', top: 74, left: 30, right: 30 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, ...ui(700, 15, '#B8F0C8'), letterSpacing: '0.22em' }}>
          <span style={{ position: 'relative', width: 12, height: 12 }}>
            <span style={{ position: 'absolute', inset: 0, borderRadius: 9, background: C.live }} />
            <span style={{ position: 'absolute', inset: -10 * pulse, borderRadius: 99, border: `2px solid rgba(159,216,176,${1 - pulse})` }} />
          </span>
          LIVE · GYM NOW
        </div>
        <div style={{ font: `400 30px ${F.serif}`, color: C.mute, marginTop: 8 }}>Ironforge Fitness</div>
      </div>
      <div style={{ position: 'absolute', top: 186, left: 30 }}>
        <div style={{ font: `400 96px ${F.serif}`, color: '#B8F0C8', lineHeight: 1, transform: `translateY(${(1 - spring(lt - 0.2, SPR.snappy)) * 30}px)`, opacity: prog(lt, 0.2, 0.5) }}>Quiet</div>
        <div style={{ ...ui(500, 22, C.mute), marginTop: 12 }}><b style={{ color: C.ink }}>{Math.round(interp(lt, [0.3, 1.1], [0, 14], Ease.out))}%</b> full · 21 people in</div>
      </div>
      <div style={{ position: 'absolute', top: 400, left: 22, right: 22, height: 250, borderRadius: 24, background: 'rgba(255,234,229,.04)', border: '1px solid rgba(255,234,229,.08)', padding: '18px 18px 14px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', ...ui(500, 15, C.mute) }}><span>Today, by hour</span><span>6 AM – 9 PM</span></div>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 160, marginTop: 14 }}>
          {CROWD.map((h, i) => {
            const g = spring(lt - 0.35 - i * 0.04, SPR.snappy);
            const now = i === 2;
            return <div key={i} style={{ flex: 1, height: `${h * 100 * g}%`, borderRadius: 6, background: now ? 'linear-gradient(180deg, #CFF5DA, #7FC897)' : h > 0.7 ? 'rgba(255,90,60,.55)' : 'rgba(255,234,229,.16)', boxShadow: now ? '0 0 16px rgba(159,216,176,.7)' : 'none' }} />;
          })}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', ...ui(500, 13, C.faint), marginTop: 8 }}><span>6</span><span>9</span><span>12</span><span>3</span><span>6</span><span>9</span></div>
      </div>
      <div style={{ position: 'absolute', top: 672, left: 22, right: 22, display: 'flex', gap: 10, opacity: prog(lt, 1.0, 1.4), transform: `translateY(${(1 - prog(lt, 1.0, 1.4)) * 20}px)` }}>
        <div style={{ flex: 1, borderRadius: 20, padding: '16px 18px', background: 'rgba(159,216,176,.10)', border: '1px solid rgba(159,216,176,.22)' }}>
          <div style={{ ...ui(600, 13, '#B8F0C8'), letterSpacing: '0.18em' }}>BEST TIME TODAY</div>
          <div style={{ ...ui(700, 24), marginTop: 6 }}>2 – 4 PM</div>
        </div>
        <div style={{ flex: 1, borderRadius: 20, padding: '16px 18px', background: 'rgba(255,90,60,.10)', border: '1px solid rgba(255,90,60,.25)' }}>
          <div style={{ ...ui(600, 13, '#FFB199'), letterSpacing: '0.18em' }}>PEAK</div>
          <div style={{ ...ui(700, 24), marginTop: 6 }}>6 – 8 PM</div>
        </div>
      </div>
    </Abs>
  );
}

/* ── floating cards that pop out of the phone ─────────────────── */
function Float({ lt, at, x, y, children, z = 140, rot = 0 }) {
  const s = spring(lt - at, SPR.bouncy);
  if (s <= 0.001) return null;
  const f = wobble(lt, at * 10, 0.25) * 10;
  return (
    <div style={{ position: 'absolute', left: x, top: y + f, transform: `translate(-50%,-50%) perspective(1400px) translateZ(${z * s}px) rotateY(${-14 + rot}deg) scale(${0.5 + 0.5 * s})`, opacity: clamp(s * 2) }}>
      <div style={{ whiteSpace: 'nowrap', borderRadius: 26, padding: '20px 26px', background: 'linear-gradient(160deg, rgba(255,234,229,.16), rgba(255,234,229,.05) 60%), rgba(30,20,22,.82)', border: '1px solid rgba(255,234,229,.18)', boxShadow: '0 40px 80px -24px rgba(0,0,0,.9), 0 0 60px -20px rgba(255,80,60,.5)', color: C.ink }}>
        {children}
      </div>
    </div>
  );
}

const COPY = [
  { k: 'For members', l1: [{ w: 'Log' }, { w: 'a' }, { w: 'meal' }], l2: [{ w: 'like' }, { w: "you'd" }, { w: 'text', it: 1 }, { w: 'a', it: 1 }, { w: 'friend.', it: 1 }], sub: 'Type it the way you’d say it. Barbell does the maths.' },
  { k: 'For members', l1: [{ w: 'Every' }, { w: 'set' }, { w: 'logged.' }], l2: [{ w: 'Every' }, { w: 'PR' }, { w: 'proved.', it: 1 }], sub: 'Your history, your trend, your next number.' },
  { k: 'For members', l1: [{ w: 'Know' }, { w: 'if' }, { w: "it's" }, { w: 'packed' }], l2: [{ w: 'before', it: 1 }, { w: 'you' }, { w: 'leave.' }], sub: 'The live gym crowd, hour by hour.' },
];
const itStyle = { fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, ...gradText, paddingRight: '0.08em' };

function Copy({ c, at, out }) {
  const t = useT();
  const sp = (arr) => arr.map((w) => ({ w: w.w, style: w.it ? itStyle : undefined }));
  return (
    <div style={{ position: 'absolute', left: 160, top: 340, width: 960 }}>
      <div style={{ opacity: prog(t, at, at + 0.3) * (1 - prog(t, out, out + 0.3)), display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ width: 12, height: 12, borderRadius: 9, background: GRAD, boxShadow: '0 0 14px rgba(255,80,60,.8)' }} />
        <MicroLabel color="#FFB199">{c.k}</MicroLabel>
      </div>
      <Rise text="" spans={sp(c.l1)} at={at + 0.05} out={out} stagger={0.05} style={{ font: `400 86px ${F.serif}`, color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.1, marginTop: 26 }} />
      <Rise text="" spans={sp(c.l2)} at={at + 0.2} out={out} stagger={0.05} style={{ font: `400 86px ${F.serif}`, color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.1 }} />
      <Rise text={c.sub} at={at + 0.5} out={out} stagger={0.025} style={{ font: `400 30px ${F.ui}`, color: C.mute, marginTop: 34, maxWidth: 700 }} />
    </div>
  );
}

export function Member() {
  const t = useT();
  const enter = spring(t - 0.02, { stiffness: 70, damping: 14, mass: 1 });
  const exit = prog(t, 11.55, 12.0, Ease.in);
  const sw1 = prog(t, 3.95, 4.4, Ease.inOut);
  const sw2 = prog(t, 7.95, 8.4, Ease.inOut);
  const whip = Math.sin(Math.PI * sw1) + Math.sin(Math.PI * sw2);
  const ry = -20 + wobble(t, 4, 0.12) * 4 + (1 - enter) * -40 + whip * 10 + exit * -50;
  const rx = 7 + wobble(t, 7, 0.1) * 2 + (1 - enter) * 20;
  const px = 1330 + (1 - enter) * 500 + exit * 900;
  const py = 545 + wobble(t, 2, 0.2) * 10 + (1 - enter) * 300;
  const screen = (i) => {
    const pos = i === 0 ? -sw1 : i === 1 ? 1 - sw1 - sw2 : 1 - sw2;
    if (pos <= -1 || pos >= 1) return null;
    const lt = i === 0 ? t : i === 1 ? t - 4 : t - 8;
    return (
      <Abs key={i} style={{ transform: `translateX(${pos * 100}%)` }}>
        {i === 0 ? <FoodScreen lt={lt} /> : i === 1 ? <LiftScreen lt={lt} /> : <CrowdScreen lt={lt} />}
      </Abs>
    );
  };
  return (
    <Abs>
      <DarkBg glow={1} seed={12} />
      <Dust seed={13} count={28} />
      <Abs style={{ opacity: 1 - exit * 0.6, filter: exit > 0 ? `blur(${exit * 6}px)` : 'none' }}>
        <Copy c={COPY[0]} at={0.25} out={3.75} />
        {t > 3.9 && <Copy c={COPY[1]} at={4.2} out={7.75} />}
        {t > 7.9 && <Copy c={COPY[2]} at={8.2} out={11.45} />}
      </Abs>
      <Phone x={px} y={py} rx={rx} ry={ry} s={0.98 + whip * -0.03} glare={whip * 0.06}>
        {screen(0)}{screen(1)}{screen(2)}
      </Phone>
      {/* pop-outs */}
      <Abs style={{ opacity: 1 - exit }}>
        {t < 4.1 && (
          <Float lt={t} at={2.6} x={1700} y={300} rot={6}>
            <div style={{ ...ui(700, 15, '#FFB199'), letterSpacing: '0.2em' }}>UNDERSTOOD</div>
            <div style={{ font: `800 46px ${F.display}`, letterSpacing: '-0.03em', marginTop: 4 }}>+615 <span style={{ ...ui(500, 22, C.mute) }}>kcal</span></div>
            <div style={{ ...ui(500, 18, C.mute) }}>3 foods · 0 searching</div>
          </Float>
        )}
        {t > 4 && t < 8.1 && (
          <Float lt={t - 4} at={1.7} x={1710} y={760} rot={8}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ width: 64, height: 64, borderRadius: 99, background: GRAD, display: 'grid', placeItems: 'center', font: `800 22px ${F.display}`, color: '#fff' }}>PR</div>
              <div>
                <div style={{ font: `800 44px ${F.display}`, letterSpacing: '-0.03em' }}>140 kg</div>
                <div style={{ ...ui(600, 18, '#FFB199') }}>+7.5 kg · deadlift</div>
              </div>
            </div>
          </Float>
        )}
        {t > 8 && (
          <Float lt={t - 8} at={1.25} x={1720} y={330} rot={6}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, ...ui(700, 15, '#B8F0C8'), letterSpacing: '0.2em' }}><span style={{ width: 10, height: 10, borderRadius: 9, background: C.live }} />RIGHT NOW</div>
            <div style={{ font: `400 52px ${F.serif}`, color: '#B8F0C8', marginTop: 4 }}>Quiet</div>
            <div style={{ ...ui(500, 18, C.mute) }}>14% full · go now</div>
          </Float>
        )}
      </Abs>
    </Abs>
  );
}
