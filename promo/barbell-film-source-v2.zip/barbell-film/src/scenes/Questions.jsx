import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble, rng, fmt } from '../lib/anim.js';
import { Abs, C, F, Rise, VoltBg, heavy, outline } from '../lib/ui.jsx';

const DK = '#0A0A0A';
const CARDS = [
  { tag: 'The bench', q: ["LAST WEEK'S", 'BENCH?'], a: 'UH… 60? 65?', lo: 50, hi: 75, unit: 'KG' },
  { tag: 'The food', q: ['CALORIES', 'TODAY?'], a: '2,000-ISH?', lo: 1400, hi: 2900, unit: 'KCAL' },
  { tag: 'The gym', q: ['IS IT PACKED', 'RIGHT NOW?'], a: 'NO IDEA.', lo: 5, hi: 98, unit: '% FULL' },
];

function Gauge({ seed, lo, hi, unit, t, enter }) {
  const ang = wobble(t * 1.4, seed, 1.3) * 72 + wobble(t * 5, seed + 9, 2) * 12;
  const r = rng(seed * 1000 + Math.floor(t / 0.09));
  const val = lo + r() * (hi - lo);
  const shown = unit === 'KCAL' ? fmt(Math.round(val / 10) * 10) : Math.round(val);
  const s = spring(enter, SPR.snappy);
  return (
    <div style={{ position: 'absolute', left: 1260, top: 300, width: 560, transform: `translateY(${(1 - s) * 60}px) scale(${0.9 + 0.1 * s})`, opacity: clamp(s * 1.5) }}>
      <svg width="560" height="320" viewBox="0 0 560 320">
        <path d="M 40 290 A 240 240 0 0 1 520 290" fill="none" stroke="rgba(10,10,10,.18)" strokeWidth="26" strokeLinecap="round" />
        {Array.from({ length: 21 }, (_, i) => {
          const a = Math.PI + (i / 20) * Math.PI;
          const r1 = i % 5 === 0 ? 190 : 206;
          return <line key={i} x1={280 + Math.cos(a) * r1} y1={290 + Math.sin(a) * r1} x2={280 + Math.cos(a) * 222} y2={290 + Math.sin(a) * 222} stroke={DK} strokeWidth={i % 5 === 0 ? 6 : 3} strokeLinecap="round" />;
        })}
        <g transform={`rotate(${ang} 280 290)`}><line x1="280" y1="290" x2="280" y2="90" stroke={DK} strokeWidth="12" strokeLinecap="round" /></g>
        <circle cx="280" cy="290" r="26" fill={DK} />
      </svg>
      <div style={{ textAlign: 'center', marginTop: 8, ...heavy(110, { color: DK }), fontVariantNumeric: 'tabular-nums' }}>
        {shown}<span style={{ ...heavy(40, { color: 'rgba(10,10,10,.6)' }), marginLeft: 14, letterSpacing: '0.02em' }}>{unit}</span>
      </div>
    </div>
  );
}

function Card({ c, i, at }) {
  const t = useT();
  const lt = t - at;
  if (lt < -0.1 || lt > 2.3) return null;
  const out = prog(lt, 1.82, 2.15, Ease.in);
  const aS = spring(lt - 0.6, SPR.bouncy);
  return (
    <Abs style={{ transform: `translateY(${-out * 180}px)`, opacity: 1 - out, filter: out > 0 ? `blur(${out * 8}px)` : 'none' }}>
      <div style={{ position: 'absolute', left: 150, top: 190, width: 1100 }}>
        <div style={{ display: 'inline-block', opacity: prog(lt, 0, 0.25), font: `900 24px ${F.display}`, letterSpacing: '0.26em', color: C.volt, background: DK, padding: '10px 18px', borderRadius: 8, textTransform: 'uppercase' }}>{c.tag}</div>
        <div style={{ marginTop: 26 }}>
          {c.q.map((ln, k) => <Rise key={k} text={ln} at={0.04 + k * 0.1} stagger={0.05} dur={0.5} style={{ ...heavy(150, { color: DK }) }} />)}
        </div>
        <div style={{ marginTop: 74, display: 'inline-block', transform: `translateY(${(1 - aS) * 50}px) rotate(${-5 + (1 - aS) * 10}deg) scale(${0.7 + 0.3 * aS})`, opacity: clamp(aS * 2), transformOrigin: '0% 100%' }}>
          <div style={{ ...heavy(140), fontStyle: 'italic', ...outline(4, DK), whiteSpace: 'nowrap' }}>{c.a}</div>
        </div>
      </div>
      <Gauge seed={i * 13 + 5} lo={c.lo} hi={c.hi} unit={c.unit} t={t} enter={lt - 0.12} />
    </Abs>
  );
}

export function Questions() {
  const t = useT();
  const wipe = prog(t, 0, 0.5, Ease.inOut);
  return (
    <Abs style={{ clipPath: `circle(${wipe * 1200}px at 50% 50%)` }}>
      <VoltBg />
      {CARDS.map((c, i) => <Card key={i} c={c} i={i} at={0.5 + i * 2} />)}
    </Abs>
  );
}
