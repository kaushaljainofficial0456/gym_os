import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Dust, gradText, GRAD, MicroLabel, BrandMark2D } from '../lib/ui.jsx';

const ui = (w, s, c = C.ink) => ({ font: `${w} ${s}px ${F.ui}`, color: c });
const itStyle = { fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, ...gradText, paddingRight: '0.08em' };

const CLIENTS = [
  { n: 'Aarav M.', i: 'AM', a: 0.96, last: 'Today', g: ['#FFA24A', '#FF5A3C'] },
  { n: 'Priya K.', i: 'PK', a: 0.88, last: 'Yesterday', g: ['#8B5CF6', '#FF2E63'] },
  { n: 'Neha R.', i: 'NR', a: 0.91, last: 'Today', g: ['#22D3EE', '#8B5CF6'] },
  { n: 'Rahul S.', i: 'RS', a: 0.31, last: '9 days ago', g: ['#FF5A3C', '#FF2E63'], risk: true },
  { n: 'Kabir D.', i: 'KD', a: 0.84, last: '2 days ago', g: ['#7FB894', '#22D3EE'] },
];

function Dashboard({ t }) {
  const flag = prog(t, 1.0, 1.3);
  const toast = spring(t - 1.15, SPR.snappy);
  const cx = interp(t, [1.7, 2.35], [1240, 1088], Ease.inOut), cy = interp(t, [1.7, 2.35], [560, 160], Ease.inOut);
  const click = prog(t, 2.4, 2.75, Ease.out);
  const drawer = spring(t - 2.6, SPR.snappy);
  const typing = t > 3.0 && t < 3.35;
  const reply = spring(t - 3.35, SPR.pop);
  const sent = spring(t - 2.75, SPR.pop);
  return (
    <div style={{ position: 'relative', width: 1500, height: 760, borderRadius: 34, overflow: 'hidden', background: '#0F0B0C', border: '1px solid rgba(255,234,229,.14)', boxShadow: '0 80px 160px -40px rgba(0,0,0,.95), 0 0 120px -40px rgba(255,80,60,.35)' }}>
      {/* sidebar */}
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 250, background: 'rgba(255,234,229,.03)', borderRight: '1px solid rgba(255,234,229,.08)', padding: '30px 26px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><BrandMark2D size={38} color={C.ink} /><span style={{ font: `600 22px ${F.serif}`, letterSpacing: '0.2em', color: C.ink }}>BARBELL</span></div>
        {['Dashboard', 'Clients', 'Programs', 'Messages', 'Reports'].map((n, i) => (
          <div key={n} style={{ marginTop: i === 0 ? 44 : 10, padding: '13px 16px', borderRadius: 14, ...ui(i === 0 ? 600 : 500, 19, i === 0 ? C.ink : C.mute), background: i === 0 ? 'rgba(255,90,60,.14)' : 'transparent', border: i === 0 ? '1px solid rgba(255,90,60,.3)' : '1px solid transparent' }}>{n}</div>
        ))}
      </div>
      {/* main */}
      <div style={{ position: 'absolute', left: 290, top: 34, right: 40 }}>
        <div style={{ ...ui(600, 14, C.faint), letterSpacing: '0.22em' }}>THURSDAY · COACH VIKRAM</div>
        <div style={{ font: `400 38px ${F.serif}`, color: C.ink, marginTop: 4 }}>Good morning, Coach.</div>
        <div style={{ display: 'flex', gap: 16, marginTop: 24 }}>
          {[{ l: 'Clients', v: '18' }, { l: 'Avg adherence', v: '92%' }, { l: 'Sessions today', v: '6' }, { l: 'At risk', v: '1', hot: true }].map((k, i) => (
            <div key={i} style={{ flex: 1, padding: '16px 20px', borderRadius: 18, background: k.hot && flag ? `rgba(255,70,70,${0.08 + 0.08 * flag})` : 'rgba(255,234,229,.04)', border: `1px solid ${k.hot ? `rgba(255,80,80,${0.15 + 0.4 * flag})` : 'rgba(255,234,229,.08)'}` }}>
              <div style={{ ...ui(500, 15, C.mute) }}>{k.l}</div>
              <div style={{ font: `800 40px ${F.display}`, letterSpacing: '-0.02em', color: k.hot ? '#FF8A7A' : C.ink, marginTop: 2 }}>{k.v}</div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 26, display: 'grid', gridTemplateColumns: '1.4fr 2fr 1fr 1fr', ...ui(600, 13, C.faint), letterSpacing: '0.18em', padding: '0 18px 10px' }}>
          <span>CLIENT</span><span>ADHERENCE · 4 WEEKS</span><span>LAST SESSION</span><span>STATUS</span>
        </div>
        {CLIENTS.map((c, i) => {
          const hot = c.risk ? flag : 0;
          const bar = prog(t, 0.3 + i * 0.06, 1.0 + i * 0.06, Ease.out);
          return (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '1.4fr 2fr 1fr 1fr', alignItems: 'center', height: 62, padding: '0 18px', marginBottom: 6, borderRadius: 16, background: hot ? `rgba(255,70,70,${0.12 * hot})` : 'rgba(255,234,229,.025)', border: `1px solid ${hot ? `rgba(255,80,80,${0.45 * hot})` : 'rgba(255,234,229,.05)'}`, boxShadow: hot ? `0 0 40px -10px rgba(255,60,80,${0.6 * hot})` : 'none' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ width: 38, height: 38, borderRadius: 99, background: `linear-gradient(135deg, ${c.g[0]}, ${c.g[1]})`, display: 'grid', placeItems: 'center', ...ui(700, 14, '#fff') }}>{c.i}</span>
                <span style={{ ...ui(600, 19) }}>{c.n}</span>
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 12, paddingRight: 30 }}>
                <span style={{ flex: 1, height: 8, borderRadius: 9, background: 'rgba(255,234,229,.08)' }}>
                  <span style={{ display: 'block', height: '100%', width: `${c.a * bar * 100}%`, borderRadius: 9, background: c.risk ? 'linear-gradient(90deg,#FF2E63,#FF5A3C)' : 'linear-gradient(90deg,#7FB894,#B8F0C8)' }} />
                </span>
                <span style={{ ...ui(600, 17, c.risk ? '#FF8A7A' : C.ink), width: 46 }}>{Math.round(c.a * 100)}%</span>
              </span>
              <span style={{ ...ui(500, 17, c.risk ? '#FF8A7A' : C.mute) }}>{c.last}</span>
              <span><span style={{ ...ui(700, 13, c.risk ? '#FFB3A8' : '#B8F0C8'), letterSpacing: '0.12em', padding: '6px 11px', borderRadius: 99, background: c.risk ? 'rgba(255,60,80,.16)' : 'rgba(159,216,176,.12)' }}>{c.risk ? 'AT RISK' : 'ON TRACK'}</span></span>
            </div>
          );
        })}
      </div>
      {/* alert toast */}
      {toast > 0.001 && (
        <div style={{ position: 'absolute', right: 34, top: 30, width: 470, padding: '20px 22px', borderRadius: 22, background: 'linear-gradient(160deg, rgba(60,20,22,.96), rgba(30,14,16,.96))', border: '1px solid rgba(255,90,70,.45)', boxShadow: '0 30px 60px -20px rgba(0,0,0,.9), 0 0 50px -10px rgba(255,60,70,.55)', transform: `translateY(${(1 - toast) * -40}px) scale(${0.92 + 0.08 * toast})`, opacity: clamp(toast * 2) * (1 - prog(t, 2.6, 2.9)) }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, ...ui(800, 14, '#FF9A8A'), letterSpacing: '0.2em' }}>
            <span style={{ width: 10, height: 10, borderRadius: 9, background: '#FF5A3C', boxShadow: '0 0 12px #FF5A3C' }} />AT-RISK ALERT
          </div>
          <div style={{ ...ui(600, 22), marginTop: 8 }}>Rahul hasn’t trained in 9 days.</div>
          <div style={{ ...ui(400, 17, C.mute), marginTop: 4 }}>Adherence dropped 68% → 31% this month.</div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <span style={{ ...ui(700, 17, '#fff'), padding: '11px 18px', borderRadius: 12, background: GRAD, transform: `scale(${1 - 0.08 * Math.sin(Math.PI * click)})`, display: 'inline-block' }}>Send check-in</span>
            <span style={{ ...ui(600, 17, C.mute), padding: '11px 18px', borderRadius: 12, background: 'rgba(255,234,229,.06)' }}>View profile</span>
          </div>
          {click > 0 && click < 1 && <span style={{ position: 'absolute', left: 100 - 60 * click, top: 140 - 60 * click, width: 120 * click, height: 120 * click, borderRadius: 99, border: `2px solid rgba(255,255,255,${0.7 * (1 - click)})` }} />}
        </div>
      )}
      {/* message drawer */}
      {drawer > 0.001 && (
        <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: 520, background: 'rgba(22,15,16,.97)', borderLeft: '1px solid rgba(255,234,229,.12)', transform: `translateX(${(1 - drawer) * 540}px)`, padding: '30px 28px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <span style={{ width: 50, height: 50, borderRadius: 99, background: 'linear-gradient(135deg,#FF5A3C,#FF2E63)', display: 'grid', placeItems: 'center', ...ui(700, 18, '#fff') }}>RS</span>
            <div><div style={{ ...ui(600, 22) }}>Rahul S.</div><div style={{ ...ui(500, 15, C.faint) }}>Member · Ironforge Fitness</div></div>
          </div>
          <div style={{ marginTop: 40, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {sent > 0.001 && <div style={{ alignSelf: 'flex-end', maxWidth: 380, padding: '16px 20px', borderRadius: '22px 22px 6px 22px', background: GRAD, ...ui(500, 21, '#fff'), transform: `translateY(${(1 - sent) * 20}px) scale(${0.9 + 0.1 * sent})`, opacity: clamp(sent * 2), transformOrigin: '100% 100%' }}>Missed you this week, Rahul. Same time tomorrow?</div>}
            {typing && <div style={{ alignSelf: 'flex-start', padding: '16px 20px', borderRadius: '22px 22px 22px 6px', background: 'rgba(255,234,229,.08)', display: 'flex', gap: 7 }}>{[0, 1, 2].map((k) => <span key={k} style={{ width: 9, height: 9, borderRadius: 9, background: C.mute, opacity: 0.4 + 0.6 * Math.abs(Math.sin(t * 9 + k)) }} />)}</div>}
            {reply > 0.001 && <div style={{ alignSelf: 'flex-start', padding: '16px 20px', borderRadius: '22px 22px 22px 6px', background: 'rgba(255,234,229,.09)', ...ui(500, 21), transform: `translateY(${(1 - reply) * 20}px) scale(${0.9 + 0.1 * reply})`, opacity: clamp(reply * 2), transformOrigin: '0% 100%' }}>See you at 7. Back on it.</div>}
          </div>
        </div>
      )}
      {/* cursor */}
      {t > 1.6 && t < 2.95 && (
        <svg width="34" height="34" viewBox="0 0 24 24" style={{ position: 'absolute', left: cx, top: cy, filter: 'drop-shadow(0 4px 8px rgba(0,0,0,.6))', transform: `scale(${1 - 0.15 * Math.sin(Math.PI * click)})` }}>
          <path d="M4 2l16 10-7 1.5L9.5 21z" fill="#fff" stroke="#111" strokeWidth="1.2" strokeLinejoin="round" />
        </svg>
      )}
    </div>
  );
}

export function Coach() {
  const t = useT();
  const enter = spring(t - 0.05, { stiffness: 80, damping: 15, mass: 1 });
  const exit = prog(t, 3.72, 4.0, Ease.in);
  const rx = 18 - enter * 6 + wobble(t, 3, 0.1) * 1.5;
  const ry = -6 + wobble(t, 5, 0.1) * 3 + t * 1.2;
  const push = prog(t, 1.0, 1.55, Ease.inOut);
  const pz = 0.9 + push * 0.3, pxo = push * -290, pyo = push * 70;
  return (
    <Abs>
      <DarkBg glow={1} seed={22} hue="platinum" />
      <Dust seed={23} count={24} />
      <Abs style={{ top: 50, opacity: 1 - exit }}>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 14, opacity: prog(t, 0.1, 0.4) }}>
          <span style={{ width: 12, height: 12, borderRadius: 9, background: GRAD }} /><MicroLabel color="#FFB199">For coaches</MicroLabel>
        </div>
        <Rise text="" at={0.15} stagger={0.05} align="center" style={{ font: `400 64px ${F.serif}`, color: C.ink, justifyContent: 'center', marginTop: 14, letterSpacing: '-0.015em' }}
          spans={[{ w: 'See' }, { w: "who's" }, { w: 'slipping' }, { w: '—' }, { w: 'before', style: itStyle }, { w: 'they' }, { w: 'quit.' }]} />
      </Abs>
      <div style={{ position: 'absolute', left: 960, top: 650, transform: `translate(calc(-50% + ${pxo}px), calc(-50% + ${pyo}px)) perspective(2600px) rotateX(${rx - push * 6}deg) rotateY(${ry}deg) translateY(${(1 - enter) * 500 + exit * -200}px) scale(${pz + exit * 0.1})`, opacity: clamp(enter * 1.5) * (1 - exit), filter: exit > 0 ? `blur(${exit * 10}px)` : 'none' }}>
        <Dashboard t={t} />
      </div>
    </Abs>
  );
}
