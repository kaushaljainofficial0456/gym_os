import React, { useMemo } from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, rng, shake } from '../lib/anim.js';
import { Abs, C, F, DarkBg, gradText, Flash, heavy } from '../lib/ui.jsx';

/* the scattered tools people juggle today — rough, generic, deliberately "not one product" */
function Sheet() {
  return (
    <div style={{ width: 300, height: 200, background: '#fff', borderRadius: 14, overflow: 'hidden', boxShadow: '0 30px 60px -20px rgba(0,0,0,.8)' }}>
      <div style={{ height: 30, background: '#1E7F4E', color: '#fff', font: `600 15px ${F.ui}`, padding: '6px 12px' }}>workouts_FINAL_v3.xlsx</div>
      <div style={{ display: 'grid', gridTemplateColumns: '50px 1fr 1fr 1fr', font: `500 13px ${F.ui}`, color: '#333' }}>
        {Array.from({ length: 28 }, (_, i) => <div key={i} style={{ height: 24, borderRight: '1px solid #e3e3e3', borderBottom: '1px solid #e3e3e3', padding: '4px 6px' }}>{i % 4 === 0 ? `${i / 4 + 1}` : i % 4 === 1 ? ['Bench', 'Squat', 'Row', 'OHP', 'DL', '??', ''][Math.floor(i / 4)] : i % 4 === 2 ? ['60', '80?', '50', '', '120', '#REF!', ''][Math.floor(i / 4)] : ''}</div>)}
      </div>
    </div>
  );
}
function Chat() {
  return (
    <div style={{ width: 280, padding: 14, background: '#0E1A15', borderRadius: 18, boxShadow: '0 30px 60px -20px rgba(0,0,0,.8)' }}>
      <div style={{ font: `600 15px ${F.ui}`, color: '#9FE3B8', marginBottom: 10 }}>Gym Bros 💪 (48)</div>
      {['bro is it crowded rn?', 'what was my last bench', 'who has the diet pdf'].map((m, i) => (
        <div key={i} style={{ background: i % 2 ? '#005C4B' : '#1F2C33', color: '#E9EDEF', font: `400 15px ${F.ui}`, padding: '8px 12px', borderRadius: 10, marginBottom: 7, marginLeft: i % 2 ? 40 : 0 }}>{m}</div>
      ))}
    </div>
  );
}
function Note() {
  return (
    <div style={{ width: 230, height: 230, background: '#FFE27A', padding: 18, transform: 'rotate(-3deg)', boxShadow: '0 30px 60px -20px rgba(0,0,0,.7)', font: `500 24px ${F.italic}`, fontStyle: 'italic', color: '#4a3b00', lineHeight: 1.35 }}>
      bench 60?? 65?<br />eat more protein<br />call trainer<br /><s>sleep 8h</s>
    </div>
  );
}
function Calc() {
  return (
    <div style={{ width: 200, height: 260, background: '#222', borderRadius: 22, padding: 14, boxShadow: '0 30px 60px -20px rgba(0,0,0,.8)' }}>
      <div style={{ font: `300 46px ${F.ui}`, color: '#fff', textAlign: 'right', marginBottom: 10 }}>2,140?</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
        {Array.from({ length: 12 }, (_, i) => <div key={i} style={{ height: 36, borderRadius: 99, background: i % 4 === 3 ? '#FF9F0A' : '#3a3a3a' }} />)}
      </div>
    </div>
  );
}
function Cal() {
  return (
    <div style={{ width: 240, background: '#fff', borderRadius: 18, overflow: 'hidden', boxShadow: '0 30px 60px -20px rgba(0,0,0,.8)' }}>
      <div style={{ background: '#E5484D', color: '#fff', font: `700 18px ${F.ui}`, padding: '10px 14px' }}>RENEWALS — ??</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', padding: 10, gap: 6 }}>
        {Array.from({ length: 28 }, (_, i) => <div key={i} style={{ height: 22, borderRadius: 5, background: [3, 9, 17, 22].includes(i) ? '#FFD3D3' : '#f1f1f1' }} />)}
      </div>
    </div>
  );
}
function Pdf() {
  return (
    <div style={{ width: 220, height: 290, background: '#fafafa', borderRadius: 10, padding: 18, boxShadow: '0 30px 60px -20px rgba(0,0,0,.8)' }}>
      <div style={{ font: `800 20px ${F.ui}`, color: '#B42318' }}>PDF</div>
      <div style={{ font: `700 18px ${F.ui}`, color: '#222', margin: '10px 0' }}>diet_plan_2019.pdf</div>
      {Array.from({ length: 8 }, (_, i) => <div key={i} style={{ height: 9, borderRadius: 4, background: '#ddd', marginBottom: 9, width: `${60 + ((i * 37) % 40)}%` }} />)}
    </div>
  );
}

const KINDS = [Sheet, Chat, Note, Calc, Cal, Pdf];
const WORDS = [
  { n: '4', w: 'apps.' }, { n: '3', w: 'spreadsheets.' }, { n: '1', w: 'group chat.' }, { n: '0', w: 'answers.' },
];

export function Chaos() {
  const t = useT();
  const frags = useMemo(() => {
    const r = rng(21);
    return Array.from({ length: 14 }, (_, i) => ({
      K: KINDS[i % KINDS.length], a0: r() * Math.PI * 2, rad: 640 + r() * 320, y: (r() - 0.5) * 760, z: -150 - r() * 450,
      rx: (r() - 0.5) * 60, ry: (r() - 0.5) * 80, spin: (r() - 0.5) * 2, born: Math.floor(i / 3.5) * 0.5 + r() * 0.2, sc: 1.1 + r() * 0.5,
    }));
  }, []);
  const suck = prog(t, 1.72, 2.0, Ease.in);
  const speed = 0.5 + t * t * 0.9;
  const beats = [0, 0.5, 1.0, 1.5];
  const sh = shake(t, beats.map((b) => ({ t: b, s: 0.5 })), 12, 9);
  return (
    <Abs>
      <DarkBg glow={1} hue="platinum" seed={9} />
      <Abs style={{ perspective: 1400, transform: `translate(${sh.x}px, ${sh.y}px)` }}>
        <div style={{ position: 'absolute', left: 960, top: 540, transformStyle: 'preserve-3d' }}>
          {frags.map((f, i) => {
            const b = spring(t - f.born, SPR.pop);
            if (b <= 0.001) return null;
            const ang = f.a0 + t * speed * (0.6 + f.spin * 0.3);
            const rad = f.rad * (1 - suck);
            const x = Math.cos(ang) * rad, z = f.z + Math.sin(ang) * 260;
            const y = f.y * (1 - suck);
            return (
              <div key={i} style={{
                position: 'absolute', left: 0, top: 0,
                transform: `translate3d(${x}px, ${y}px, ${z}px) translate(-50%, -50%) rotateX(${f.rx + t * 90 * f.spin}deg) rotateY(${f.ry + t * 120 * f.spin}deg) scale(${f.sc * b * (1 - suck * 0.9)})`,
                opacity: clamp(b * 2) * (1 - suck),
              }}><f.K /></div>
            );
          })}
        </div>
      </Abs>
      {WORDS.map((w, i) => {
        const at = beats[i];
        const lt = t - at;
        if (lt < 0 || (i < 3 && lt > 0.5)) return null;
        const s = spring(lt, SPR.pop);
        const o = i === 3 ? 1 - suck : 1;
        return (
          <Abs key={i} style={{ display: 'grid', placeItems: 'center', zIndex: 5, background: 'radial-gradient(900px 320px at 50% 50%, rgba(6,6,6,.9), transparent 75%)' }}>
            <div style={{
              display: 'flex', alignItems: 'baseline', gap: 26, transform: `scale(${1.5 - 0.5 * s})`, opacity: clamp(s * 2) * o, filter: s < 0.9 ? `blur(${(1 - s) * 10}px)` : 'none',
              textShadow: '0 20px 60px rgba(0,0,0,.8)',
            }}>
              <span style={{ ...heavy(280), color: C.volt }}>{w.n}</span>
              <span style={{ ...heavy(170), fontStyle: 'italic', paddingRight: '0.08em' }}>{w.w}</span>
            </div>
          </Abs>
        );
      })}
      <Flash at={1.98} dur={0.12} color="#C8FF2E" max={1} />
    </Abs>
  );
}
