import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble, fmt } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Dust, gradText, GRAD, MicroLabel } from '../lib/ui.jsx';

const ui = (w, s, c = C.ink) => ({ font: `${w} ${s}px ${F.ui}`, color: c });
const itStyle = { fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, ...gradText, paddingRight: '0.08em' };
const BARS = [0.12, 0.3, 0.72, 0.9, 0.62, 0.34, 0.26, 0.3, 0.44, 0.78, 0.96, 0.68];

function Card({ t, i, children, w = 330, h = 230, hot }) {
  const s = spring(t - 0.12 - i * 0.08, SPR.snappy);
  return (
    <div style={{
      width: w, height: h, borderRadius: 28, padding: '24px 26px', position: 'relative', overflow: 'hidden',
      background: hot ? 'linear-gradient(140deg, #FF8A4A, #FF4B3E 50%, #FF2E63)' : 'linear-gradient(160deg, rgba(255,234,229,.11), rgba(255,234,229,.03) 60%), rgba(24,16,17,.86)',
      border: hot ? 'none' : '1px solid rgba(255,234,229,.14)',
      boxShadow: hot ? '0 40px 90px -30px rgba(255,60,70,.75)' : '0 40px 80px -30px rgba(0,0,0,.9), inset 0 1px 0 rgba(255,234,229,.12)',
      transform: `translateZ(${(1 - s) * -700 + (hot ? 60 : 0)}px) rotateX(${(1 - s) * 30}deg)`, opacity: clamp(s * 1.6),
    }}>{children}</div>
  );
}

const Label = ({ children, c = C.mute }) => <div style={{ ...ui(600, 15, c), letterSpacing: '0.2em', textTransform: 'uppercase' }}>{children}</div>;

export function Owner() {
  const t = useT();
  const exit = prog(t, 3.65, 4.0, Ease.in);
  const ry = interp(t, [0, 4], [-16, -6], Ease.out) + wobble(t, 4, 0.12) * 2;
  const rx = 10 + wobble(t, 6, 0.1) * 1.5;
  const n = (v, at, d = 1.1) => v * prog(t, at, at + d, Ease.out);
  return (
    <Abs>
      <DarkBg glow={1} seed={31} />
      <Dust seed={32} count={24} />
      <div style={{ position: 'absolute', left: 140, top: 360, width: 640, opacity: 1 - exit }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, opacity: prog(t, 0.1, 0.4) }}>
          <span style={{ width: 12, height: 12, borderRadius: 9, background: GRAD }} /><MicroLabel color="#FFB199">For gym owners</MicroLabel>
        </div>
        <Rise text="" at={0.15} stagger={0.05} style={{ font: `400 84px ${F.serif}`, color: C.ink, marginTop: 24, lineHeight: 1.1, letterSpacing: '-0.02em' }}
          spans={[{ w: 'Run' }, { w: 'the' }, { w: 'whole' }, { w: 'gym' }, { w: 'from' }, { w: 'one', style: itStyle }, { w: 'screen.', style: itStyle }]} />
        <Rise text="Members, renewals, revenue, attendance — live." at={0.55} stagger={0.03} style={{ font: `400 28px ${F.ui}`, color: C.mute, marginTop: 30 }} />
      </div>
      <div style={{ position: 'absolute', left: 1300, top: 545, transform: `translate(-50%,-50%) perspective(2400px) rotateY(${ry}deg) rotateX(${rx}deg) translateX(${exit * 600}px)`, transformStyle: 'preserve-3d', opacity: 1 - exit, filter: exit > 0 ? `blur(${exit * 8}px)` : 'none' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 330px)', gap: 26, transformStyle: 'preserve-3d' }}>
          <Card t={t} i={0}>
            <Label>Active members</Label>
            <div style={{ font: `800 84px ${F.display}`, letterSpacing: '-0.04em', marginTop: 8 }}>{Math.round(n(248, 0.5))}</div>
            <span style={{ ...ui(700, 16, '#B8F0C8'), padding: '6px 12px', borderRadius: 99, background: 'rgba(159,216,176,.14)' }}>+12 this month</span>
          </Card>
          <Card t={t} i={1} hot>
            <Label c="rgba(255,255,255,.85)">Revenue · Oct</Label>
            <div style={{ font: `800 84px ${F.display}`, letterSpacing: '-0.04em', marginTop: 8, color: '#fff' }}>₹{n(4.2, 0.6).toFixed(1)}L</div>
            <svg width="280" height="50" viewBox="0 0 280 50" style={{ position: 'absolute', left: 26, bottom: 18 }}>
              <polyline fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" pathLength="1" strokeDasharray={`${prog(t, 0.7, 1.7)} 1`}
                points={[2.9, 3.1, 3.0, 3.4, 3.3, 3.6, 3.8, 3.7, 4.0, 4.2].map((v, i) => `${i * 31},${46 - ((v - 2.8) / 1.5) * 42}`).join(' ')} />
            </svg>
            <span style={{ position: 'absolute', right: 22, top: 24, ...ui(800, 16, '#fff'), padding: '6px 12px', borderRadius: 99, background: 'rgba(255,255,255,.22)' }}>+9%</span>
          </Card>
          <Card t={t} i={2}>
            <Label>Renewals</Label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginTop: 14 }}>
              <svg width="110" height="110" viewBox="0 0 110 110">
                <circle cx="55" cy="55" r="45" fill="none" stroke="rgba(255,234,229,.10)" strokeWidth="14" />
                <circle cx="55" cy="55" r="45" fill="none" stroke="#FF5A3C" strokeWidth="14" strokeLinecap="round" pathLength="1" strokeDasharray={`${0.86 * prog(t, 0.7, 1.6, Ease.out)} 1`} transform="rotate(-90 55 55)" />
              </svg>
              <div><div style={{ font: `800 52px ${F.display}`, letterSpacing: '-0.03em' }}>{Math.round(n(31, 0.7))}<span style={{ ...ui(500, 22, C.mute) }}> / 36</span></div><div style={{ ...ui(500, 16, C.mute) }}>renewed on time</div></div>
            </div>
          </Card>
          <Card t={t} i={3}>
            <Label>Gym now</Label>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 6 }}><span style={{ font: `400 52px ${F.serif}`, color: '#FFB199' }}>Busy</span><span style={{ ...ui(600, 20, C.mute) }}>68% full</span></div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 70, marginTop: 10 }}>
              {BARS.map((h, k) => <span key={k} style={{ flex: 1, borderRadius: 4, height: `${h * 100 * prog(t, 0.8 + k * 0.03, 1.3 + k * 0.03, Ease.out)}%`, background: k === 10 ? GRAD : 'rgba(255,234,229,.18)' }} />)}
            </div>
          </Card>
          <Card t={t} i={4}>
            <Label>Check-ins today</Label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginTop: 8 }}>
              <div style={{ font: `800 84px ${F.display}`, letterSpacing: '-0.04em' }}>{Math.round(n(186, 0.85))}</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 12px)', gap: 3, padding: 8, borderRadius: 10, background: C.ink }}>
                {Array.from({ length: 25 }, (_, k) => <span key={k} style={{ width: 12, height: 12, background: [0, 1, 3, 5, 7, 9, 12, 13, 16, 18, 19, 21, 24, 4, 20].includes(k) ? '#111' : 'transparent' }} />)}
              </div>
            </div>
            <div style={{ ...ui(500, 16, C.mute) }}>QR at the front desk</div>
          </Card>
          <Card t={t} i={5}>
            <Label>Trainers on shift</Label>
            <div style={{ display: 'flex', marginTop: 20 }}>
              {[['#FFA24A', '#FF5A3C', 'VK'], ['#8B5CF6', '#FF2E63', 'SA'], ['#22D3EE', '#8B5CF6', 'MJ'], ['#7FB894', '#22D3EE', 'RT']].map(([a, b, l], k) => (
                <span key={k} style={{ width: 66, height: 66, marginLeft: k ? -14 : 0, borderRadius: 99, border: '3px solid #1A1213', background: `linear-gradient(135deg, ${a}, ${b})`, display: 'grid', placeItems: 'center', ...ui(700, 20, '#fff'), transform: `scale(${spring(t - 1.0 - k * 0.08, SPR.pop)})` }}>{l}</span>
              ))}
            </div>
            <div style={{ ...ui(500, 16, C.mute), marginTop: 16 }}>4 coaches · 6 sessions booked</div>
          </Card>
        </div>
      </div>
    </Abs>
  );
}
