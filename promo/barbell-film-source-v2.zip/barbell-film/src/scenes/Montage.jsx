import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble } from '../lib/anim.js';
import { Abs, C, F, DarkBg, gradText, GRAD, Flash } from '../lib/ui.jsx';

const ui = (w, s, c = C.ink) => ({ font: `${w} ${s}px ${F.ui}`, color: c });
const WORDS = ['Workouts.', 'Nutrition.', 'Meal photos.', 'Live crowd.', 'Communities.', 'Challenges.', 'Coaching.', 'Billing.'];

/* tiny product chips that orbit the word — each one a piece of the app */
const Tile = ({ children, w = 250 }) => (
  <div style={{ width: w, padding: '16px 18px', borderRadius: 22, background: 'linear-gradient(160deg, rgba(255,234,229,.13), rgba(255,234,229,.04) 60%), rgba(24,16,17,.9)', border: '1px solid rgba(255,234,229,.16)', boxShadow: '0 30px 60px -24px rgba(0,0,0,.9)', color: C.ink, whiteSpace: 'nowrap' }}>{children}</div>
);
const TILES = [
  <Tile key="a"><div style={ui(600, 13, C.faint)}>BENCH PRESS</div><div style={{ font: `800 34px ${F.display}` }}>92.5 kg <span style={ui(700, 15, '#FFB199')}>PR</span></div></Tile>,
  <Tile key="b"><div style={ui(600, 13, C.faint)}>FUEL TODAY</div><div style={{ font: `800 34px ${F.display}` }}>1,840 <span style={ui(500, 15, C.mute)}>kcal</span></div></Tile>,
  <Tile key="c"><div style={ui(600, 13, C.faint)}>MEAL PHOTO</div><div style={{ font: `800 30px ${F.display}` }}>450–550 <span style={ui(500, 15, C.mute)}>kcal est.</span></div></Tile>,
  <Tile key="d"><div style={ui(600, 13, '#B8F0C8')}>● LIVE</div><div style={{ font: `400 34px ${F.serif}`, color: '#B8F0C8' }}>Quiet · 14%</div></Tile>,
  <Tile key="e"><div style={ui(600, 13, C.faint)}>LEADERBOARD</div><div style={{ ...ui(600, 20) }}>1. Priya · 2. You · 3. Aarav</div></Tile>,
  <Tile key="f"><div style={ui(600, 13, C.faint)}>CHALLENGE</div><div style={{ ...ui(600, 22) }}>30-day streak · 12/30</div></Tile>,
  <Tile key="g"><div style={ui(600, 13, C.faint)}>COACH</div><div style={{ ...ui(500, 20) }}>“Add 2.5 kg next week.”</div></Tile>,
  <Tile key="h"><div style={ui(600, 13, C.faint)}>RENEWAL</div><div style={{ ...ui(600, 22) }}>Paid · ₹2,499</div></Tile>,
];

export function Montage() {
  const t = useT();
  const beat = Math.min(7, Math.floor(t / 0.5));
  const bt = t - beat * 0.5;
  const s = spring(bt, SPR.pop);
  const collapse = prog(t, 3.6, 4.0, Ease.in);
  const spin = t * 34 + collapse * 200;
  const pulse = Math.exp(-bt * 6);
  return (
    <Abs>
      <DarkBg glow={0.9 + pulse * 0.4} seed={41 + beat} hue={beat % 2 ? 'platinum' : 'blush'} />
      <Abs style={{ background: `radial-gradient(800px 500px at 50% 50%, rgba(255,90,60,${0.12 * pulse}), transparent 70%)` }} />
      {/* orbiting carousel */}
      <Abs style={{ perspective: 1600 }}>
        <div style={{ position: 'absolute', left: 960, top: 540, transformStyle: 'preserve-3d', transform: `rotateX(-14deg) rotateY(${spin}deg) scale(${1 - collapse})` }}>
          {TILES.map((tile, i) => {
            const a = (i / TILES.length) * 360;
            const appear = spring(t - i * 0.08, SPR.snappy);
            return (
              <div key={i} style={{ position: 'absolute', left: 0, top: 0, transform: `rotateY(${a}deg) translateZ(${760 * appear}px) translate(-50%, ${-50 + ((i % 3) - 1) * 120}%) rotateY(${-a - spin}deg) rotateX(14deg)`, opacity: clamp(appear) }}>
                {tile}
              </div>
            );
          })}
        </div>
      </Abs>
      {/* the word */}
      <Abs style={{ display: 'grid', placeItems: 'center', opacity: 1 - collapse }}>
        <div style={{ transform: `scale(${1.25 - 0.25 * s})`, opacity: clamp(s * 3), filter: s < 0.8 ? `blur(${(1 - s) * 8}px)` : 'none', textShadow: '0 20px 80px rgba(0,0,0,.9)' }}>
          <span style={{ font: `${beat % 2 ? 'italic 600' : '900'} ${beat % 2 ? 170 : 170}px ${beat % 2 ? F.italic : F.display}`, letterSpacing: beat % 2 ? '-0.02em' : '-0.05em', ...(beat % 2 ? gradText : { color: C.ink }), padding: '0 0.1em' }}>{WORDS[beat]}</span>
        </div>
      </Abs>
      <Abs style={{ top: 960, opacity: 0.7 * (1 - collapse) }}>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 14 }}>
          {WORDS.map((_, i) => <span key={i} style={{ width: i === beat ? 34 : 10, height: 10, borderRadius: 9, background: i <= beat ? GRAD : 'rgba(255,234,229,.2)' }} />)}
        </div>
      </Abs>
      <Flash at={3.94} dur={0.14} color="#FF6A4A" max={0.9} />
    </Abs>
  );
}
