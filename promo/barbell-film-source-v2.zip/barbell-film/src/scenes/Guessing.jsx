import React from 'react';
import * as THREE from 'three';
import { useT, interp, prog, Ease, clamp, shake, rng, wobble, spring, SPR } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Flash, heavy } from '../lib/ui.jsx';
import { ThreeStage } from '../lib/ThreeStage.jsx';
import { makeText3D, materials, heroLights } from '../lib/objects.js';

export const IMPACT = 0.7; // local time of the slam

function setup({ scene, camera }) {
  const m = materials();
  const txt = makeText3D('guessing', { height: 1.5, depth: 0.5, bevel: 0.05, material: m.white });
  scene.add(txt.group);
  heroLights(scene, { intensity: 1.0, rimA: 0xc8ff2e, rimB: 0xffffff });
  scene.environmentIntensity = 0.9;
  const r = rng(77);
  const rand = txt.letters.map(() => ({ rx: (r() - 0.5) * 2.4, ry: (r() - 0.5) * 2.4, rz: (r() - 0.5) * 1.2, fx: (r() - 0.5) * 2, fz: r() * 2 + 1, sp: r() }));
  camera.position.set(0, 0.3, 13);
  return { txt, rand };
}

function update({ scene, camera, user }, t) {
  const { txt, rand } = user;
  scene.environmentRotation.y = t * 0.55;
  const camZ = interp(t, [0, IMPACT, 4.6], [13, 13, 11.6], Ease.inOut);
  camera.position.set(Math.sin(t * 0.5) * 0.7, 0.25 + Math.sin(t * 0.33) * 0.15, camZ);
  camera.lookAt(0, 0, 0);
  txt.letters.forEach((L, i) => {
    const R = rand[i];
    const arrive = IMPACT + i * 0.028;
    const p = clamp((t - (arrive - 0.24)) / 0.24);
    const e = p * p * p;
    const d = Math.max(0, t - arrive);
    const bounce = p >= 1 ? Math.exp(-7 * d) * Math.sin(d * 26) : 0;
    let x = L.home.x, y = L.home.y, z = (1 - e) * 11 - bounce * 0.35;
    let rx = R.rx * (1 - e) + bounce * 0.08, ry = R.ry * (1 - e) + wobble(t, i + 3, 0.35) * 0.06, rz = R.rz * (1 - e);
    // idle float
    y += wobble(t, i + 11, 0.3) * 0.035 * clamp(d * 2);
    // fall away
    const fall = t - (3.75 + i * 0.03);
    if (fall > 0) {
      y -= 9.8 * 0.9 * fall * fall;
      x += R.fx * fall * 1.5;
      z += R.fz * fall * 2.0;
      rx += fall * 4 * (R.sp - 0.3);
      rz += fall * 3 * (R.sp - 0.5);
    }
    L.pivot.position.set(x, y, z);
    L.pivot.rotation.set(rx, ry, rz);
    L.pivot.visible = p > 0;
  });
}

export function Guessing() {
  const t = useT();
  const sh = shake(t, [{ t: IMPACT, s: 1.4 }, { t: IMPACT + 0.2, s: 0.4 }], 20, 6);
  const ring = prog(t, IMPACT, IMPACT + 0.9, Ease.out);
  const capOut = prog(t, 3.5, 3.9, Ease.in);
  return (
    <Abs>
      <DarkBg glow={1} />
      {/* shock ring */}
      {ring > 0 && ring < 1 && (
        <Abs style={{ display: 'grid', placeItems: 'center' }}>
          <div style={{
            width: 300 + ring * 2200, height: 300 + ring * 2200, borderRadius: '50%',
            border: `${2 + (1 - ring) * 30}px solid rgba(200,255,46,${0.5 * (1 - ring)})`,
            filter: 'blur(2px)',
          }} />
        </Abs>
      )}
      <Abs style={{ transform: `translate(${sh.x}px, ${sh.y}px) rotate(${sh.r}deg)` }}>
        <ThreeStage setup={setup} update={update} fov={35} exposure={1.05} />
      </Abs>
      <Abs style={{ top: 228, height: 120, opacity: 1 - capOut, transform: `translate(${sh.x * 0.5}px, ${sh.y * 0.5}px)` }}>
        <Rise text="" at={0.05} stagger={0.08} align="center"
          spans={[{ w: 'Honestly?' }, { w: "You're", style: { color: C.ink } }]}
          style={{ ...heavy(64), color: C.mute, justifyContent: 'center' }} />
      </Abs>
      <Abs style={{ top: 760, height: 80, opacity: prog(t, 1.6, 2.2) * (1 - capOut) }}>
        <div style={{ textAlign: 'center', font: `900 26px ${F.display}`, letterSpacing: '0.42em', color: C.volt, textTransform: 'uppercase' }}>
          weights &nbsp;·&nbsp; calories &nbsp;·&nbsp; timing &nbsp;·&nbsp; progress
        </div>
      </Abs>
      <Flash at={IMPACT} dur={0.16} color="#ffffff" max={0.4} />
    </Abs>
  );
}
