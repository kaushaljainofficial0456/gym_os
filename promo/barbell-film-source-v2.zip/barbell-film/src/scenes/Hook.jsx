import React from 'react';
import { useT, Seq, interp, prog, Ease, spring, SPR, clamp, fmt, wobble } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Dust, heavy, outline, voltWord } from '../lib/ui.jsx';

/** giant word with outline echoes behind it (kinetic-poster look) */
function Echo({ children, echo, size, at = 0, color = C.ink, italic = false, rot = 0, echoes = 3 }) {
  const t = useT();
  const s = spring(t - at, SPR.pop);
  const base = { ...heavy(size), fontStyle: italic ? 'italic' : 'normal', whiteSpace: 'nowrap' };
  return (
    <div style={{ position: 'relative', transform: `rotate(${rot}deg) scale(${0.7 + 0.3 * s})`, opacity: clamp(s * 2) }}>
      {Array.from({ length: echoes }, (_, k) => {
        const d = (k + 1) * 0.07;
        const e = spring(t - at - d, SPR.soft);
        return (
          <div key={k} style={{ position: 'absolute', left: 0, top: 0, ...base, ...outline(2, `rgba(255,255,255,${0.32 - k * 0.09})`), transform: `translateY(${(k + 1) * 26 * e}px) scale(${1 + (k + 1) * 0.02 * e})`, opacity: e }}>{echo ?? children}</div>
        );
      })}
      <div style={{ position: 'relative', ...base, color }}>{children}</div>
    </div>
  );
}

function Days() {
  const t = useT();
  return (
    <Abs style={{ display: 'grid', placeItems: 'center' }}>
      <div style={{ textAlign: 'center', transform: `translateY(-20px)` }}>
        <Rise text="You trained" at={0.1} out={1.82} align="center" style={{ ...heavy(64), color: C.mute, justifyContent: 'center' }} />
        <div style={{ marginTop: 18, display: 'flex', justifyContent: 'center', opacity: 1 - prog(t, 1.82, 2.1) }}>
          <Echo size={300} at={0.3} echo="5 DAYS."><span style={{ color: C.volt }}>5</span> DAYS.</Echo>
        </div>
        <div style={{ display: 'flex', gap: 26, justifyContent: 'center', marginTop: 56 }}>
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => {
            const on = i < 5;
            const fill = on ? spring(t - (0.75 + i * 0.25), SPR.pop) : 0;
            const out = prog(t, 1.82 + i * 0.02, 2.05 + i * 0.02, Ease.in);
            return (
              <div key={i} style={{ textAlign: 'center', opacity: prog(t, 0.4 + i * 0.04, 0.7 + i * 0.04) * (1 - out) }}>
                <div style={{ width: 70, height: 70, borderRadius: 16, border: `3px solid ${on ? 'rgba(200,255,46,.5)' : 'rgba(255,255,255,.14)'}`, position: 'relative', overflow: 'hidden' }}>
                  <div style={{ position: 'absolute', inset: 0, background: C.volt, transform: `scale(${fill})`, borderRadius: 10, boxShadow: `0 0 ${30 * fill}px rgba(200,255,46,.7)` }} />
                </div>
                <div style={{ marginTop: 12, font: `900 20px ${F.display}`, letterSpacing: '0.18em', color: on ? C.ink : C.faint }}>{d}</div>
              </div>
            );
          })}
        </div>
      </div>
    </Abs>
  );
}

function Lifted() {
  const t = useT();
  const p = prog(t, 0.3, 1.4, Ease.out);
  const out = prog(t, 1.82, 2.1, Ease.in);
  return (
    <Abs style={{ display: 'grid', placeItems: 'center', opacity: 1 - out, transform: `scale(${1 + out * 0.15})`, filter: out > 0 ? `blur(${out * 10}px)` : 'none' }}>
      <div style={{ textAlign: 'center' }}>
        <Rise text="Lifted" at={0.02} align="center" style={{ ...heavy(64), color: C.mute, justifyContent: 'center' }} />
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 24, marginTop: 10 }}>
          <span style={{ ...heavy(310), fontVariantNumeric: 'tabular-nums', opacity: clamp(t * 5) }}>{fmt(Math.round((12480 * p) / 10) * 10)}</span>
          <span style={{ ...heavy(200), ...outline(4, C.volt), opacity: prog(t, 0.3, 0.6) }}>KG</span>
        </div>
        <div style={{ height: 14, width: 900, margin: '30px auto 0', borderRadius: 4, background: 'rgba(255,255,255,.08)', overflow: 'hidden', transform: 'skewX(-20deg)' }}>
          <div style={{ height: '100%', width: `${p * 100}%`, background: C.volt, boxShadow: '0 0 30px rgba(200,255,46,.8)' }} />
        </div>
      </div>
    </Abs>
  );
}

function Ate() {
  const t = useT();
  const out = prog(t, 1.82, 2.1, Ease.in);
  return (
    <Abs style={{ display: 'grid', placeItems: 'center', opacity: 1 - out, filter: out > 0 ? `blur(${out * 10}px)` : 'none' }}>
      <div style={{ textAlign: 'center' }}>
        <Rise text="Ate…" at={0.02} align="center" style={{ ...heavy(64), color: C.mute, justifyContent: 'center' }} />
        <div style={{ marginTop: 26, display: 'flex', justifyContent: 'center', transform: `rotate(${wobble(t, 4, 0.8) * 2}deg)` }}>
          <Echo size={250} at={0.45} italic rot={-5}>SOMETHING?</Echo>
        </div>
      </div>
    </Abs>
  );
}

function Work() {
  const t = useT();
  const shrink = prog(t, 1.15, 1.5, Ease.in);
  return (
    <Abs style={{ display: 'grid', placeItems: 'center', opacity: 1 - shrink, transform: `scale(${1 - shrink * 0.25})`, filter: shrink > 0 ? `blur(${shrink * 12}px)` : 'none' }}>
      <div style={{ textAlign: 'center' }}>
        <Rise text="But did any of it" at={0.02} stagger={0.05} align="center" style={{ ...heavy(64), color: C.mute, justifyContent: 'center' }} />
        <div style={{ marginTop: 10, display: 'flex', justifyContent: 'center' }}>
          <Echo size={360} at={0.3} italic color={C.volt}>WORK?</Echo>
        </div>
      </div>
    </Abs>
  );
}

export function Hook() {
  const t = useT();
  const zoom = interp(t, [0, 8], [1.0, 1.05], Ease.inOut);
  return (
    <Abs>
      <DarkBg glow={prog(t, 0, 1.2)} />
      <Dust opacity={prog(t, 0, 2)} />
      <Abs style={{ transform: `scale(${zoom})`, opacity: prog(t, 0, 0.35) }}>
        <Seq from={0} dur={2.15}><Days /></Seq>
        <Seq from={2.0} dur={2.15}><Lifted /></Seq>
        <Seq from={4.0} dur={2.15}><Ate /></Seq>
        <Seq from={6.0} dur={2.0}><Work /></Seq>
      </Abs>
    </Abs>
  );
}
