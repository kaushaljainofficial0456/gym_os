import React, { useMemo } from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, rng } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Dust, gradText, GRAD } from '../lib/ui.jsx';

const ROWS = [
  { n: 'Aarav M.', i: 'AM', s: 'Trained today', chip: 'Today', tone: C.live, g: ['#FFA24A', '#FF5A3C'] },
  { n: 'Priya K.', i: 'PK', s: 'Trained yesterday', chip: '1 day', tone: C.live, g: ['#8B5CF6', '#FF2E63'] },
  { n: 'Rahul S.', i: 'RS', s: 'Last workout · 23 days ago', chip: '23 days', tone: '#7d6f6c', g: ['#6b6262', '#3a3333'], lost: true },
];

function Row({ r, k, lt }) {
  const enter = spring(lt - 0.3 - k * 0.12, SPR.snappy);
  const flag = r.lost ? prog(lt, 1.3, 1.6) : 0;
  const dim = !r.lost ? prog(lt, 1.3, 1.7) * 0.55 : 0;
  const dis = r.lost ? prog(lt, 2.35, 3.2, Ease.out) : 0;
  return (
    <div style={{ position: 'relative', height: 132, marginBottom: 22 }}>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', gap: 28, padding: '0 34px', borderRadius: 30,
        background: 'linear-gradient(160deg, rgba(255,234,229,.09), rgba(255,234,229,.025) 60%), rgba(24,16,17,.8)',
        border: `1px solid ${flag > 0 ? `rgba(255,70,80,${0.25 + 0.5 * flag})` : 'rgba(255,234,229,.12)'}`,
        boxShadow: flag > 0 ? `0 0 ${40 * flag}px rgba(255,46,99,${0.35 * flag}), 0 30px 60px -30px rgba(0,0,0,.9)` : '0 30px 60px -30px rgba(0,0,0,.9)',
        transform: `translateY(${(1 - enter) * 60}px) translateX(${dis * 60}px)`, opacity: clamp(enter * 1.4) * (1 - dim) * (1 - dis),
        filter: `${r.lost ? `grayscale(${0.4 + flag * 0.6})` : 'none'} ${dis > 0 ? `blur(${dis * 6}px)` : ''}`,
      }}>
        <div style={{ width: 76, height: 76, borderRadius: 99, background: `linear-gradient(135deg, ${r.g[0]}, ${r.g[1]})`, display: 'grid', placeItems: 'center', font: `700 28px ${F.ui}`, color: '#fff' }}>{r.i}</div>
        <div style={{ flex: 1 }}>
          <div style={{ font: `600 38px ${F.ui}`, color: C.ink }}>{r.n}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 6, font: `400 27px ${F.ui}`, color: C.mute }}>
            <span style={{ width: 11, height: 11, borderRadius: 9, background: r.tone, boxShadow: r.lost ? 'none' : `0 0 12px ${r.tone}` }} />{r.s}
          </div>
        </div>
        <div style={{ font: `700 22px ${F.ui}`, letterSpacing: '0.12em', textTransform: 'uppercase', padding: '12px 20px', borderRadius: 99,
          color: r.lost ? '#FF8A8A' : '#B8F0C8', background: r.lost ? 'rgba(255,60,80,.12)' : 'rgba(159,216,176,.12)', border: `1px solid ${r.lost ? 'rgba(255,60,80,.3)' : 'rgba(159,216,176,.25)'}` }}>{r.chip}</div>
      </div>
      {r.lost && <Shards p={dis} />}
    </div>
  );
}

/** the row breaks into drifting fragments */
function Shards({ p }) {
  const parts = useMemo(() => {
    const r = rng(9);
    return Array.from({ length: 90 }, (_, i) => ({ x: (i % 18) / 18, y: Math.floor(i / 18) / 5, vx: 120 + r() * 420, vy: -60 - r() * 260, rot: (r() - 0.5) * 300, s: 10 + r() * 22, d: r() * 0.35 }));
  }, []);
  if (p <= 0 || p >= 1) return null;
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {parts.map((q, i) => {
        const k = clamp((p - q.d) / (1 - q.d));
        if (k <= 0) return null;
        return <div key={i} style={{
          position: 'absolute', left: `${q.x * 100}%`, top: `${q.y * 100}%`, width: q.s, height: q.s, borderRadius: 4,
          background: i % 3 === 0 ? 'rgba(255,90,60,.7)' : 'rgba(255,234,229,.22)',
          transform: `translate(${q.vx * k}px, ${q.vy * k}px) rotate(${q.rot * k}deg) scale(${1 - k * 0.6})`, opacity: 1 - k,
        }} />;
      })}
    </div>
  );
}

export function Blindspot() {
  const t = useT();
  const cover = prog(t, 0, 0.42, Ease.inOut);
  const out = prog(t, 3.95, 4.4, Ease.in);
  return (
    <Abs style={{ transform: `translateY(${(1 - cover) * 1100}px) skewY(${(1 - cover) * -4}deg)`, transformOrigin: '0 0' }}>
      <DarkBg glow={1} seed={5} />
      <Dust seed={8} />
      <Abs style={{ opacity: 1 - out, filter: out > 0 ? `blur(${out * 10}px)` : 'none' }}>
        <div style={{ position: 'absolute', left: 470, top: 150 }}>
          <Rise text="" at={0.3} stagger={0.07} spans={[{ w: 'Meanwhile,' }, { w: 'your' }, { w: 'coach…', style: { ...gradText, fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, paddingRight: '0.1em' } }]}
            style={{ font: `400 76px ${F.serif}`, color: C.ink }} />
        </div>
        <div style={{ position: 'absolute', left: 470, top: 300, width: 980 }}>
          {ROWS.map((r, k) => <Row key={k} r={r} k={k} lt={t} />)}
        </div>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 812 }}>
          <Rise text="" at={2.2} stagger={0.07} align="center"
            spans={[{ w: '…finds' }, { w: 'out' }, { w: 'you' }, { w: 'quit' }, { w: 'after', style: { ...gradText, fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, paddingRight: '0.08em' } }, { w: 'you' }, { w: 'quit.' }]}
            style={{ font: `400 78px ${F.serif}`, color: C.ink, justifyContent: 'center' }} />
        </div>
      </Abs>
    </Abs>
  );
}
