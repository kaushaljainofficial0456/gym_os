import React from 'react';
import * as THREE from 'three';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble, fmt, shake, rng } from '../lib/anim.js';
import { Abs, C, F, Glass, Feature, heavy, outline, Pill, LiveDot, Ring, voltWord } from '../lib/ui.jsx';
import { ThreeStage } from '../lib/ThreeStage.jsx';
import { heroLights } from '../lib/objects.js';

const ui = (w, s, c = C.ink) => ({ font: `${w} ${s}px ${F.ui}`, color: c });
const label = (c = C.mute) => ({ font: `800 20px ${F.display}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: c });

/** gives a visual some real depth: perspective + slow drift */
function Tilt({ children, ry = -9, rx = 4, x = 1420, y = 540 }) {
  const t = useT();
  const s = spring(t - 0.08, { stiffness: 90, damping: 15, mass: 1 });
  return (
    <div style={{ position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) perspective(2200px) rotateY(${ry + wobble(t, 3, 0.12) * 3 + (1 - s) * -30}deg) rotateX(${rx + wobble(t, 7, 0.1) * 2}deg) translateY(${(1 - s) * 260}px)`, opacity: clamp(s * 1.6) }}>
      {children}
    </div>
  );
}

/* ═════════════ 01 LIVE GYM CROWD ═════════════ */
const HOURS = [0.28, 0.14, 0.18, 0.26, 0.38, 0.5, 0.44, 0.32, 0.26, 0.3, 0.48, 0.76, 0.92, 0.88, 0.62, 0.36];
const HLAB = ['6A', '7', '8', '9', '10', '11', '12P', '1', '2', '3', '4', '5', '6P', '7', '8', '9'];
export function Crowd() {
  const t = useT();
  const lapse = prog(t, 2.5, 3.5, Ease.inOut);       // morning → evening
  const packed = t > 3.5;
  const pk = spring(t - 3.5, SPR.pop);
  const pct = Math.round(interp(lapse, [0, 1], [14, 92]) * prog(t, 0.4, 1.0, Ease.out) || 0);
  const people = Math.round(interp(lapse, [0, 1], [21, 138]));
  const hour = 6 + Math.floor(lapse * 12);
  const clock = `${((hour - 1) % 12) + 1}:40 ${hour < 12 ? 'AM' : 'PM'}`;
  const nowIdx = Math.round(interp(lapse, [0, 1], [1, 12]));
  const sh = shake(t, [{ t: 3.5, s: 0.7 }], 14, 8);
  const note = spring(t - 1.0, SPR.snappy) * (1 - prog(t, 2.3, 2.55));
  const tip = spring(t - 4.25, SPR.pop);
  const meter = interp(lapse, [0, 1], [0.14, 0.92]) * prog(t, 0.4, 1.0, Ease.out);
  const col = packed ? C.hot : C.volt;
  return (
    <Feature idx={1} label="Live gym crowd" dur={6} exitAt={5.75} size={176}
      lines={[[{ w: 'Know' }, { w: 'before' }], [{ w: 'you' }, { w: 'go.', v: 1 }]]}
      sub="See exactly how packed your gym is right now — and the best time to train today.">
      <Tilt ry={-10}>
        <div style={{ transform: `translate(${sh.x}px, ${sh.y}px)` }}>
          <Glass style={{ width: 840, padding: '34px 40px 36px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <LiveDot t={t} color={col} />
                <span style={{ font: `900 26px ${F.display}`, letterSpacing: '0.24em', color: col }}>LIVE</span>
                <span style={{ ...label(), marginLeft: 8 }}>Ironforge Fitness</span>
              </div>
              <span style={{ ...heavy(46), fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.01em', opacity: lapse > 0 && lapse < 1 ? 0.6 + 0.4 * Math.abs(Math.sin(t * 30)) : 1 }}>{clock}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 26 }}>
              <div style={{ ...heavy(150), color: col, fontStyle: 'italic', transform: packed ? `scale(${0.8 + 0.2 * pk})` : 'none', transformOrigin: '0 100%', filter: lapse > 0.05 && lapse < 0.98 ? 'blur(3px)' : 'none' }}>{packed ? 'PACKED' : 'QUIET'}</div>
              <div style={{ textAlign: 'right', paddingBottom: 14 }}>
                <div style={{ ...heavy(96), fontVariantNumeric: 'tabular-nums' }}>{pct}<span style={{ ...heavy(48), color: C.mute }}>%</span></div>
                <div style={{ ...label(), marginTop: 6, whiteSpace: 'nowrap' }}>{people} people in</div>
              </div>
            </div>
            {/* capacity meter */}
            <div style={{ position: 'relative', height: 26, borderRadius: 6, background: 'rgba(255,255,255,.08)', marginTop: 26, overflow: 'hidden', transform: 'skewX(-18deg)' }}>
              <div style={{ position: 'absolute', inset: 0, width: `${meter * 100}%`, background: `linear-gradient(90deg, ${C.volt}, ${meter > 0.6 ? '#FFB020' : C.volt}, ${meter > 0.8 ? C.hot : C.volt})`, boxShadow: `0 0 30px ${col}aa` }} />
              {Array.from({ length: 9 }, (_, k) => <div key={k} style={{ position: 'absolute', top: 0, bottom: 0, left: `${(k + 1) * 10}%`, width: 3, background: 'rgba(6,6,6,.6)' }} />)}
            </div>
            {/* hour by hour */}
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 9, height: 190, marginTop: 30 }}>
              {HOURS.map((h, i) => {
                const g = spring(t - 0.45 - i * 0.035, SPR.snappy);
                const isNow = i === nowIdx;
                const past = i < nowIdx;
                const jitter = isNow ? 1 + Math.sin(t * 9) * 0.04 : 1;
                return (
                  <div key={i} style={{ flex: 1, position: 'relative', height: '100%', display: 'flex', alignItems: 'flex-end' }}>
                    <div style={{
                      width: '100%', height: `${h * 100 * g * jitter}%`, borderRadius: 6,
                      background: isNow ? col : past ? 'rgba(255,255,255,.34)' : 'transparent',
                      border: past || isNow ? 'none' : '2px dashed rgba(255,255,255,.22)',
                      boxShadow: isNow ? `0 0 26px ${col}` : 'none',
                    }} />
                    {isNow && <div style={{ position: 'absolute', top: -34, left: '50%', transform: 'translateX(-50%)', font: `900 16px ${F.display}`, color: C.black, background: col, padding: '3px 7px', borderRadius: 5, letterSpacing: '0.1em' }}>NOW</div>}
                  </div>
                );
              })}
            </div>
            <div style={{ display: 'flex', gap: 9, marginTop: 10 }}>
              {HLAB.map((l, i) => <div key={i} style={{ flex: 1, textAlign: 'center', font: `700 15px ${F.display}`, color: i === nowIdx ? C.ink : C.faint }}>{l}</div>)}
            </div>
            <div style={{ display: 'flex', gap: 14, marginTop: 26, opacity: clamp(tip * 2), transform: `translateY(${(1 - tip) * 24}px)` }}>
              <Pill>Best time today · 2–4 PM</Pill>
              <Pill bg="transparent" color={C.hot} style={{ border: `3px solid ${C.hot}` }}>Peak 6–8 PM</Pill>
            </div>
          </Glass>
        </div>
      </Tilt>
      {/* push notification */}
      {note > 0.001 && (
        <div style={{ position: 'absolute', left: 1240, top: 70, width: 600, transform: `translateY(${(1 - note) * -120}px)`, opacity: clamp(note * 2), borderRadius: 26, padding: '18px 22px', background: 'rgba(28,28,28,.94)', border: '1px solid rgba(255,255,255,.14)', boxShadow: '0 30px 60px -20px rgba(0,0,0,.9)', display: 'flex', gap: 16, alignItems: 'center' }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: C.volt, display: 'grid', placeItems: 'center' }}>
            <svg width="40" height="40" viewBox="0 0 240 240"><circle cx="120" cy="120" r="108" fill="none" stroke="#0A0A0A" strokeWidth="16" /><rect x="48" y="113" width="144" height="14" fill="#0A0A0A" /><rect x="79" y="72" width="16" height="96" rx="3" fill="#0A0A0A" /><rect x="145" y="72" width="16" height="96" rx="3" fill="#0A0A0A" /><rect x="65" y="88" width="13" height="64" rx="3" fill="#0A0A0A" /><rect x="162" y="88" width="13" height="64" rx="3" fill="#0A0A0A" /></svg>
          </div>
          <div>
            <div style={{ ...ui(800, 22) }}>BARBELL · now</div>
            <div style={{ ...ui(500, 22, C.mute), marginTop: 2 }}>Gym’s quiet — 14% full. Good time to go.</div>
          </div>
        </div>
      )}
    </Feature>
  );
}

/* ═════════════ 02 WORKOUTS ═════════════ */
const SETS = [{ n: 1, kg: 120, r: 5, at: -1 }, { n: 2, kg: 130, r: 5, at: -1 }, { n: 3, kg: 140, r: 3, at: 1.3 }];
export function Workouts() {
  const t = useT();
  const st = spring(t - 1.5, { stiffness: 260, damping: 15, mass: 1 });
  const sh = shake(t, [{ t: 1.55, s: 0.9 }], 16, 8);
  const trend = [118, 122, 125, 128, 130, 132.5, 140];
  return (
    <Feature idx={2} label="Smart workouts" size={176}
      lines={[[{ w: 'Every' }, { w: 'rep.' }], [{ w: 'Tracked.', v: 1 }]]}
      sub="Log sets in a tap. Personal records and progressive overload — automatic.">
      <Tilt>
        <div style={{ transform: `translate(${sh.x}px, ${sh.y}px)` }}>
          <Glass style={{ width: 820, padding: '36px 40px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={label()}>Pull day · Week 6</div>
                <div style={{ ...heavy(92), marginTop: 8 }}>Deadlift</div>
              </div>
              <svg width="230" height="90" viewBox="0 0 230 90">
                <polyline fill="none" stroke={C.volt} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" pathLength="1" strokeDasharray={`${prog(t, 0.2, 1.1, Ease.out) * (t > 1.5 ? 1 : 0.85)} 1`}
                  points={trend.map((v, i) => `${8 + i * 35},${82 - ((v - 115) / 27) * 74}`).join(' ')} style={{ filter: 'drop-shadow(0 0 8px rgba(200,255,46,.7))' }} />
              </svg>
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
              {['Hamstrings', 'Glutes', 'Back'].map((m) => <span key={m} style={{ ...label(C.ink), fontSize: 17, padding: '8px 14px', borderRadius: 8, background: 'rgba(255,255,255,.08)' }}>{m}</span>)}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr 1fr 90px', marginTop: 30, padding: '0 20px 12px', ...label(C.faint) }}>
              <span>Set</span><span>KG</span><span>Reps</span><span />
            </div>
            {SETS.map((s, i) => {
              const done = s.at < 0 || t > s.at;
              const ck = s.at < 0 ? 1 : spring(t - s.at, SPR.pop);
              const hot = s.at > 0 && done;
              return (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '90px 1fr 1fr 90px', alignItems: 'center', height: 96, padding: '0 20px', marginBottom: 12, borderRadius: 18, background: hot ? 'rgba(200,255,46,.12)' : 'rgba(255,255,255,.04)', border: `2px solid ${hot ? C.volt : 'rgba(255,255,255,.06)'}`, opacity: prog(t, 0.2 + i * 0.08, 0.45 + i * 0.08) }}>
                  <span style={{ ...heavy(48), color: C.mute }}>{s.n}</span>
                  <span style={{ ...heavy(64) }}>{s.kg}</span>
                  <span style={{ ...heavy(64) }}>{s.r}</span>
                  <span style={{ width: 66, height: 66, borderRadius: 16, display: 'grid', placeItems: 'center', background: done ? C.volt : 'rgba(255,255,255,.08)', transform: `scale(${done ? 0.75 + 0.25 * ck : 1})` }}>
                    {done && <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#0A0A0A" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7" /></svg>}
                  </span>
                </div>
              );
            })}
          </Glass>
        </div>
      </Tilt>
      {/* the PR stamp */}
      {st > 0.001 && (
        <div style={{ position: 'absolute', left: 1250, top: 800, transform: `rotate(-8deg) scale(${2.2 - 1.2 * st})`, opacity: clamp(st * 3), transformOrigin: '50% 50%' }}>
          <div style={{ background: C.volt, padding: '20px 36px 24px', borderRadius: 14, boxShadow: '0 30px 80px -10px rgba(200,255,46,.6)' }}>
            <div style={{ ...heavy(120, { color: C.black }), fontStyle: 'italic' }}>New PR</div>
            <div style={{ ...heavy(52, { color: C.black }), marginTop: 6 }}>140 KG · +7.5</div>
          </div>
        </div>
      )}
    </Feature>
  );
}

/* ═════════════ 03 NUTRITION ═════════════ */
const TYPED = '2 rotis + 150g rice + dal';
const FOODS = [{ n: 'Roti', q: '× 2', k: 240 }, { n: 'Rice, cooked', q: '150 g', k: 195 }, { n: 'Dal', q: '1 bowl', k: 180 }];
export function Fuel() {
  const t = useT();
  const chars = Math.floor(clamp((t - 0.35) / 1.0) * TYPED.length);
  const sent = t > 1.4;
  const kcal = interp(t, [1.75, 2.6], [1225, 1840], Ease.out);
  const caret = !sent && Math.floor(t * 2.4) % 2 === 0;
  return (
    <Feature idx={3} label="Nutrition" size={164}
      lines={[[{ w: 'Type' }, { w: 'it.' }], [{ w: 'We' }, { w: 'count' }], [{ w: 'it.', v: 1 }]]}
      sub="Log a meal like a text message. Indian foods built in — calories and macros done for you.">
      <Tilt>
        <div style={{ width: 820 }}>
          <div style={{ height: 116, borderRadius: 30, background: '#151515', border: `2px solid ${!sent && t > 0.3 ? C.volt : 'rgba(255,255,255,.14)'}`, display: 'flex', alignItems: 'center', padding: '0 16px 0 34px', boxShadow: '0 40px 80px -30px rgba(0,0,0,1)' }}>
            <div style={{ flex: 1, ...ui(600, 40, chars && !sent ? C.ink : C.faint), whiteSpace: 'nowrap', overflow: 'hidden' }}>
              {!sent && chars ? TYPED.slice(0, chars) : 'What did you eat?'}
              {caret && <span style={{ display: 'inline-block', width: 4, height: 44, background: C.volt, marginLeft: 4, verticalAlign: 'middle' }} />}
            </div>
            <div style={{ width: 84, height: 84, borderRadius: 24, background: C.volt, display: 'grid', placeItems: 'center' }}>
              <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#0A0A0A" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" /></svg>
            </div>
          </div>
          <div style={{ marginTop: 22, minHeight: 300 }}>
            {FOODS.map((f, i) => {
              const s = spring(t - 1.45 - i * 0.12, SPR.pop);
              if (s <= 0.001) return null;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 20, height: 92, padding: '0 28px', marginBottom: 12, borderRadius: 22, background: '#121212', border: '1px solid rgba(255,255,255,.1)', transform: `translateX(${(1 - s) * 80}px)`, opacity: clamp(s * 2) }}>
                  <div style={{ width: 14, height: 14, borderRadius: 4, background: C.volt }} />
                  <div style={{ flex: 1, ...ui(700, 34) }}>{f.n} <span style={{ ...ui(500, 30, C.mute) }}>{f.q}</span></div>
                  <span style={{ ...label(C.volt), fontSize: 16 }}>Verified</span>
                  <div style={{ ...heavy(52), width: 150, textAlign: 'right' }}>{f.k}<span style={{ ...heavy(22, { color: C.mute }), marginLeft: 6 }}>kcal</span></div>
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 34, marginTop: 14, opacity: prog(t, 1.6, 1.9) }}>
            <Ring size={190} stroke={22} pct={kcal / 2200}><span style={{ ...heavy(30, { color: C.mute }) }}>{Math.round((kcal / 2200) * 100)}%</span></Ring>
            <div style={{ flex: 1 }}>
              <div style={{ ...heavy(110), fontVariantNumeric: 'tabular-nums' }}>{fmt(Math.round(kcal))}</div>
              <div style={{ ...label(), marginTop: 8 }}>of 2,200 kcal today</div>
              <div style={{ display: 'flex', gap: 14, marginTop: 18 }}>
                {[{ l: 'P', v: [62, 81], m: 140 }, { l: 'C', v: [140, 236], m: 280 }, { l: 'F', v: [38, 47], m: 70 }].map((m, i) => {
                  const v = interp(t, [1.75, 2.6], m.v, Ease.out);
                  return (
                    <div key={i} style={{ flex: 1 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', ...heavy(24) }}><span style={{ color: C.mute }}>{m.l}</span><span>{Math.round(v)}g</span></div>
                      <div style={{ height: 10, borderRadius: 3, background: 'rgba(255,255,255,.1)', marginTop: 8 }}><div style={{ height: '100%', width: `${(v / m.m) * 100}%`, background: C.volt, borderRadius: 3 }} /></div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </Tilt>
    </Feature>
  );
}

/* ═════════════ 04 SCAN ═════════════ */
const LABEL_ROWS = [
  { l: 'Calories', v: '210', big: true, key: 'ENERGY · 210 KCAL' },
  { l: 'Total Fat', v: '6g', key: 'FAT · 6 G' },
  { l: 'Carbohydrate', v: '18g', key: 'CARBS · 18 G' },
  { l: 'Sugars', v: '4g' },
  { l: 'Protein', v: '24g', key: 'PROTEIN · 24 G' },
  { l: 'Sodium', v: '180mg' },
];
export function Scan() {
  const t = useT();
  const scan = prog(t, 0.45, 1.5, Ease.inOut);
  const chips = LABEL_ROWS.filter((r) => r.key);
  return (
    <Feature idx={4} label="AI food scan" size={164}
      lines={[[{ w: 'Snap' }, { w: 'it.' }], [{ w: 'Scan' }, { w: 'it.' }], [{ w: 'Done.', v: 1 }]]}
      sub="Point at a nutrition label, a barcode or your plate — Barbell reads it for you.">
      <Tilt x={1240} ry={-12}>
        <div style={{ position: 'relative', width: 540, height: 760, borderRadius: 48, background: '#0C0C0C', border: '10px solid #1E1E1E', boxShadow: '0 60px 120px -30px rgba(0,0,0,1)', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', left: 60, top: 90, width: 420, padding: '26px 28px', background: '#FAFAF7', color: '#111', transform: 'rotate(-3deg)', boxShadow: '0 20px 50px rgba(0,0,0,.6)' }}>
            <div style={{ font: `900 46px ${F.display}`, letterSpacing: '-0.02em' }}>Nutrition Facts</div>
            <div style={{ ...ui(500, 18, '#333'), borderBottom: '10px solid #111', paddingBottom: 8, marginTop: 4 }}>Serving size 1 bar (60 g)</div>
            {LABEL_ROWS.map((r, i) => {
              const rowY = (i + 1) / (LABEL_ROWS.length + 1);
              const hit = r.key && scan > rowY;
              return (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: r.big ? '10px 6px' : '8px 6px', borderBottom: r.big ? '6px solid #111' : '1px solid #999', background: hit ? 'rgba(200,255,46,.55)' : 'transparent' }}>
                  <span style={{ font: `${r.big ? 900 : 700} ${r.big ? 34 : 22}px ${F.display}` }}>{r.l}</span>
                  <span style={{ font: `900 ${r.big ? 40 : 22}px ${F.display}` }}>{r.v}</span>
                </div>
              );
            })}
            <div style={{ display: 'flex', gap: 3, marginTop: 18, height: 60, alignItems: 'stretch' }}>
              {Array.from({ length: 38 }, (_, k) => <div key={k} style={{ width: [2, 4, 2, 6, 3][k % 5], background: '#111' }} />)}
            </div>
          </div>
          {/* viewfinder brackets */}
          {[[30, 60, 0], [480, 60, 90], [480, 690, 180], [30, 690, 270]].map(([x, y, r], k) => (
            <div key={k} style={{ position: 'absolute', left: x, top: y, width: 60, height: 60, borderTop: `8px solid ${C.volt}`, borderLeft: `8px solid ${C.volt}`, transform: `rotate(${r}deg)`, transformOrigin: '30px 30px', borderRadius: '10px 0 0 0' }} />
          ))}
          {scan > 0 && scan < 1 && (
            <div style={{ position: 'absolute', left: 30, right: 30, top: 70 + scan * 620, height: 6, background: C.volt, boxShadow: '0 0 30px 8px rgba(200,255,46,.7)' }} />
          )}
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 26, textAlign: 'center' }}>
            <Pill style={{ fontSize: 18 }}>{scan >= 1 ? 'Label read ✓' : 'Scanning…'}</Pill>
          </div>
        </div>
      </Tilt>
      {chips.map((c, i) => {
        const s = spring(t - 1.55 - i * 0.1, SPR.pop);
        if (s <= 0.001) return null;
        return (
          <div key={i} style={{ position: 'absolute', left: 1545, top: 250 + i * 112, transform: `translateX(${(1 - s) * -160}px) scale(${0.8 + 0.2 * s})`, opacity: clamp(s * 2), whiteSpace: 'nowrap', padding: '20px 26px', borderRadius: 20, background: i === 0 ? C.volt : '#151515', border: i === 0 ? 'none' : '1px solid rgba(255,255,255,.14)', ...heavy(26, { color: i === 0 ? C.black : C.ink }), letterSpacing: '0.02em' }}>{c.key}</div>
        );
      })}
      {[{ k: 'Barcode · matched', at: 2.35 }, { k: 'Meal photo · 450–550 kcal', at: 2.55 }].map((c, i) => {
        const s = spring(t - c.at, SPR.pop);
        if (s <= 0.001) return null;
        return <div key={i} style={{ position: 'absolute', left: 1545, top: 720 + i * 80, transform: `scale(${0.8 + 0.2 * s})`, opacity: clamp(s * 2), whiteSpace: 'nowrap', padding: '14px 20px', borderRadius: 14, border: `2px solid ${C.volt}`, ...label(C.volt), fontSize: 19 }}>{c.k}</div>;
      })}
    </Feature>
  );
}

/* ═════════════ 05 MUSCLE MAP (real 3D model from the app) ═════════════ */
const HEAT = { pectoralis_major: 1, latissimus_dorsi: 0.95, anterior_deltoid: 0.7, triceps: 0.7, rhomboids: 0.8, trapezius: 0.5, quadriceps: 0.6, hamstrings: 0.45, biceps: 0.55, lateral_deltoid: 0.6, gluteus_maximus: 0.4 };
function muscleSetup({ scene, camera }) {
  const src = window.__assets?.muscle;
  const pivot = new THREE.Group();
  scene.add(pivot);
  const mats = [];
  if (src) {
    const body = src.clone(true);
    const box = new THREE.Box3().setFromObject(body);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const k = 4.6 / size.y;
    body.position.sub(center).multiplyScalar(1);
    const holder = new THREE.Group();
    holder.add(body);
    holder.scale.setScalar(k);
    pivot.add(holder);
    body.traverse((o) => {
      if (!o.isMesh) return;
      const id = o.name.replace(/\.[lr]$/i, '');
      const h = HEAT[id] || 0;
      const m = new THREE.MeshStandardMaterial({ color: h ? new THREE.Color().setHSL(0.21, 0.9, 0.12 + h * 0.38) : new THREE.Color(0x2b2b2b), roughness: 0.45, metalness: 0.15 });
      m.emissive = new THREE.Color(0xc8ff2e);
      m.emissiveIntensity = 0;
      m.userData.h = h;
      o.material = m;
      mats.push(m);
    });
  }
  heroLights(scene, { intensity: 1.1, rimA: 0xc8ff2e, rimB: 0xffffff });
  scene.environmentIntensity = 0.5;
  camera.position.set(0, 0.2, 9.5);
  return { pivot, mats };
}
function muscleUpdate({ camera, user }, t) {
  user.pivot.rotation.y = interp(t, [0, 4], [-0.55, 2.7], Ease.inOut);
  user.pivot.position.y = wobble(t, 5, 0.2) * 0.04;
  const glow = prog(t, 0.6, 1.6, Ease.out);
  for (const m of user.mats) m.emissiveIntensity = m.userData.h * glow * (0.35 + 0.1 * Math.sin(t * 5));
  camera.lookAt(0, 0, 0);
}
const LEGEND = [{ m: 'Chest', s: 12 }, { m: 'Back', s: 11 }, { m: 'Shoulders', s: 8 }, { m: 'Legs', s: 7 }, { m: 'Core', s: 0 }];
export function Muscles() {
  const t = useT();
  return (
    <Feature idx={5} label="3D muscle map" size={150}
      lines={[[{ w: 'See' }, { w: 'every' }], [{ w: 'muscle', v: 1 }], [{ w: 'you' }, { w: 'hit.' }]]}
      sub="Every set lands on a 3D body — see what you trained this week, and what you skipped.">
      <div style={{ position: 'absolute', left: 880, top: 0, width: 920, height: 1080 }}>
        <Abs style={{ background: 'radial-gradient(420px 520px at 50% 50%, rgba(200,255,46,.12), transparent 70%)' }} />
        <ThreeStage setup={muscleSetup} update={muscleUpdate} width={920} height={1080} fov={34} exposure={1.15} />
      </div>
      <div style={{ position: 'absolute', right: 50, top: 300 }}>
        {LEGEND.map((l, i) => {
          const s = spring(t - 0.9 - i * 0.1, SPR.pop);
          const skip = l.s === 0;
          return (
            <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, width: 350, whiteSpace: 'nowrap', padding: '14px 20px', marginBottom: 12, borderRadius: 14, background: skip ? 'transparent' : 'rgba(20,20,20,.9)', border: `2px solid ${skip ? C.hot : 'rgba(255,255,255,.12)'}`, transform: `translateX(${(1 - s) * 80}px)`, opacity: clamp(s * 2) }}>
              <span style={{ ...heavy(26), color: skip ? C.hot : C.ink, letterSpacing: '0.04em' }}>{l.m}</span>
              <span style={{ ...heavy(26), color: skip ? C.hot : C.volt }}>{skip ? 'Skipped' : `${l.s} sets`}</span>
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', right: 40, bottom: 26, font: `500 13px ${F.ui}`, color: 'rgba(255,255,255,.4)' }}>
        3D anatomy: “BodyParts3D, © The Database Center for Life Science licensed under CC Attribution-Share Alike 2.1 Japan” mixed and modified by Z-Anatomy.com
      </div>
    </Feature>
  );
}

/* ═════════════ 06 COMMUNITY ═════════════ */
const BOARD = [
  { n: 'Priya K.', i: 'PK', v: 14200, g: ['#8B5CF6', '#FF2E63'] },
  { n: 'Aarav M.', i: 'AM', v: 13950, g: ['#FFA24A', '#FF5A3C'] },
  { n: 'You', i: 'YOU', v: 13400, g: [C.volt, C.voltDeep], me: true },
  { n: 'Neha R.', i: 'NR', v: 12100, g: ['#22D3EE', '#8B5CF6'] },
];
export function Community() {
  const t = useT();
  const climb = prog(t, 1.3, 2.0, Ease.inOut);
  const myV = interp(climb, [0, 1], [13400, 14650]);
  const order = (row) => {
    if (row.me) return interp(climb, [0, 1], [2, 0]);
    const base = BOARD.indexOf(row);
    return base < 2 ? base + climb : base;
  };
  const streak = prog(t, 0.6, 1.6, Ease.out);
  return (
    <Feature idx={6} label="Community" size={150}
      lines={[[{ w: 'Train' }], [{ w: 'together.', v: 1 }]]}
      sub="Gym and friend communities, weekly leaderboards and streak challenges.">
      <Tilt>
        <div style={{ width: 820 }}>
          <Glass style={{ padding: '30px 34px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={label(C.ink)}>Leaderboard · this week</span>
              <span style={label(C.volt)}>Volume lifted</span>
            </div>
            <div style={{ position: 'relative', height: 4 * 104, marginTop: 20 }}>
              {BOARD.map((r, i) => {
                const pos = order(r);
                const v = r.me ? myV : r.v;
                return (
                  <div key={i} style={{ position: 'absolute', left: 0, right: 0, top: pos * 104, height: 92, display: 'flex', alignItems: 'center', gap: 20, padding: '0 22px', borderRadius: 18, background: r.me ? C.volt : 'rgba(255,255,255,.04)', zIndex: r.me ? 2 : 1, boxShadow: r.me ? '0 20px 50px -10px rgba(200,255,46,.5)' : 'none', opacity: prog(t, 0.15 + i * 0.07, 0.4 + i * 0.07) }}>
                    <span style={{ ...heavy(48, { color: r.me ? C.black : C.mute }), width: 50 }}>{Math.round(pos) + 1}</span>
                    <span style={{ width: 60, height: 60, borderRadius: 99, background: `linear-gradient(135deg, ${r.g[0]}, ${r.g[1]})`, display: 'grid', placeItems: 'center', ...heavy(r.me ? 18 : 22, { color: r.me ? C.black : '#fff' }), border: r.me ? '3px solid #0A0A0A' : 'none' }}>{r.i}</span>
                    <span style={{ flex: 1, ...heavy(40, { color: r.me ? C.black : C.ink }), letterSpacing: '-0.01em' }}>{r.n}</span>
                    <span style={{ ...heavy(44, { color: r.me ? C.black : C.ink }), fontVariantNumeric: 'tabular-nums' }}>{fmt(Math.round(v / 10) * 10)}<span style={{ fontSize: 22, opacity: 0.6 }}> kg</span></span>
                  </div>
                );
              })}
            </div>
          </Glass>
          <Glass style={{ marginTop: 22, padding: '26px 34px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={label(C.volt)}>Challenge</div>
                <div style={{ ...heavy(52), marginTop: 6 }}>30-day streak</div>
              </div>
              <div style={{ ...heavy(64), fontVariantNumeric: 'tabular-nums' }}>{Math.round(12 * streak)}<span style={{ ...heavy(30, { color: C.mute }) }}>/30</span></div>
            </div>
            <div style={{ display: 'flex', gap: 5, marginTop: 18 }}>
              {Array.from({ length: 30 }, (_, k) => <div key={k} style={{ flex: 1, height: 22, borderRadius: 4, background: k < Math.round(12 * streak) ? C.volt : 'rgba(255,255,255,.1)' }} />)}
            </div>
          </Glass>
        </div>
      </Tilt>
    </Feature>
  );
}

/* ═════════════ 07 COACHING ═════════════ */
export function Coaching() {
  const t = useT();
  const pulse = 0.5 + 0.5 * Math.sin(t * 7);
  const adh = interp(t, [0.4, 1.1], [68, 31], Ease.inOut);
  const press = prog(t, 1.45, 1.75, Ease.out);
  const b1 = spring(t - 1.7, SPR.pop);
  const typing = t > 2.0 && t < 2.4;
  const b2 = spring(t - 2.4, SPR.pop);
  const ok = spring(t - 2.9, SPR.pop);
  return (
    <Feature idx={7} label="For coaches" size={124}
      lines={[[{ w: 'Catch' }, { w: 'them' }], [{ w: 'before' }, { w: 'they' }], [{ w: 'quit.', v: 1 }]]}
      sub="At-risk alerts, adherence scores and one-tap check-ins for every client.">
      <Tilt>
        <div style={{ width: 820 }}>
          <Glass style={{ padding: '32px 38px', border: `2px solid rgba(255,77,45,${0.4 + 0.4 * pulse})`, boxShadow: `0 50px 100px -40px #000, 0 0 ${50 + 30 * pulse}px -10px rgba(255,77,45,.55)` }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Pill bg={C.hot} color="#fff"><LiveDot t={t} size={12} color="#fff" />At-risk alert</Pill>
              <span style={label()}>Today · 9:12 AM</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 22, marginTop: 26 }}>
              <span style={{ width: 92, height: 92, borderRadius: 99, background: 'linear-gradient(135deg,#FF7A3D,#FF2E63)', display: 'grid', placeItems: 'center', ...heavy(32) }}>RS</span>
              <div>
                <div style={{ ...heavy(80) }}>Rahul S.</div>
                <div style={{ ...ui(500, 30, C.mute), marginTop: 6 }}>No workout in <b style={{ color: C.hot }}>9 days</b></div>
              </div>
            </div>
            <div style={{ marginTop: 26, display: 'flex', alignItems: 'center', gap: 20 }}>
              <span style={label()}>Adherence</span>
              <div style={{ flex: 1, height: 18, borderRadius: 4, background: 'rgba(255,255,255,.08)', transform: 'skewX(-18deg)', overflow: 'hidden' }}><div style={{ width: `${adh}%`, height: '100%', background: C.hot }} /></div>
              <span style={{ ...heavy(54, { color: C.hot }), fontVariantNumeric: 'tabular-nums', width: 120, textAlign: 'right' }}>{Math.round(adh)}%</span>
            </div>
            <div style={{ display: 'flex', gap: 14, marginTop: 28 }}>
              <div style={{ position: 'relative', ...heavy(30, { color: C.black }), letterSpacing: '0.04em', background: C.volt, padding: '22px 30px', borderRadius: 16, transform: `scale(${1 - 0.08 * Math.sin(Math.PI * press)})` }}>
                Send check-in
                {press > 0 && press < 1 && <span style={{ position: 'absolute', left: '50%', top: '50%', width: 300 * press, height: 300 * press, marginLeft: -150 * press, marginTop: -150 * press, borderRadius: 999, border: `3px solid rgba(255,255,255,${1 - press})` }} />}
              </div>
              <div style={{ ...heavy(30, { color: C.mute }), letterSpacing: '0.04em', padding: '22px 30px', borderRadius: 16, border: '2px solid rgba(255,255,255,.15)' }}>View profile</div>
            </div>
          </Glass>
          <div style={{ marginTop: 26, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {b1 > 0.001 && <div style={{ alignSelf: 'flex-end', maxWidth: 600, padding: '22px 28px', borderRadius: '28px 28px 8px 28px', background: C.volt, ...ui(700, 32, C.black), transform: `scale(${0.8 + 0.2 * b1})`, opacity: clamp(b1 * 2), transformOrigin: '100% 100%' }}>Missed you this week. Same time tomorrow?</div>}
            {typing && <div style={{ alignSelf: 'flex-start', padding: '22px 26px', borderRadius: '28px 28px 28px 8px', background: '#1C1C1C', display: 'flex', gap: 9 }}>{[0, 1, 2].map((k) => <span key={k} style={{ width: 12, height: 12, borderRadius: 9, background: C.mute, opacity: 0.4 + 0.6 * Math.abs(Math.sin(t * 9 + k)) }} />)}</div>}
            {b2 > 0.001 && <div style={{ alignSelf: 'flex-start', padding: '22px 28px', borderRadius: '28px 28px 28px 8px', background: '#1C1C1C', ...ui(700, 32), transform: `scale(${0.8 + 0.2 * b2})`, opacity: clamp(b2 * 2), transformOrigin: '0% 100%' }}>See you at 7. Back on it.</div>}
          </div>
        </div>
      </Tilt>
      {ok > 0.001 && <div style={{ position: 'absolute', left: 1560, top: 150, transform: `rotate(6deg) scale(${1.6 - 0.6 * ok})`, opacity: clamp(ok * 3) }}><Pill style={{ fontSize: 26, padding: '16px 24px' }}>Back on track ✓</Pill></div>}
    </Feature>
  );
}

/* ═════════════ 08 OWNERS ═════════════ */
function Tile({ i, t, children, volt }) {
  const s = spring(t - 0.25 - i * 0.1, SPR.snappy);
  return (
    <div style={{ width: 400, height: 300, borderRadius: 30, padding: '30px 32px', position: 'relative', overflow: 'hidden', background: volt ? C.volt : 'linear-gradient(165deg, rgba(255,255,255,.08), rgba(255,255,255,.015) 55%), #101010', border: volt ? 'none' : '1px solid rgba(255,255,255,.12)', boxShadow: volt ? '0 40px 90px -30px rgba(200,255,46,.6)' : '0 40px 80px -30px #000', transform: `translateY(${(1 - s) * 120}px) scale(${0.85 + 0.15 * s})`, opacity: clamp(s * 1.6), color: volt ? C.black : C.ink }}>{children}</div>
  );
}
export function Owners() {
  const t = useT();
  const n = (v, at, d = 1.0) => v * prog(t, at, at + d, Ease.out);
  const L = (c) => ({ ...label(c), fontSize: 18 });
  return (
    <Feature idx={8} label="For gym owners" size={160}
      lines={[[{ w: 'Run' }, { w: 'the' }], [{ w: 'whole' }], [{ w: 'gym.', v: 1 }]]}
      sub="Members, renewals, revenue and QR check-ins — one live dashboard.">
      <Tilt ry={-8}>
        <div style={{ display: 'grid', gridTemplateColumns: '400px 400px', gap: 24 }}>
          <Tile i={0} t={t}>
            <div style={L(C.mute)}>Active members</div>
            <div style={{ ...heavy(140), marginTop: 18, fontVariantNumeric: 'tabular-nums' }}>{Math.round(n(248, 0.4))}</div>
            <div style={{ ...label(C.volt), fontSize: 18, marginTop: 12 }}>+12 this month</div>
          </Tile>
          <Tile i={1} t={t} volt>
            <div style={L('rgba(10,10,10,.7)')}>Revenue · October</div>
            <div style={{ ...heavy(132, { color: C.black }), marginTop: 18 }}>₹{n(4.2, 0.5).toFixed(1)}L</div>
            <svg width="336" height="56" viewBox="0 0 336 56" style={{ position: 'absolute', left: 32, bottom: 26 }}>
              <polyline fill="none" stroke="#0A0A0A" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" pathLength="1" strokeDasharray={`${prog(t, 0.6, 1.5)} 1`} points={[2.9, 3.1, 3.0, 3.4, 3.3, 3.6, 3.8, 3.7, 4.0, 4.2].map((v, i) => `${i * 37},${52 - ((v - 2.8) / 1.5) * 48}`).join(' ')} />
            </svg>
            <span style={{ position: 'absolute', right: 26, top: 26, ...heavy(26, { color: C.black }), background: 'rgba(10,10,10,.12)', padding: '6px 12px', borderRadius: 8 }}>+9%</span>
          </Tile>
          <Tile i={2} t={t}>
            <div style={L(C.mute)}>Renewals</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 22, marginTop: 22 }}>
              <Ring size={150} stroke={20} pct={0.86 * prog(t, 0.6, 1.4, Ease.out)} />
              <div><div style={{ ...heavy(96), fontVariantNumeric: 'tabular-nums' }}>{Math.round(n(31, 0.6))}</div><div style={{ ...heavy(30, { color: C.mute }) }}>of 36</div></div>
            </div>
          </Tile>
          <Tile i={3} t={t}>
            <div style={L(C.mute)}>QR check-ins today</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 18 }}>
              <div style={{ ...heavy(124), fontVariantNumeric: 'tabular-nums' }}>{Math.round(n(186, 0.7))}</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 12px)', gap: 3, padding: 8, borderRadius: 10, background: C.ink }}>
                {Array.from({ length: 25 }, (_, k) => <span key={k} style={{ width: 12, height: 12, background: [0, 1, 3, 5, 7, 9, 12, 13, 16, 18, 19, 21, 24, 4, 20].includes(k) ? '#0A0A0A' : 'transparent' }} />)}
              </div>
            </div>
            <div style={{ ...label(C.volt), fontSize: 18, marginTop: 8 }}>Live · front desk</div>
          </Tile>
        </div>
      </Tilt>
    </Feature>
  );
}
