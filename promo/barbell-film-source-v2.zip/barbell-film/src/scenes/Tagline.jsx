import React from 'react';
import { useT, prog, Ease, clamp, spring, SPR } from '../lib/anim.js';
import { Abs, C, F, VoltBg, Rise, BrandMark2D, heavy, outline } from '../lib/ui.jsx';

const DK = '#0A0A0A';
const LINES = [['Train', 'smarter.'], ['Coach', 'better.'], ['Prove', 'progress.']];

export function Tagline() {
  const t = useT();
  const open = prog(t, 0, 0.3, Ease.out);
  const close = prog(t, 3.55, 4.0, Ease.in);
  const r = open * 1300 * (1 - close);
  return (
    <Abs style={{ clipPath: `circle(${Math.max(0, r)}px at 50% 50%)` }}>
      <VoltBg />
      <Abs style={{ display: 'grid', placeItems: 'center' }}>
        <div style={{ transform: `scale(${1 - close * 0.3})` }}>
          {LINES.map((l, i) => {
            const at = 0.05 + i * 1.0;
            return (
              <div key={i} style={{ height: 210 }}>
                <Rise text="" at={at} stagger={0.08} dur={0.5} align="center"
                  spans={[{ w: l[0] }, { w: l[1], style: { fontStyle: 'italic', ...outline(5, DK) } }]}
                  style={{ ...heavy(176, { color: DK }), justifyContent: 'center' }} />
              </div>
            );
          })}
        </div>
      </Abs>
      <Abs style={{ top: 56, opacity: prog(t, 0.2, 0.6) * (1 - close) }}>
        <div style={{ display: 'flex', justifyContent: 'center' }}><BrandMark2D size={72} color={DK} draw={prog(t, 0.2, 1.2)} /></div>
      </Abs>
    </Abs>
  );
}
