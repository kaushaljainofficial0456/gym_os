import React from 'react';
import { createRoot } from 'react-dom/client';
import { flushSync } from 'react-dom';
import { TimeCtx } from './lib/anim.js';
import { Video, DURATION } from './Video.jsx';
import { GLTFLoader } from './lib/three/GLTFLoader.js';
import { DRACOLoader } from './lib/three/DRACOLoader.js';

const params = new URLSearchParams(location.search);
const FPS = Number(params.get('fps') || 30);
const root = createRoot(document.getElementById('root'));

window.__fps = FPS;
window.__duration = DURATION;
window.__frames = Math.round(DURATION * FPS);
window.__seek = (frame) => {
  const t = frame / FPS;
  flushSync(() => {
    root.render(
      <TimeCtx.Provider value={{ t, abs: t, fps: FPS, dur: DURATION }}>
        <Video />
      </TimeCtx.Provider>,
    );
  });
  return true;
};

window.__ready = (async () => {
  const fonts = [
    '400 40px "DM Sans"', '600 40px "DM Sans"', '700 40px "DM Sans"',
    '400 40px "Sentient"', '500 40px "Sentient"',
    '900 40px "Inter Display"', '800 40px "Inter Display"', '600 40px "Inter Display"', '500 40px "Inter Display"',
    'italic 400 40px "Lora"', 'italic 500 40px "Lora"', 'italic 600 40px "Lora"',
    'italic 900 40px "Inter Display"', 'italic 800 40px "Inter Display"', '700 40px "Inter Display"',
    '400 40px "Inter"', '500 40px "Inter"', '600 40px "Inter"', '700 40px "Inter"', '800 40px "Inter"',
  ];
  await Promise.all(fonts.map((f) => document.fonts.load(f).catch(() => null)));
  await document.fonts.ready;
  try {
    const draco = new DRACOLoader();
    draco.setDecoderPath('draco/');
    const loader = new GLTFLoader();
    loader.setDRACOLoader(draco);
    const gltf = await loader.loadAsync('assets/skos-muscular-body.glb');
    window.__assets = { muscle: gltf.scene };
  } catch (e) {
    console.error('muscle model failed: ' + e.message);
    window.__assets = {};
  }
  return true;
})();
