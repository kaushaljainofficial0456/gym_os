import React from 'react';
import { Seq } from './lib/anim.js';
import { Abs, Vignette, Slash } from './lib/ui.jsx';
import { Hook } from './scenes/Hook.jsx';
import { Guessing } from './scenes/Guessing.jsx';
import { Questions } from './scenes/Questions.jsx';
import { Chaos } from './scenes/Chaos.jsx';
import { Reveal } from './scenes/Reveal.jsx';
import { Crowd, Workouts, Fuel, Scan, Muscles, Community, Coaching, Owners } from './scenes/Features.jsx';
import { More } from './scenes/More.jsx';
import { Tagline } from './scenes/Tagline.jsx';

export const DURATION = 72;
// feature sections: [start, component, duration]
const FEATURES = [[26, Crowd, 6], [32, Workouts, 4], [36, Fuel, 4], [40, Scan, 4], [44, Muscles, 4], [48, Community, 4], [52, Coaching, 4], [56, Owners, 4]];

export function Video() {
  return (
    <Abs style={{ background: '#000', overflow: 'hidden' }}>
      <Seq from={0} dur={8}><Hook /></Seq>
      <Seq from={7.3} dur={4.75}><Guessing /></Seq>
      <Seq from={11.5} dur={6.55}><Questions /></Seq>
      <Seq from={18} dur={2.02}><Chaos /></Seq>
      <Seq from={20} dur={6}><Reveal variant="reveal" /></Seq>
      {FEATURES.map(([at, Comp, d]) => <Seq key={at} from={at} dur={d}><Comp /></Seq>)}
      <Seq from={60} dur={2}><More /></Seq>
      <Seq from={62} dur={4}><Tagline /></Seq>
      <Seq from={66} dur={6}><Reveal variant="end" /></Seq>
      <Vignette strength={0.45} />
      {[26, 32, 36, 40, 44, 48, 52, 56, 60].map((at, i) => <Slash key={at} at={at} dir={i % 2 ? -1 : 1} />)}
    </Abs>
  );
}
