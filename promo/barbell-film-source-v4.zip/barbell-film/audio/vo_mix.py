"""
Voiceover mixer for the Barbell film.

Takes the voice from either
  (a) one file per line:  audio/vo/line_00.wav, line_01.wav … (any format ffmpeg reads), or
  (b) one continuous take: audio/vo/full.<ext>  (ElevenLabs download, a phone recording …)
      which is split into lines automatically (silence detection + a best-fit
      alignment against the script in lines.json),
then places every line on its cue in lines.json, gently speeds up any line
that would run into the next cue, cleans the voice (HPF, presence, compression),
ducks the music and SFX under it, and writes audio/score_vo.wav.

Usage:  python3 vo_mix.py            -> score_vo.wav
        python3 vo_mix.py --mux IN.mp4 OUT.mp4   (also muxes onto the video, video stream copied)
"""
import json, os, sys, glob, subprocess, tempfile
import numpy as np
from scipy import signal

HERE = os.path.dirname(os.path.abspath(__file__))
SR = 48000
DUR = 72.0
N = int(SR * DUR)

def decode(path):
    """any audio -> mono float32 @48k via ffmpeg"""
    out = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(out, dtype='<f4').astype(np.float64)

def tempo(x, factor):
    """time-stretch without pitch change (ffmpeg atempo)"""
    with tempfile.TemporaryDirectory() as d:
        a, b = os.path.join(d, 'a.f32'), os.path.join(d, 'b.f32')
        x.astype('<f4').tofile(a)
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'f32le', '-ar', str(SR), '-ac', '1', '-i', a, '-filter:a', f'atempo={factor:.4f}', '-f', 'f32le', b], check=True)
        return np.fromfile(b, dtype='<f4').astype(np.float64)

def frame_rms(x, hop=480):
    n = len(x) // hop
    return np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(axis=1) + 1e-12), hop

def trim(x, db=-42):
    r, hop = frame_rms(x)
    th = max(10 ** (db / 20), r.max() * 10 ** (-36 / 20))
    on = np.where(r > th)[0]
    if not len(on):
        return x
    a = max(0, on[0] * hop - int(0.02 * SR))
    b = min(len(x), (on[-1] + 1) * hop + int(0.06 * SR))
    return x[a:b]

def split_full(x, lines):
    """split one continuous take into len(lines) chunks"""
    r, hop = frame_rms(x)
    floor = np.percentile(r, 10)
    th = max(floor * 4, r.max() * 10 ** (-38 / 20))
    voiced = r > th
    # voiced runs, bridging tiny gaps (<120 ms) inside words
    segs, i, n = [], 0, len(voiced)
    while i < n:
        if voiced[i]:
            j = i
            while j < n and (voiced[j] or (j + 12 < n and voiced[j:j + 12].any())):
                j += 1
            segs.append((i * hop, j * hop))
            i = j
        else:
            i += 1
    segs = [s for s in segs if s[1] - s[0] > 0.06 * SR]
    S, K = len(segs), len(lines)
    if S < K:
        raise SystemExit(f'found only {S} speech segments for {K} lines — leave a clear pause between lines')
    gaps = [(segs[k + 1][0] - segs[k][1]) / SR for k in range(S - 1)] + [9.0]
    exp = np.array([max(4, len(l['text'])) for l in lines], float)
    total = (segs[-1][1] - segs[0][0]) / SR
    exp = exp / exp.sum() * total
    INF = 1e18
    cost = np.full((K + 1, S + 1), INF)
    back = np.zeros((K + 1, S + 1), int)
    cost[0][0] = 0
    for k in range(1, K + 1):
        for j in range(k, S - (K - k) + 1):
            for i in range(k - 1, j):
                if cost[k - 1][i] >= INF:
                    continue
                d = (segs[j - 1][1] - segs[i][0]) / SR
                c = cost[k - 1][i] + np.log(max(d, 0.05) / exp[k - 1]) ** 2 - 1.5 * min(gaps[j - 1], 1.5)
                if c < cost[k][j]:
                    cost[k][j], back[k][j] = c, i
    out, j = [], S
    for k in range(K, 0, -1):
        i = back[k][j]
        out.append((segs[i][0], segs[j - 1][1]))
        j = i
    out.reverse()
    return [x[a:b] for a, b in out]

def lp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, 'low', fs=SR, output='sos'), x, axis=-1)
def hp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, 'high', fs=SR, output='sos'), x, axis=-1)

def voice_chain(v):
    v = hp(v, 90)
    v = v + 0.35 * hp(v, 3500)                     # presence
    env = np.sqrt(lp(v ** 2, 30, 1).clip(0)) + 1e-9
    th = 0.08
    g = np.where(env > th, (th / env) ** (1 - 1 / 3.0), 1.0)   # 3:1 compression
    v = v * g
    v = np.tanh(v * 2.2) / np.tanh(2.2)
    return v / (np.abs(v).max() + 1e-9)

def main():
    lines = json.load(open(os.environ.get('LINES', os.path.join(HERE, 'lines.json'))))
    vdir = os.environ.get('VO_DIR', os.path.join(HERE, 'vo'))
    full = [p for p in glob.glob(os.path.join(vdir, 'full.*'))]
    per = sorted(glob.glob(os.path.join(vdir, 'line_*.*')))
    if per:
        clips = [trim(decode(p)) for p in per]
        if len(clips) != len(lines):
            raise SystemExit(f'{len(clips)} line files for {len(lines)} lines')
    elif full:
        clips = [trim(c) for c in split_full(decode(full[0]), lines)]
    else:
        raise SystemExit('no voice found: put audio/vo/full.<ext> or audio/vo/line_XX.<ext>')

    voice = np.zeros(N + SR * 3)
    report = []
    for k, (l, c) in enumerate(zip(lines, clips)):
        start = l['t']
        end_ok = (lines[k + 1]['t'] - 0.06) if k + 1 < len(lines) else DUR - 0.6
        if 'end' in l:
            end_ok = min(end_ok, l['end'])
        room = end_ok - start
        d = len(c) / SR
        f = 1.0
        if d > room and room > 0.2:
            f = min(1.32, d / room)
            c = tempo(c, f)
        i = int(start * SR)
        voice[i:i + len(c)] += c[: len(voice) - i]
        report.append(f'{start:6.2f}s  {d:4.2f}s{" x%.2f" % f if f > 1 else "      "}  {l["text"]}')
    voice = voice_chain(voice[:N])

    stems = np.load(os.path.join(HERE, 'stems.npy')).astype(np.float64)   # [music|sfx, 2, N]
    music, sfx = stems[0][:, :N], stems[1][:, :N]
    # ducking from the voice envelope (fast attack, slow release)
    e = np.abs(voice)
    att, rel = np.exp(-1 / (0.012 * SR)), np.exp(-1 / (0.30 * SR))
    env = signal.lfilter([1 - rel], [1, -rel], e)
    env = np.maximum(env, signal.lfilter([1 - att], [1, -att], e))
    env = np.clip(env / (np.percentile(env[env > 1e-4], 90) + 1e-9), 0, 1) if (env > 1e-4).any() else env
    duck_m = 1 - 0.70 * env          # ≈ -10.5 dB under speech
    duck_s = 1 - 0.45 * env
    vo_st = np.stack([voice, voice]) * 0.85
    mix = music * duck_m + sfx * duck_s + vo_st
    mix = hp(mix, 28)
    mix = np.tanh(mix * 1.1) / np.tanh(1.1)
    mix = mix / np.abs(mix).max() * 0.93
    out = os.environ.get('OUT', os.path.join(HERE, 'score_vo.wav'))
    pcm = (np.clip(mix.T, -1, 1) * 32767).astype('<i2')
    import wave
    with wave.open(out, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    print('\n'.join(report))
    print('wrote', out)
    if '--mux' in sys.argv:
        i = sys.argv.index('--mux')
        vin, vout = sys.argv[i + 1], sys.argv[i + 2]
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', vin, '-i', out, '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                        '-af', 'loudnorm=I=-14:TP=-1.2:LRA=11,aresample=48000', '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', '-shortest', vout], check=True)
        print('muxed', vout)

if __name__ == '__main__':
    main()
