import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR } from '../lib/anim.js';
import { Abs, C, F, EmberBg, Rise, BrandMark2D } from '../lib/ui.jsx';

const DK = '#1A0B0C';
const LINES = [
  { a: 'Train', b: 'smarter.' },
  { a: 'Coach', b: 'better.' },
  { a: 'Prove', b: 'progress.' },
];

export function Tagline() {
  const t = useT();
  // ember fills the frame, then closes into a point where the badge will appear
  const open = prog(t, 0, 0.35, Ease.out);
  const close = prog(t, 3.55, 4.0, Ease.in);
  const r = open * 1300 * (1 - close);
  return (
    <Abs style={{ clipPath: `circle(${Math.max(0, r)}px at 50% 50%)` }}>
      <EmberBg />
      <Abs style={{ display: 'grid', placeItems: 'center' }}>
        <div style={{ transform: `scale(${1 - close * 0.3})` }}>
          {LINES.map((l, i) => {
            const at = 0.05 + i * 1.0;
            const dim = i < 2 ? prog(t, at + 0.95, at + 1.2) * (1 - prog(t, 2.95, 3.15)) : 0;
            return (
              <div key={i} style={{ opacity: 1 - dim * 0.6, height: 168 }}>
                <Rise text="" at={at} stagger={0.08} dur={0.6} align="center"
                  spans={[{ w: l.a }, { w: l.b, style: { fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, color: C.cream } }]}
                  style={{ font: `400 150px ${F.serif}`, color: DK, letterSpacing: '-0.03em', lineHeight: 1.05, justifyContent: 'center' }} />
              </div>
            );
          })}
        </div>
      </Abs>
      <Abs style={{ top: 70, opacity: prog(t, 0.2, 0.6) * (1 - close) }}>
        <div style={{ display: 'flex', justifyContent: 'center' }}><BrandMark2D size={64} color={DK} draw={prog(t, 0.2, 1.2)} /></div>
      </Abs>
    </Abs>
  );
}
