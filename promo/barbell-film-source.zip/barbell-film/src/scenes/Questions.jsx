import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, wobble, rng, fmt } from '../lib/anim.js';
import { Abs, C, F, Rise, EmberBg } from '../lib/ui.jsx';
const DK = '#1A0B0C';

const CARDS = [
  { tag: 'The bench', q: "Last week's bench press?", a: 'uh… 60? maybe 65?', lo: 50, hi: 75, unit: 'kg', dec: 0 },
  { tag: 'The food', q: 'Calories today?', a: 'like… 2,000-ish?', lo: 1400, hi: 2900, unit: 'kcal', dec: 0 },
  { tag: 'The gym', q: 'Is the gym packed right now?', a: 'no idea.', lo: 5, hi: 98, unit: '% full', dec: 0 },
];

/** a gauge whose needle can't make up its mind — the visual for "guessing" */
function Gauge({ seed, lo, hi, unit, t, enter }) {
  const ang = wobble(t * 1.4, seed, 1.3) * 70 + wobble(t * 5, seed + 9, 2) * 12;
  const step = Math.floor(t / 0.09);
  const r = rng(seed * 1000 + step);
  const val = lo + r() * (hi - lo);
  const shown = unit === 'kcal' ? fmt(Math.round(val / 10) * 10) : Math.round(val);
  const s = spring(enter, SPR.snappy);
  return (
    <div style={{ position: 'absolute', left: 1250, top: 330, width: 560, transform: `translateY(${(1 - s) * 60}px) scale(${0.9 + 0.1 * s})`, opacity: clamp(s * 1.5) }}>
      <svg width="560" height="320" viewBox="0 0 560 320">
        <path d="M 40 290 A 240 240 0 0 1 520 290" fill="none" stroke="rgba(26,11,12,.16)" strokeWidth="18" strokeLinecap="round" />
        {Array.from({ length: 21 }, (_, i) => {
          const a = Math.PI + (i / 20) * Math.PI;
          const r1 = i % 5 === 0 ? 196 : 208, r2 = 222;
          return <line key={i} x1={280 + Math.cos(a) * r1} y1={290 + Math.sin(a) * r1} x2={280 + Math.cos(a) * r2} y2={290 + Math.sin(a) * r2} stroke="rgba(26,11,12,.42)" strokeWidth={i % 5 === 0 ? 4 : 2} strokeLinecap="round" />;
        })}
        <g transform={`rotate(${ang} 280 290)`}>
          <line x1="280" y1="290" x2="280" y2="96" stroke={C.cream} strokeWidth="9" strokeLinecap="round" />
        </g>
        <circle cx="280" cy="290" r="22" fill={C.cream} />
        <circle cx="280" cy="290" r="8" fill={DK} />
      </svg>
      <div style={{ textAlign: 'center', marginTop: 14, font: `800 84px ${F.display}`, color: DK, letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>
        {shown}<span style={{ font: `500 34px ${F.ui}`, color: 'rgba(26,11,12,.6)', marginLeft: 12, letterSpacing: 0 }}>{unit}</span>
      </div>
    </div>
  );
}

function Card({ c, i, at }) {
  const t = useT();
  const lt = t - at;
  if (lt < -0.1 || lt > 2.3) return null;
  const out = prog(lt, 1.85, 2.2, Ease.in);
  const aS = spring(lt - 0.62, SPR.bouncy);
  const line = prog(lt, 0.95, 1.35, Ease.out);
  const idxS = spring(lt, SPR.soft);
  return (
    <Abs style={{ transform: `translateY(${-out * 160}px)`, opacity: 1 - out, filter: out > 0 ? `blur(${out * 8}px)` : 'none' }}>
      <div style={{
        position: 'absolute', right: 120, top: 40, font: `900 420px ${F.display}`, letterSpacing: '-0.06em', lineHeight: 1,
        color: 'transparent', WebkitTextStroke: '3px rgba(255,241,236,.35)', transform: `translateX(${(1 - idxS) * 120}px)`, opacity: clamp(idxS),
      }}>0{i + 1}</div>
      <div style={{ position: 'absolute', left: 190, top: 300, width: 1000 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, opacity: prog(lt, 0, 0.3), transform: `translateX(${(1 - prog(lt, 0, 0.4)) * -30}px)` }}>
          <div style={{ width: 12, height: 12, borderRadius: 9, background: DK }} />
          <div style={{ font: `700 24px ${F.ui}`, letterSpacing: '0.24em', color: DK, textTransform: 'uppercase' }}>{c.tag}</div>
        </div>
        <Rise text={c.q} at={0.04} stagger={0.05} dur={0.6} style={{ font: `800 104px ${F.display}`, color: DK, letterSpacing: '-0.035em', lineHeight: 1.04, marginTop: 26 }} />
        <div style={{ position: 'relative', marginTop: 58, marginLeft: 40, display: 'inline-block', transform: `translateY(${(1 - aS) * 50}px) rotate(${-4 + (1 - aS) * 8}deg) scale(${0.7 + 0.3 * aS})`, opacity: clamp(aS * 2), transformOrigin: '0% 100%' }}>
          <div style={{ font: `italic 600 104px ${F.italic}`, color: C.cream, textShadow: '0 10px 40px rgba(120,0,30,.35)', letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>{c.a}</div>
          <svg width="100%" height="40" viewBox="0 0 600 40" preserveAspectRatio="none" style={{ position: 'absolute', left: 0, bottom: -18, width: '100%' }}>
            <path d="M5 24 C 80 8, 160 34, 240 20 S 400 8, 470 22 S 560 30, 595 14" fill="none" stroke={C.cream} strokeWidth="6" strokeLinecap="round" pathLength="1" strokeDasharray={`${line} 1`} opacity=".55" />
          </svg>
        </div>
      </div>
      <Gauge seed={i * 13 + 5} lo={c.lo} hi={c.hi} unit={c.unit} t={t} enter={lt - 0.15} />
    </Abs>
  );
}

export function Questions() {
  const t = useT();
  const wipe = prog(t, 0, 0.55, Ease.inOut);
  return (
    <Abs style={{ clipPath: `circle(${wipe * 1200}px at 50% 50%)` }}>
      <EmberBg />
      {CARDS.map((c, i) => <Card key={i} c={c} i={i} at={0.5 + i * 2} />)}
    </Abs>
  );
}
