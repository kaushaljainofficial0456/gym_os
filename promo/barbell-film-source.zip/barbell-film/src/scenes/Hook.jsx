import React from 'react';
import { useT, Seq, interp, prog, Ease, spring, SPR, clamp, fmt, wobble } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Dust, gradText, GRAD } from '../lib/ui.jsx';

const serif = { font: `400 96px ${F.serif}`, color: C.ink, letterSpacing: '-0.02em' };
const it = { fontFamily: F.italic, fontStyle: 'italic', fontWeight: 600, letterSpacing: '-0.01em', ...gradText, paddingRight: '0.08em' };

function Week() {
  const t = useT();
  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  return (
    <div style={{ display: 'flex', gap: 34, justifyContent: 'center', marginTop: 70 }}>
      {days.map((d, i) => {
        const appear = spring(t - 0.35 - i * 0.04, SPR.snappy);
        const on = i < 5;
        const fill = on ? spring(t - (0.75 + i * 0.25), SPR.pop) : 0;
        const out = prog(t, 1.85 + i * 0.02, 2.15 + i * 0.02, Ease.in);
        return (
          <div key={i} style={{ textAlign: 'center', opacity: clamp(appear) * (1 - out), transform: `translateY(${(1 - appear) * 30 + out * -40}px)` }}>
            <div style={{
              width: 58, height: 58, borderRadius: 999, position: 'relative',
              border: `2px solid ${on ? 'rgba(255,120,90,.55)' : 'rgba(255,234,229,.16)'}`,
            }}>
              <div style={{
                position: 'absolute', inset: -2, borderRadius: 999, background: GRAD,
                transform: `scale(${fill})`, boxShadow: `0 0 ${30 * fill}px rgba(255,80,70,${0.6 * fill})`,
              }} />
            </div>
            <div style={{ marginTop: 16, font: `600 18px ${F.ui}`, letterSpacing: '0.2em', color: on ? C.mute : C.faint }}>{d}</div>
          </div>
        );
      })}
    </div>
  );
}

function Lifted() {
  const t = useT();
  const v = 12480 * prog(t, 0.35, 1.45, Ease.out);
  const land = spring(t - 1.45, SPR.pop);
  const out = prog(t, 1.85, 2.15, Ease.in);
  const inP = spring(t - 0.05, SPR.snappy);
  return (
    <Abs style={{ display: 'grid', placeItems: 'center' }}>
      <div style={{ textAlign: 'center', transform: `translateY(${-out * 80}px)`, opacity: 1 - out, filter: out > 0 ? `blur(${out * 10}px)` : 'none' }}>
        <Rise text="Lifted" at={0} style={{ ...serif, justifyContent: 'center' }} align="center" />
        <div style={{
          font: `900 230px ${F.display}`, color: C.ink, letterSpacing: '-0.045em', lineHeight: 1, marginTop: 6,
          fontVariantNumeric: 'tabular-nums', opacity: clamp(inP * 1.5), transform: `scale(${0.9 + 0.1 * inP + land * 0.0})`,
        }}>
          {fmt(Math.round(v / 10) * 10)}<span style={{ font: `500 92px ${F.serif}`, color: C.mute, marginLeft: 22, letterSpacing: 0 }}>kg</span>
        </div>
        <div style={{ height: 6, width: 560, margin: '30px auto 0', borderRadius: 9, background: 'rgba(255,223,221,.10)', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${prog(t, 0.35, 1.45, Ease.out) * 100}%`, background: GRAD, boxShadow: '0 0 18px rgba(255,80,70,.7)' }} />
        </div>
      </div>
    </Abs>
  );
}

function Ate() {
  const t = useT();
  const s = spring(t - 0.6, SPR.bouncy);
  const out = prog(t, 1.85, 2.15, Ease.in);
  const wob = wobble(t, 4, 0.9) * 3;
  return (
    <Abs style={{ display: 'grid', placeItems: 'center', opacity: 1 - out, filter: out > 0 ? `blur(${out * 10}px)` : 'none' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 36, transform: `translateY(${-out * 80}px)` }}>
        <Rise text="Ate…" at={0.05} style={{ ...serif, fontSize: 120 }} />
        <div style={{
          font: `italic 600 190px ${F.italic}`, letterSpacing: '-0.02em', ...gradText, padding: '0 0.1em',
          transform: `translateY(${(1 - s) * 80}px) rotate(${-7 + wob + (1 - s) * 14}deg) scale(${0.6 + 0.4 * s})`, opacity: clamp(s * 2),
          transformOrigin: '20% 80%',
        }}>something.</div>
      </div>
    </Abs>
  );
}

function DidItWork() {
  const t = useT();
  const shrink = prog(t, 1.05, 1.5, Ease.in);
  return (
    <Abs style={{ display: 'grid', placeItems: 'center' }}>
      <div style={{ transform: `scale(${1 - shrink * 0.3}) translateY(${-shrink * 160}px)`, opacity: 1 - shrink, filter: shrink > 0 ? `blur(${shrink * 12}px)` : 'none' }}>
        <Rise text="But did any of it work?" at={0.05} stagger={0.07}
          spans={[{ w: 'But' }, { w: 'did' }, { w: 'any' }, { w: 'of' }, { w: 'it' }, { w: 'work?', style: it }]}
          style={{ ...serif, fontSize: 118, justifyContent: 'center' }} align="center" />
      </div>
    </Abs>
  );
}

export function Hook() {
  const t = useT();
  const zoom = interp(t, [0, 8], [1.0, 1.06], Ease.inOut);
  const fadeIn = prog(t, 0, 0.6, Ease.out);
  return (
    <Abs>
      <DarkBg glow={prog(t, 0, 1.5)} />
      <Dust opacity={prog(t, 0, 2)} />
      <Abs style={{ transform: `scale(${zoom})`, opacity: fadeIn }}>
        <Seq from={0} dur={2.2}>
          <Abs style={{ display: 'grid', placeItems: 'center' }}>
            <div style={{ transform: 'translateY(-30px)' }}>
              <Rise text="" at={0.15} out={1.85} stagger={0.07} align="center" style={{ ...serif, justifyContent: 'center' }}
                spans={[{ w: 'You' }, { w: 'trained' }, { w: '5', style: it }, { w: 'days', style: it }, { w: 'this' }, { w: 'week.' }]} />
              <Week />
            </div>
          </Abs>
        </Seq>
        <Seq from={2.0} dur={2.2}><Lifted /></Seq>
        <Seq from={4.0} dur={2.2}><Ate /></Seq>
        <Seq from={6.0} dur={2.0}><DidItWork /></Seq>
      </Abs>
    </Abs>
  );
}
