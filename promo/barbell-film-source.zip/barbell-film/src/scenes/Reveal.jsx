import React from 'react';
import { useT, interp, prog, Ease, clamp, spring, SPR, shake, wobble } from '../lib/anim.js';
import { Abs, C, F, Rise, DarkBg, Flash } from '../lib/ui.jsx';
import { ThreeStage } from '../lib/ThreeStage.jsx';
import { makeBadge3D, makeWordmark3D, materials, heroLights } from '../lib/objects.js';

/**
 * The brand reveal. variant 'reveal' assembles the badge piece by piece
 * (ring sweeps, bar extends, plates slide on); variant 'end' spins the
 * finished badge in for the end card.
 */
function makeSetup(variant) {
  return ({ scene, camera }) => {
    const m = materials();
    const badge = makeBadge3D({ size: 3.1, mats: m, ringMat: m.chrome, barMat: m.chrome, plateMat: m.coral });
    scene.add(badge.group);
    const word = makeWordmark3D({ height: 0.6, depth: 0.16, bevel: 0.018, material: m.pearl });
    scene.add(word.group);
    heroLights(scene, { intensity: 1.0, rimA: 0xff8a6a, rimB: 0xa38bff });
    scene.environmentIntensity = 1.0;
    camera.position.set(0, 0, 10);
    return { badge, word, variant, arc: -1 };
  };
}

function update({ scene, camera, user }, t) {
  const { badge, word, variant } = user;
  const isReveal = variant === 'reveal';
  scene.environmentRotation.y = 0.6 + t * 0.35;
  scene.environmentRotation.x = Math.sin(t * 0.4) * 0.2;

  // ── badge assembly
  let arc, barS, bigP, smallP, rotY, rotX, lift, sc;
  if (isReveal) {
    arc = prog(t, 0.08, 0.75, Ease.inOut) * Math.PI * 2;
    barS = prog(t, 0.35, 0.8, Ease.out);
    bigP = spring(t - 0.72, SPR.snappy);
    smallP = spring(t - 0.9, SPR.snappy);
    rotY = interp(t, [0, 2.2], [-1.05, 0], Ease.inOut) + wobble(t, 3, 0.15) * 0.04;
    rotX = interp(t, [0, 2.2], [0.42, 0], Ease.inOut);
    lift = prog(t, 2.25, 2.85, Ease.inOut);
    sc = interp(t, [0, 0.6, 2.25, 2.85], [0.82, 1, 1, 0.6], Ease.inOut);
  } else {
    arc = Math.PI * 2; barS = 1; bigP = 1; smallP = 1;
    const sp = spring(t - 0.05, { stiffness: 60, damping: 13, mass: 1 });
    rotY = (1 - sp) * Math.PI * 2.0 + wobble(t, 9, 0.12) * 0.05;
    rotX = (1 - sp) * 0.3;
    lift = prog(t, 0.9, 1.5, Ease.inOut);
    sc = interp(t, [0, 0.5, 0.9, 1.5], [0.4, 1, 1, 0.6], Ease.inOut);
  }
  if (Math.abs(arc - user.arc) > 1e-4) { badge.setRingArc(arc); user.arc = arc; }
  badge.ring.visible = arc > 0.01;
  badge.barPivot.scale.set(Math.max(0.001, barS), 1, 1);
  badge.barPivot.visible = barS > 0.001;
  badge.plates.forEach((p) => {
    const k = p.big ? bigP : smallP;
    p.pivot.position.x = p.home + p.side * (1 - k) * 4.2;
    p.pivot.rotation.x = (1 - k) * 3 * p.side;
    p.pivot.visible = k > 0.002;
  });
  badge.group.rotation.set(rotX, rotY, 0);
  badge.group.scale.setScalar(sc);
  badge.group.position.y = lift * 1.06;

  // ── wordmark opens from the centre letter out
  const wStart = isReveal ? 2.45 : 1.15;
  word.letters.forEach((L) => {
    const d = t - (wStart + Math.abs(L.i - 3) * 0.075);
    const k = spring(d, SPR.snappy);
    L.pivot.position.set(L.home.x, L.home.y - 0.7 - (1 - k) * 0.25, 0);
    L.pivot.scale.set(1, Math.max(0.001, k), 1);
    L.pivot.rotation.x = (1 - k) * -1.2;
    L.pivot.visible = d > 0;
  });
  word.group.rotation.y = wobble(t, 21, 0.12) * 0.03;

  camera.position.set(Math.sin(t * 0.35) * 0.25, Math.sin(t * 0.27) * 0.12, 10);
  camera.lookAt(0, 0.1, 0);
}

const setupReveal = makeSetup('reveal');
const setupEnd = makeSetup('end');

export function Reveal({ variant = 'reveal' }) {
  const t = useT();
  const isReveal = variant === 'reveal';
  const sh = shake(t, isReveal ? [{ t: 0.02, s: 1.2 }, { t: 0.74, s: 0.35 }, { t: 0.92, s: 0.3 }] : [{ t: 0.05, s: 0.8 }], 16, 6);
  const subAt = isReveal ? 3.15 : 1.9;
  const exit = isReveal ? prog(t, 5.55, 6.0, Ease.in) : prog(t, 5.0, 6.0, Ease.inOut);
  const burst = prog(t, 0, 1.1, Ease.out);
  return (
    <Abs>
      <DarkBg glow={0.8} />
      {/* light burst behind the badge */}
      <Abs style={{ display: 'grid', placeItems: 'center', opacity: (1 - burst) * (isReveal ? 1 : 0.6) }}>
        <div style={{ width: 200 + burst * 1800, height: 200 + burst * 1800, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,140,100,.6), rgba(255,46,99,.0) 60%)' }} />
      </Abs>
      {/* soft halo that settles behind the mark */}
      <Abs style={{
        background: `radial-gradient(520px 520px at 50% ${interp(t, isReveal ? [2.25, 2.85] : [0.9, 1.5], [50, 30], Ease.inOut)}%, rgba(255,90,60,.20), transparent 70%)`,
      }} />
      <Abs style={{
        transform: `translate(${sh.x}px, ${sh.y}px) rotate(${sh.r}deg) scale(${1 + (isReveal ? exit * 0.35 : 0)})`,
        opacity: isReveal ? 1 - exit : 1,
        filter: exit > 0.01 && isReveal ? `blur(${exit * 14}px)` : 'none',
      }}>
        <ThreeStage setup={isReveal ? setupReveal : setupEnd} update={update} fov={32} exposure={1.1} />
        <Abs style={{ top: 796 }}>
          {isReveal ? (
            <Rise text="The operating system for your gym." at={subAt} stagger={0.05} align="center"
              style={{ font: `400 46px ${F.serif}`, color: C.mute, justifyContent: 'center' }} />
          ) : (
            <Rise text="" at={subAt} stagger={0.09} align="center"
              spans={[{ w: 'Stop' }, { w: 'guessing.', style: { fontFamily: F.italic, fontStyle: 'italic', color: C.ink } }]}
              style={{ font: `400 60px ${F.serif}`, color: C.mute, justifyContent: 'center' }} />
          )}
        </Abs>
        <Abs style={{ top: isReveal ? 878 : 892, opacity: prog(t, subAt + 0.5, subAt + 1.1) }}>
          <div style={{ textAlign: 'center', font: `600 19px ${F.ui}`, letterSpacing: '0.42em', color: C.faint, textTransform: 'uppercase' }}>
            {isReveal ? 'Members  ·  Coaches  ·  Gym owners' : 'Train smarter  ·  Coach better  ·  Prove progress'}
          </div>
        </Abs>
      </Abs>
      {isReveal && <Flash at={0} dur={0.28} color="#fff" max={0.85} />}
      {!isReveal && <Abs style={{ background: '#000', opacity: prog(t, 5.3, 6.0, Ease.inOut) }} />}
    </Abs>
  );
}
