import React from 'react';
import { useT, Seq } from './lib/anim.js';
import { Abs, Grain, Vignette } from './lib/ui.jsx';
import { Hook } from './scenes/Hook.jsx';
import { Guessing } from './scenes/Guessing.jsx';
import { Questions } from './scenes/Questions.jsx';
import { Blindspot } from './scenes/Blindspot.jsx';
import { Chaos } from './scenes/Chaos.jsx';
import { Reveal } from './scenes/Reveal.jsx';
import { Member } from './scenes/Member.jsx';
import { Coach } from './scenes/Coach.jsx';
import { Owner } from './scenes/Owner.jsx';
import { Montage } from './scenes/Montage.jsx';
import { Tagline } from './scenes/Tagline.jsx';

export const DURATION = 64;

export function Video() {
  return (
    <Abs style={{ background: '#000', overflow: 'hidden' }}>
      <Seq from={0} dur={8}><Hook /></Seq>
      <Seq from={7.3} dur={4.75}><Guessing /></Seq>
      <Seq from={11.45} dur={6.6}><Questions /></Seq>
      <Seq from={17.6} dur={4.4}><Blindspot /></Seq>
      <Seq from={22} dur={2.02}><Chaos /></Seq>
      <Seq from={24} dur={6}><Reveal variant="reveal" /></Seq>
      <Seq from={30} dur={12}><Member /></Seq>
      <Seq from={42} dur={4}><Coach /></Seq>
      <Seq from={46} dur={4}><Owner /></Seq>
      <Seq from={50} dur={4}><Montage /></Seq>
      <Seq from={54} dur={4}><Tagline /></Seq>
      <Seq from={58} dur={6}><Reveal variant="end" /></Seq>
      <Vignette strength={0.5} />
    </Abs>
  );
}
