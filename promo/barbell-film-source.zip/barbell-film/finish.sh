#!/usr/bin/env bash
# Final encode: add film grain (luma only), mux the score, loudness-normalise
# to -14 LUFS (web/social standard), H.264 High + AAC, faststart.
set -euo pipefail
cd "$(dirname "$0")"
IN=${1:-out/video_60.mp4}
OUT=${2:-out/Barbell_Pitch_Film_1080p60.mp4}
ffmpeg -y -v error -i "$IN" -i audio/score.wav \
  -filter_complex "[0:v]noise=c0s=5:c0f=t+u,format=yuv420p[v];[1:a]loudnorm=I=-14:TP=-1.2:LRA=11,aresample=48000[a]" \
  -map "[v]" -map "[a]" -c:v libx264 -preset slow -crf 17 -profile:v high -tune film \
  -c:a aac -b:a 256k -movflags +faststart -shortest "$OUT"
ffprobe -v error -show_entries format=duration,size:stream=codec_name,width,height,r_frame_rate -of default=nw=1 "$OUT"
