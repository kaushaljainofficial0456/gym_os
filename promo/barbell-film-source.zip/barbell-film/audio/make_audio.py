"""
Original score + sound design for the Barbell film, synthesised from scratch.
120 BPM (one beat = 0.5 s, one bar = 2 s) so every cut in the edit lands on
the grid. Key: F minor, lifting to Ab major at the end.

Writes: score.wav (full mix), music.wav, sfx.wav (stems)
"""
import numpy as np
from scipy import signal
import wave, sys, os

SR = 48000
DUR = 64.0
N = int(SR * DUR)
rng = np.random.default_rng(7)
BPM = 120
BEAT = 60 / BPM
BAR = 4 * BEAT

def tt(d):
    return np.arange(int(d * SR)) / SR

def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)

class Bus:
    def __init__(self):
        self.L = np.zeros(N + SR * 4)
        self.R = np.zeros(N + SR * 4)
    def add(self, x, at, gain=1.0, pan=0.0):
        """x mono or (2, n). pan -1..1 (equal power)."""
        i = int(at * SR)
        if i < 0:
            x = x[..., -i:] if x.ndim == 2 else x[-i:]
            i = 0
        if x.ndim == 1:
            a = (pan + 1) * np.pi / 4
            l, r = x * np.cos(a) * gain, x * np.sin(a) * gain
        else:
            l, r = x[0] * gain, x[1] * gain
        n = min(len(l), len(self.L) - i)
        if n <= 0:
            return
        self.L[i:i + n] += l[:n]
        self.R[i:i + n] += r[:n]
    def st(self):
        return np.stack([self.L[:N], self.R[:N]])

def lp(x, f, order=2):
    sos = signal.butter(order, min(f, SR * 0.45), 'low', fs=SR, output='sos')
    return signal.sosfilt(sos, x, axis=-1)
def hp(x, f, order=2):
    sos = signal.butter(order, f, 'high', fs=SR, output='sos')
    return signal.sosfilt(sos, x, axis=-1)
def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, min(hi, SR * 0.45)], 'band', fs=SR, output='sos')
    return signal.sosfilt(sos, x, axis=-1)

def env_adsr(n, a, d, s, r, sus_len):
    A, D, R = int(a * SR), int(d * SR), int(r * SR)
    S = max(0, int(sus_len * SR) - A - D)
    e = np.concatenate([np.linspace(0, 1, max(A, 1)), np.linspace(1, s, max(D, 1)), np.full(S, s), np.linspace(s, 0, max(R, 1))])
    if len(e) < n:
        e = np.pad(e, (0, n - len(e)))
    return e[:n]

def saw(f, t, phase=0.0):
    return 2 * ((f * t + phase) % 1.0) - 1

def softclip(x, drive=1.0):
    return np.tanh(x * drive) / np.tanh(drive)

def make_ir(dur=2.4, pre=0.02, damp=6000, decay=3.2, seed=3):
    r = np.random.default_rng(seed)
    n = int(dur * SR)
    t = np.arange(n) / SR
    e = np.exp(-t * decay)
    ir = np.stack([r.standard_normal(n) * e, r.standard_normal(n) * e])
    ir = lp(ir, damp)
    ir = np.concatenate([np.zeros((2, int(pre * SR))), ir], axis=1)
    return ir / np.sqrt((ir ** 2).sum() / 2)

IR_HALL = make_ir(2.8, 0.03, 5200, 2.4)
IR_ROOM = make_ir(0.9, 0.01, 7000, 7.0, 5)

def reverb(stereo, ir, wet=0.3):
    out = np.zeros_like(stereo)
    for c in range(2):
        out[c] = signal.fftconvolve(stereo[c], ir[c])[:stereo.shape[1]]
    return out * wet

# ─────────────────────────── instruments ───────────────────────────
def kick(punch=1.0, length=0.5):
    t = tt(length)
    f = 46 + 120 * np.exp(-t * 30) + 40 * np.exp(-t * 160)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t * 6.5)
    click = hp(rng.standard_normal(len(t)), 2500) * np.exp(-t * 400) * 0.35
    return softclip((body + click) * punch, 1.6) * 0.6

def clap():
    t = tt(0.4)
    n = rng.standard_normal(len(t))
    e = np.zeros(len(t))
    for k, o in enumerate([0, 0.011, 0.022, 0.034]):
        i = int(o * SR)
        e[i:] += np.exp(-(t[: len(t) - i]) * (90 if k < 3 else 18)) * (0.8 if k < 3 else 1.0)
    return bp(n * e, 900, 3200) * 0.9

def snare(tone=200):
    t = tt(0.25)
    n = bp(rng.standard_normal(len(t)), 1500, 9000) * np.exp(-t * 22)
    b = np.sin(2 * np.pi * tone * t) * np.exp(-t * 35) * 0.6
    return (n + b) * 0.7

def hat(open_=False):
    t = tt(0.3 if open_ else 0.06)
    n = hp(rng.standard_normal(len(t)), 7500, 4) * np.exp(-t * (14 if open_ else 80))
    return n * (0.2 if open_ else 0.17)

def sub(m, dur):
    t = tt(dur)
    f = midi(m)
    x = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)
    e = env_adsr(len(t), 0.005, 0.1, 0.85, 0.06, dur - 0.06)
    return softclip(x * e, 1.3) * 0.42

def pluck_bass(m, dur=0.22):
    t = tt(dur + 0.1)
    f = midi(m)
    x = saw(f, t) + saw(f * 1.006, t, 0.3)
    e = np.exp(-t * 9)
    y = lp(x * e, 900)
    return y * 0.35

def supersaw(m, dur, voices=7, detune=0.18, seed=0, cutoff=2600, attack=0.25, release=0.6):
    t = tt(dur + release)
    r = np.random.default_rng(seed + m)
    out = np.zeros((2, len(t)))
    f0 = midi(m)
    for v in range(voices):
        d = (v - (voices - 1) / 2) / ((voices - 1) / 2) * detune
        f = f0 * 2 ** (d / 12)
        x = saw(f, t, r.random())
        pan = (v / (voices - 1)) * 2 - 1
        a = (pan * 0.8 + 1) * np.pi / 4
        out[0] += x * np.cos(a)
        out[1] += x * np.sin(a)
    e = env_adsr(len(t), attack, 0.3, 0.8, release, dur)
    out = lp(out * e, cutoff) / voices
    return out

def bell(m, dur=1.2, ratio=3.5, idx=2.2, decay=3.5):
    t = tt(dur)
    f = midi(m) if m < 200 else m
    mod = np.sin(2 * np.pi * f * ratio * t) * idx * np.exp(-t * decay * 1.6)
    return np.sin(2 * np.pi * f * t + mod) * np.exp(-t * decay)

def keys(m, dur=1.0):
    """soft electric-piano-ish tone"""
    t = tt(dur + 0.5)
    f = midi(m)
    x = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t) * np.exp(-t * 4) + 0.12 * np.sin(6 * np.pi * f * t) * np.exp(-t * 7)
    mod = np.sin(2 * np.pi * f * 14 * t) * 0.6 * np.exp(-t * 30)
    x += 0.15 * np.sin(2 * np.pi * f * t + mod)
    return x * np.exp(-t * 2.2) * env_adsr(len(t), 0.004, 0.05, 1, 0.3, dur) * 0.5

def lead(m, dur):
    t = tt(dur + 0.25)
    f = midi(m)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t) * np.clip(t * 4 - 0.4, 0, 1)
    ph = np.cumsum(f * vib) / SR
    x = 0.55 * (2 * (ph % 1) - 1) + 0.45 * np.sign(np.sin(2 * np.pi * ph * 1.002))
    e = env_adsr(len(t), 0.006, 0.12, 0.55, 0.18, dur)
    y = lp(x * e, 3200)
    y = y + 0.4 * lp(x * e * np.exp(-t * 18), 7000)
    return y * 0.33

# ─────────────────────────── sound effects ─────────────────────────
def whoosh(d=0.6, f0=300, f1=4000, up=True, peak=0.6):
    """noise swept through a bank of band-passes (crossfaded, so no zipper)"""
    t = tt(d)
    x = t / d
    lo, hi = (f0, f1) if up else (f1, f0)
    fc = lo * (hi / lo) ** x                      # instantaneous centre
    bands = np.geomspace(min(f0, f1) * 0.7, max(f0, f1) * 1.3, 9)
    out = np.zeros(len(t))
    wsum = np.zeros(len(t)) + 1e-9
    n = rng.standard_normal(len(t))
    for b in bands:
        y = bp(n, b / 1.45, b * 1.45)
        w = np.exp(-0.5 * (np.log(fc / b) / 0.35) ** 2)
        out += y * w
        wsum += w
    out /= np.sqrt(wsum)
    e = np.where(x < peak, (x / peak) ** 2, ((1 - x) / (1 - peak + 1e-9)) ** 1.5)
    st = np.stack([out * e * (1 - 0.6 * x), out * e * (0.4 + 0.6 * x)])
    return st * 1.1

def impact(size=1.0, d=2.5):
    t = tt(d)
    f = 30 + 70 * np.exp(-t * 7)
    ph = 2 * np.pi * np.cumsum(f) / SR
    boom = np.sin(ph) * np.exp(-t * (1.6 / size))
    crack = lp(rng.standard_normal(len(t)), 3500) * np.exp(-t * 14) * 0.6
    body = softclip(boom * 1.5 + crack, 1.5)
    return body * 0.9

def rev_cymbal(d=1.2):
    t = tt(d)
    n = hp(rng.standard_normal(len(t)), 4000) * (t / d) ** 3
    return np.stack([n, hp(rng.standard_normal(len(t)), 4000) * (t / d) ** 3]) * 0.5

def riser(d=1.5, f0=200, f1=2400):
    t = tt(d)
    f = f0 * (f1 / f0) ** (t / d)
    ph = np.cumsum(f) / SR
    tone = (2 * (ph % 1) - 1) + (2 * ((ph * 1.01) % 1) - 1)
    tone = lp(tone, 5000) * 0.15
    w = whoosh(d, 400, 9000, True, 0.97)[0] * 0.7
    e = (t / d) ** 2
    return (tone * e + w)

def pop(f=700, d=0.09, drop=0.5):
    t = tt(d)
    fr = f * (1 - drop * (t / d))
    return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 45) * 0.6

def tick(f=2400, d=0.03):
    t = tt(d)
    return (np.sin(2 * np.pi * f * t) * 0.6 + hp(rng.standard_normal(len(t)), 3000) * 0.4) * np.exp(-t * 220) * 0.5

def key_click():
    t = tt(0.05)
    n = bp(rng.standard_normal(len(t)), 1800 + rng.random() * 1500, 7000) * np.exp(-t * 160)
    b = np.sin(2 * np.pi * (140 + rng.random() * 60) * t) * np.exp(-t * 120) * 0.4
    return (n + b) * 0.45

def clank(f=330, d=1.6):
    t = tt(d)
    parts = [(1.0, 1.0, 3.0), (2.76, 0.6, 5), (5.40, 0.45, 7), (8.93, 0.3, 9), (13.3, 0.2, 13)]
    x = np.zeros(len(t))
    for r, a, dec in parts:
        x += a * np.sin(2 * np.pi * f * r * t + rng.random() * 6) * np.exp(-t * dec)
    hit = lp(rng.standard_normal(len(t)), 6000) * np.exp(-t * 60) * 0.8
    thud = np.sin(2 * np.pi * 70 * t) * np.exp(-t * 20) * 0.8
    return (x * 0.35 + hit + thud) * 0.6

def chime(notes, gap=0.07, d=1.6, ratio=3.01, idx=1.4):
    out = np.zeros(int((gap * len(notes) + d) * SR))
    for k, m in enumerate(notes):
        b = bell(m, d, ratio, idx, 3.0)
        i = int(k * gap * SR)
        out[i:i + len(b)] += b
    return out * 0.3

def boing(f0=520, f1=180, d=0.35):
    t = tt(d)
    f = f0 * (f1 / f0) ** (t / d) * (1 + 0.06 * np.sin(2 * np.pi * 22 * t))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7) * 0.5

def scribble(d=0.35):
    t = tt(d)
    n = bp(rng.standard_normal(len(t)), 2500, 8000)
    am = 0.5 + 0.5 * np.sin(2 * np.pi * 26 * t) ** 2
    return n * am * np.sin(np.pi * t / d) * 0.25

def dust(d=1.2):
    out = np.zeros(int(d * SR) + SR)
    for k in range(60):
        at = (k / 60) ** 0.8 * d
        f = 5200 - 3800 * (k / 60) + rng.random() * 600
        b = bell(f, 0.25, 2.0, 0.5, 20) * (1 - k / 70)
        i = int(at * SR)
        out[i:i + len(b)] += b * 0.08
    return out

def glitch(d=0.18):
    t = tt(d)
    n = rng.standard_normal(len(t))
    step = int(SR / 900)
    n = np.repeat(n[::step], step)[: len(t)]
    gate = (np.floor(t * 60) % 2)
    return lp(n * gate, 6000) * 0.35 * np.exp(-t * 6)

def ping2():
    a, b = bell(84, 0.6, 2.0, 0.6, 6), bell(88, 0.8, 2.0, 0.6, 5)
    out = np.zeros(int(1.0 * SR))
    out[: len(a)] += a
    i = int(0.11 * SR)
    out[i:i + len(b)] += b
    return out * 0.35

def mouse_click():
    t = tt(0.03)
    return hp(rng.standard_normal(len(t)), 2000) * np.exp(-t * 300) * 0.5 + np.sin(2 * np.pi * 3000 * t) * np.exp(-t * 400) * 0.3

# ─────────────────────────── arrangement ───────────────────────────
music = Bus()
drums = Bus()
sfx = Bus()
send_hall = Bus()   # reverb send for music
sfx_hall = Bus()

F2, Ab2, Bb2, C3, Db3, Eb3, F3 = 41, 44, 46, 48, 49, 51, 53
CH = {  # chord tones (pad voicing) and bass root (midi)
    'Fm': ([65, 68, 72, 77], 41), 'Db': ([65, 68, 73, 77], 37), 'Ab': ([63, 68, 72, 75], 44),
    'Eb': ([63, 67, 70, 75], 39), 'Dbmaj9': ([65, 68, 72, 75, 80], 37), 'AbM': ([63, 68, 72, 75, 80], 44),
}

def bar_t(b):
    return b * BAR

def pad_chord(name, at, bars=1, gain=0.22, cutoff=2600, attack=0.3, seed=0):
    tones, _ = CH[name]
    for k, m in enumerate(tones):
        x = supersaw(m - 12 if k == 0 else m, bars * BAR, seed=seed + k, cutoff=cutoff, attack=attack)
        music.add(x, at, gain * 1.7)
        send_hall.add(x, at, gain * 0.85)

def bass_bar(name, at, style='house', gain=1.0):
    root = CH[name][1]
    if style == 'house':
        for k in range(4):  # offbeat bass + sub on beats
            music.add(sub(root, BEAT * 0.9), at + k * BEAT, 0.55 * gain)
            music.add(pluck_bass(root + 12, 0.2), at + k * BEAT + BEAT / 2, 0.9 * gain)
    elif style == 'long':
        music.add(sub(root, BAR - 0.05), at, 0.6 * gain)
    elif style == 'half':
        music.add(sub(root, BEAT * 2.8), at, 0.6 * gain)
        music.add(sub(root, BEAT * 0.9), at + BEAT * 3, 0.5 * gain)

KICKS = []
def drums_bar(at, style='four', fill=False, gain=1.0):
    if style == 'four':
        for k in range(4):
            drums.add(kick(), at + k * BEAT, 0.95 * gain); KICKS.append(at + k * BEAT)
            drums.add(hat(True), at + k * BEAT + BEAT / 2, 0.55 * gain, 0.2)
            for s in range(4):
                if s != 2:
                    drums.add(hat(False), at + k * BEAT + s * BEAT / 4, (0.35 if s % 2 else 0.22) * gain, -0.25)
        for k in (1, 3):
            c = clap()
            drums.add(c, at + k * BEAT, 0.75 * gain)
            send_hall.add(np.stack([c, c]), at + k * BEAT, 0.25 * gain)
    elif style == 'half':
        drums.add(kick(1.2), at, 1.0 * gain); KICKS.append(at)
        drums.add(kick(), at + BEAT * 2.5, 0.8 * gain); KICKS.append(at + BEAT * 2.5)
        c = clap()
        drums.add(c, at + BEAT * 2, 0.85 * gain)
        send_hall.add(np.stack([c, c]), at + BEAT * 2, 0.4 * gain)
        for s in range(8):
            drums.add(hat(False), at + s * BEAT / 2, 0.28 * gain, -0.2)
    elif style == 'pulse':
        drums.add(kick(0.8), at, 0.6 * gain); KICKS.append(at)
        drums.add(kick(0.8), at + BEAT * 2, 0.5 * gain); KICKS.append(at + BEAT * 2)
    if fill:
        for s in range(8):
            drums.add(snare(220 + s * 10), at + BEAT * 2 + s * BEAT / 4, (0.25 + s * 0.06) * gain)

def lead_phrase(at, notes, gain=1.0):
    """notes: list of (beat_offset, midi, dur_beats)"""
    for b, m, d in notes:
        x = lead(m, d * BEAT)
        music.add(x, at + b * BEAT, 0.9 * gain, 0.1)
        send_hall.add(x, at + b * BEAT, 0.35 * gain)
        # ping-pong delay (dotted eighth)
        music.add(x, at + b * BEAT + BEAT * 0.75, 0.28 * gain, -0.7)
        music.add(x, at + b * BEAT + BEAT * 1.5, 0.14 * gain, 0.7)

# the hook melody, 4 bars, over Db – Ab – Eb – Fm
HOOK = [
    [(0, 72, 0.5), (0.75, 68, 0.25), (1, 72, 0.5), (1.5, 75, 1.0), (2.75, 72, 0.25), (3, 68, 0.75)],
    [(0, 75, 0.5), (0.75, 72, 0.25), (1, 75, 0.5), (1.5, 77, 1.0), (2.75, 75, 0.25), (3, 72, 0.75)],
    [(0, 70, 0.5), (0.75, 67, 0.25), (1, 70, 0.5), (1.5, 75, 1.0), (2.75, 70, 0.25), (3, 67, 0.75)],
    [(0, 72, 0.5), (0.5, 68, 0.5), (1, 65, 1.5), (3, 67, 0.5), (3.5, 68, 0.5)],
]
ARP = lambda tones: [tones[i % len(tones)] + (12 if (i // len(tones)) % 2 else 0) for i in range(16)]

def arp_bar(name, at, gain=0.18, octave=12):
    tones = CH[name][0]
    seq = ARP(tones)
    for k, m in enumerate(seq):
        b = bell(m + octave, 0.5, 2.0, 1.2, 7)
        music.add(b, at + k * BEAT / 4, gain * 1.5, (-0.5 if k % 2 else 0.5))
        send_hall.add(b, at + k * BEAT / 4, gain * 0.4)

# ── 0–8  intro: pad, ticks, swell
pad_chord('Fm', 0.0, 2, gain=0.13, cutoff=900, attack=1.6)
pad_chord('Db', 4.0, 2, gain=0.14, cutoff=1300, attack=0.8)
for b in range(4):
    drums_bar(bar_t(b), 'pulse', gain=0.55 if b < 3 else 0.7)
    music.add(sub(41 if b < 2 else 37, BAR * 0.95), bar_t(b), 0.28)
for k in range(16):  # soft keys motif, sparse
    if k % 3 == 0:
        m = [77, 72, 80, 75, 77, 73][k // 3 % 6]
        x = keys(m, 0.8)
        music.add(x, k * BEAT, 0.28, 0.3 if k % 2 else -0.3)
        send_hall.add(x, k * BEAT, 0.3)
music.add(riser(1.6, 180, 2600), 6.4, 0.7)
sfx.add(rev_cymbal(1.0), 7.0, 0.9)

# ── 8–18  drop A: four-on-the-floor, Fm Db Ab Eb Fm
progA = ['Fm', 'Db', 'Ab', 'Eb', 'Fm']
for i, c in enumerate(progA):
    at = 8 + i * BAR
    drums_bar(at, 'four', fill=(i == 4))
    bass_bar(c, at)
    pad_chord(c, at, 1, gain=0.16, cutoff=3200, attack=0.05, seed=i)
    arp_bar(c, at, gain=0.11)
for i in range(4):
    lead_phrase(10 + i * BAR, HOOK[(i + 3) % 4], gain=0.7)

# ── 18–22 breakdown: keys + pad, no drums (the coach doesn't know)
pad_chord('Db', 18, 1, gain=0.15, cutoff=1800, attack=0.4)
pad_chord('Eb', 20, 1, gain=0.15, cutoff=1500, attack=0.4)
for k, m in enumerate([77, 73, 72, 68, 75, 70, 67, 63]):
    x = keys(m, 0.9)
    music.add(x, 18 + k * BEAT, 0.42, 0.2 if k % 2 else -0.2)
    send_hall.add(x, 18 + k * BEAT, 0.5)
music.add(sub(37, BAR), 18, 0.35); music.add(sub(39, BAR), 20, 0.35)

# ── 22–24 build: snare roll + riser + hits on each word
for s in range(16):
    step = BEAT / 4 if s < 8 else BEAT / 8
    pass
roll_t = 22.0
for k in range(24):
    at = 22.0 + (k / 24) ** 0.85 * 1.85
    drums.add(snare(240 + k * 6), at, 0.18 + 0.022 * k)
for k, at in enumerate([22.0, 22.5, 23.0, 23.5]):
    drums.add(kick(1.1), at, 0.9); KICKS.append(at)
    sfx.add(glitch(), at + 0.02, 0.7, 0.3 * (1 if k % 2 else -1))
    sfx.add(impact(0.4, 0.6), at, 0.45)
music.add(riser(1.95, 260, 5200), 22.0, 0.9)
pad_chord('Eb', 22, 1, gain=0.12, cutoff=4000, attack=1.4)

# ── 24–30 reveal: half-time, wide, arps
for i, c in enumerate(['Fm', 'Db', 'Ab']):
    at = 24 + i * BAR
    drums_bar(at, 'half', gain=0.95)
    bass_bar(c, at, 'half')
    pad_chord(c, at, 1, gain=0.18, cutoff=4200, attack=0.02, seed=10 + i)
    arp_bar(c, at, gain=0.14)
music.add(riser(0.5, 500, 4000), 29.5, 0.5)

# ── 30–50 main groove: Db Ab Eb Fm, hook lead
progB = ['Db', 'Ab', 'Eb', 'Fm'] * 3
for i in range(10):
    c = progB[i]
    at = 30 + i * BAR
    drums_bar(at, 'four', fill=(i == 9), gain=0.92)
    bass_bar(c, at, gain=0.95)
    pad_chord(c, at, 1, gain=0.14, cutoff=3600, attack=0.03, seed=20 + i)
    if i in (2, 3, 6, 7, 8, 9):
        lead_phrase(at, HOOK[i % 4], gain=0.62)
    else:
        arp_bar(c, at, gain=0.1)

# ── 50–54 montage: peak energy
for i, c in enumerate(['Db', 'Eb']):
    at = 50 + i * BAR
    drums_bar(at, 'four', gain=1.0)
    bass_bar(c, at)
    pad_chord(c, at, 1, gain=0.17, cutoff=5000, attack=0.02, seed=40 + i)
    arp_bar(c, at, gain=0.13)
    lead_phrase(at, HOOK[i], gain=0.7)
for k in range(8):
    at = 50 + k * BEAT
    drums.add(snare(230), at, 0.32)
music.add(riser(0.95, 400, 6000), 53.0, 0.75)

# ── 54–58 tagline: three stabs, then lift to Ab major
for k, (name, at) in enumerate([('Db', 54.0), ('Eb', 55.0), ('Fm', 56.0)]):
    drums.add(kick(1.25), at, 1.0); KICKS.append(at)
    sfx.add(impact(0.7, 1.2), at, 0.55)
    for m in CH[name][0]:
        x = supersaw(m, 0.85, cutoff=5200, attack=0.005, release=0.5, seed=60 + k)
        music.add(x, at, 0.2)
        send_hall.add(x, at, 0.22)
    music.add(sub(CH[name][1], 0.9), at, 0.6)
pad_chord('AbM', 57.0, 0.5, gain=0.2, cutoff=6000, attack=0.05, seed=70)
music.add(sub(44, 1.0), 57.0, 0.55)
music.add(riser(0.95, 300, 7000), 57.05, 0.8)
sfx.add(rev_cymbal(0.9), 57.1, 0.8)

# ── 58–64 end: boom, wide Db(maj9) → Ab, chimes, long tail
drums.add(kick(1.4), 58.0, 1.0); KICKS.append(58.0)
pad_chord('Dbmaj9', 58.0, 1.2, gain=0.2, cutoff=5200, attack=0.02, seed=80)
pad_chord('AbM', 60.4, 1.8, gain=0.18, cutoff=4200, attack=0.6, seed=81)
music.add(sub(37, 2.4), 58.0, 0.55)
music.add(sub(44, 3.4), 60.4, 0.45)
for k, m in enumerate([80, 84, 87, 92, 87, 84]):
    b = bell(m, 2.0, 3.01, 1.0, 1.8)
    music.add(b, 59.15 + k * 0.12, 0.12, (-0.6 + k * 0.24))
    send_hall.add(b, 59.15 + k * 0.12, 0.2)

# ─────────────────────────── sound design cues ───────────────────────────
# hook
for k, at in enumerate([0.75, 1.0, 1.25, 1.5, 1.75]):
    sfx.add(pop([698, 784, 831, 932, 1047][k], 0.12, 0.25), at, 0.5, -0.3 + k * 0.15)
for at in (1.9, 3.9, 5.9):
    sfx.add(whoosh(0.45, 1200, 300, False, 0.3), at, 0.28)
v_prev = 0
for i in range(400):  # counter ticks follow the ease-out of the number
    tl = 2.35 + i * 0.01
    if tl > 3.45:
        break
    p = 1 - (1 - (tl - 2.35) / 1.1) ** 4
    v = int(p * 40)
    if v != v_prev:
        sfx.add(tick(2600 + v * 20, 0.02), tl, 0.22, 0.2)
        v_prev = v
sfx.add(chime([84, 91], 0.06, 1.2), 3.45, 0.55)
sfx.add(boing(), 4.6, 0.55, 0.2)

# GUESSING slam
sfx.add(impact(1.6, 3.0), 8.0, 1.0)
sfx.add(clank(180, 1.8), 8.0, 0.5)
sfx_hall.add(np.stack([impact(1.0, 1.5)] * 2), 8.0, 0.35)
for k in range(9):  # letters falling
    sfx.add(clank(260 + k * 37, 0.6), 11.15 + k * 0.045, 0.16, -0.8 + k * 0.2)
sfx.add(whoosh(0.6, 3000, 200, False, 0.2), 11.05, 0.45)
sfx.add(whoosh(0.55, 250, 5000, True, 0.85), 11.45, 0.55)

# questions (coral)
for k in range(3):
    at = 11.95 + k * 2.0
    sfx.add(pop(520, 0.1, 0.3), at, 0.45)
    sfx.add(boing(700 - k * 60, 300, 0.3), at + 0.62, 0.45, 0.3)
    sfx.add(scribble(0.4), at + 0.95, 0.6, 0.2)
    for j in range(int(1.7 / 0.09)):
        sfx.add(tick(1500 + (j % 3) * 300, 0.012), at + 0.15 + j * 0.09, 0.07, 0.5)
    if k < 2:
        sfx.add(whoosh(0.4, 400, 3000, True, 0.6), at + 1.85, 0.35)

# blindspot
sfx.add(whoosh(0.5, 3500, 250, False, 0.4), 17.55, 0.5)
for k in range(3):
    sfx.add(pop(600 + k * 80, 0.08, 0.3), 17.9 + k * 0.12, 0.32)
sfx.add(bell(52, 1.4, 1.5, 0.8, 2.5), 18.9, 0.25)
sfx.add(dust(1.1), 19.95, 0.9)
sfx.add(whoosh(1.0, 2500, 400, False, 0.25), 19.95, 0.3)
sfx.add(whoosh(0.45, 3000, 300, False, 0.5), 21.55, 0.3)

# chaos
for at in (22.2, 22.8, 23.3):
    sfx.add(whoosh(0.4, 500, 2500, True, 0.5), at, 0.25)
sfx.add(whoosh(0.3, 6000, 200, False, 0.9), 23.7, 0.6)

# reveal
sfx.add(impact(2.2, 3.5), 24.0, 1.0)
sfx_hall.add(np.stack([impact(1.2, 2)] * 2), 24.0, 0.4)
ring = chime([77, 80, 84, 89, 92], 0.13, 1.4)
sfx.add(ring, 24.08, 0.45)
sfx.add(whoosh(0.45, 600, 6000, True, 0.7), 24.35, 0.3)
sfx.add(clank(300, 1.6), 24.72, 0.75, -0.4)
sfx.add(clank(340, 1.6), 24.9, 0.7, 0.4)
for k in range(4):
    at = 26.45 + k * 0.075
    sfx.add(bell([84, 87, 91, 96][k], 1.0, 3.01, 0.8, 3), at, 0.12, (-1) ** k * 0.4)
sfx.add(whoosh(0.9, 300, 4000, True, 0.5), 26.3, 0.3)
sfx.add(whoosh(0.5, 300, 6000, True, 0.9), 29.5, 0.45)

# member
sfx.add(whoosh(0.6, 2000, 300, False, 0.3), 30.0, 0.45)
for k in range(25):
    sfx.add(key_click(), 30.7 + k * 0.05 + (rng.random() - 0.5) * 0.012, 0.42, 0.1)
sfx.add(pop(900, 0.1, 0.5), 32.0, 0.5)
sfx.add(whoosh(0.3, 800, 5000, True, 0.7), 31.95, 0.3)
for k in range(3):
    sfx.add(pop(784 + k * 120, 0.09, 0.2), 32.15 + k * 0.14, 0.4, 0.3)
sfx.add(whoosh(0.9, 300, 3000, True, 0.95), 32.35, 0.18)
sfx.add(chime([84, 88, 91], 0.07, 1.2), 33.25, 0.45)
sfx.add(pop(660, 0.1, 0.3), 32.6, 0.35, 0.6)
for at in (33.95, 37.95):
    sfx.add(whoosh(0.45, 400, 4500, True, 0.55), at, 0.4)
sfx.add(mouse_click(), 35.35, 0.6)
sfx.add(chime([72, 76, 79, 84, 88, 91], 0.06, 1.6), 35.55, 0.5)
sfx.add(pop(700, 0.1, 0.3), 35.7, 0.35, 0.6)
for k in range(16):
    sfx.add(tick(900 + k * 60, 0.025), 38.35 + k * 0.04, 0.12, -0.4 + k * 0.05)
sfx.add(pop(620, 0.1, 0.3), 39.0, 0.3)
sfx.add(pop(740, 0.1, 0.3), 39.25, 0.35, 0.6)
sfx.add(whoosh(0.45, 3000, 300, False, 0.5), 41.55, 0.4)

# coach
sfx.add(whoosh(0.6, 300, 3000, True, 0.6), 41.95, 0.4)
sfx.add(ping2(), 43.15, 0.6, 0.4)
sfx.add(whoosh(0.55, 200, 1800, True, 0.6), 43.0, 0.2)
sfx.add(mouse_click(), 44.4, 0.7, 0.3)
sfx.add(whoosh(0.35, 500, 4000, True, 0.6), 44.6, 0.3, 0.5)
sfx.add(whoosh(0.25, 1000, 6000, True, 0.8), 44.72, 0.35, 0.5)
sfx.add(pop(1047, 0.08, 0.2), 44.75, 0.3, 0.5)
sfx.add(ping2(), 45.35, 0.35, -0.2)
sfx.add(whoosh(0.4, 3000, 300, False, 0.5), 45.65, 0.35)

# owner
sfx.add(whoosh(0.5, 300, 3500, True, 0.6), 45.95, 0.4)
for k in range(6):
    sfx.add(pop(523 * 2 ** ([0, 3, 5, 7, 10, 12][k] / 12), 0.09, 0.15), 46.14 + k * 0.08, 0.3, -0.5 + k * 0.2)
for k in range(30):
    sfx.add(tick(2200, 0.012), 46.6 + k * 0.035, 0.06, 0.3)
for k in range(4):
    sfx.add(pop(880 + k * 110, 0.07, 0.2), 47.0 + k * 0.08, 0.22, 0.5)
sfx.add(whoosh(0.4, 3000, 300, False, 0.5), 49.65, 0.35)

# montage
for k in range(8):
    at = 50 + k * BEAT
    sfx.add(tick(1800 + k * 150, 0.03), at, 0.25)
    sfx.add(whoosh(0.25, 800, 5000, True, 0.3), at - 0.02, 0.2, (-1) ** k * 0.5)
sfx.add(whoosh(0.4, 6000, 200, False, 0.95), 53.6, 0.6)

# tagline + end
sfx.add(whoosh(0.4, 300, 4000, True, 0.3), 54.0, 0.35)
sfx.add(whoosh(0.45, 5000, 200, False, 0.95), 57.55, 0.55)
sfx.add(impact(2.4, 4.5), 58.0, 1.0)
sfx_hall.add(np.stack([impact(1.4, 2.5)] * 2), 58.0, 0.45)
sfx.add(whoosh(1.0, 300, 3000, True, 0.3), 58.05, 0.4)
sfx.add(chime([80, 84, 87, 92], 0.09, 2.0), 59.15, 0.25)

# ─────────────────────────── mix ───────────────────────────
print('mixing…')
t_all = np.arange(N) / SR
# sidechain from kicks
sc = np.ones(N)
for k in KICKS:
    i = int(k * SR)
    n = min(int(0.35 * SR), N - i)
    if n <= 0:
        continue
    x = np.arange(n) / SR
    sc[i:i + n] = np.minimum(sc[i:i + n], 1 - 0.55 * np.exp(-x * 9))

mus = music.st() * sc
mus += reverb(send_hall.st(), IR_HALL, 0.55) * sc
dr = drums.st()
dr += reverb(dr, IR_ROOM, 0.12)
fx = sfx.st()
fx += reverb(sfx_hall.st() + fx * 0.25, IR_HALL, 0.35)

# intro low-pass opening (0–8 s): blend filtered → open
mix_music = mus + dr
filtered = lp(mix_music, 700)
m = np.clip((t_all - 1.0) / 6.8, 0, 1) ** 2
m[t_all >= 8.0] = 1
# breakdown filter (18–22) and pre-reveal dip
bd = (t_all >= 18) & (t_all < 22)
m = np.where(bd, 0.35 + 0.65 * np.clip((t_all - 21.0) / 1.0, 0, 1), m)
filt2 = lp(mix_music, 1400)
mix_music = np.where(t_all < 8.0, filtered * (1 - m) + mix_music * m, np.where(bd, filt2 * (1 - m) + mix_music * m, mix_music))

# tiny silence before the reveal for impact (23.92–24.0)
gap = (t_all > 23.9) & (t_all < 24.0)
mix_music[:, gap] *= np.clip((24.0 - t_all[gap]) / 0.1, 0, 1) * 0.3

# master fade out
fade = np.clip((DUR - t_all) / 3.2, 0, 1) ** 1.3
fade_in = np.clip(t_all / 0.25, 0, 1)
music_st = mix_music * 0.9 * fade * fade_in
sfx_st = fx * 0.85 * np.clip((DUR - t_all) / 1.5, 0, 1)

def master(x):
    x = hp(x, 28)
    # gentle glue compression (envelope follower)
    level = np.sqrt(lp((x ** 2).mean(axis=0), 8, 1))
    gain = np.where(level > 0.25, (0.25 / np.maximum(level, 1e-9)) ** 0.35, 1.0)
    x = x * gain
    x = softclip(x * 1.15, 1.2)
    peak = np.abs(x).max()
    return x / peak * 0.93

full = master(music_st + sfx_st)
mus_only = music_st / max(1e-9, np.abs(music_st).max()) * 0.9
sfx_only = sfx_st / max(1e-9, np.abs(sfx_st).max()) * 0.9

def write(path, x):
    y = np.clip(x.T, -1, 1)
    pcm = (y * 32767).astype('<i2')
    with wave.open(path, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())

out = os.path.dirname(os.path.abspath(__file__))
write(os.path.join(out, 'score.wav'), full)
write(os.path.join(out, 'music.wav'), mus_only)
write(os.path.join(out, 'sfx.wav'), sfx_only)
print('done')
