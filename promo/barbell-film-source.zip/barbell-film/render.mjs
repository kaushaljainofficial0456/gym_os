// Frame-by-frame renderer: headless Chromium + ffmpeg.
// Usage:
//   node render.mjs stills 1,2.5,8 [--scale 0.5] [--fps 30]
//   node render.mjs video --fps 30 --from 0 --to 64 --workers 2 --out out/video.mp4 [--quality 92]
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const ROOT = path.resolve('public');
const args = process.argv.slice(2);
const mode = args[0];
const opt = (k, d) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : d; };
const FPS = Number(opt('fps', 30));

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.woff2': 'font/woff2', '.png': 'image/png', '.json': 'application/json', '.jpg': 'image/jpeg' };
function serve() {
  return new Promise((res) => {
    const srv = http.createServer((req, resp) => {
      const p = path.join(ROOT, decodeURIComponent(req.url.split('?')[0]));
      fs.readFile(p, (err, data) => {
        if (err) { resp.writeHead(404); resp.end(); return; }
        resp.writeHead(200, { 'content-type': MIME[path.extname(p)] || 'application/octet-stream' });
        resp.end(data);
      });
    });
    srv.listen(0, '127.0.0.1', () => res(srv));
  });
}

async function openPage(port, scale = 1) {
  const browser = await chromium.launch({
    args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--disable-gpu-compositing', '--disable-gpu-vsync', '--font-render-hinting=none', '--disable-lcd-text'],
  });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: scale });
  page.on('console', (m) => { if ((m.type() === 'error' || m.type() === 'warning') && !m.text().includes('deprecated')) console.log('[page]', m.type(), m.text()); });
  page.on('pageerror', (e) => console.log('[pageerror]', e.message));
  await page.goto(`http://127.0.0.1:${port}/index.html?fps=${FPS}`);
  await page.evaluate(() => window.__ready);
  return { browser, page };
}

async function stills() {
  const times = args[1].split(',').map(Number);
  const scale = Number(opt('scale', 0.5));
  const dir = opt('dir', 'out/stills');
  fs.mkdirSync(dir, { recursive: true });
  const srv = await serve();
  const { browser, page } = await openPage(srv.address().port, scale);
  for (const t of times) {
    const f = Math.round(t * FPS);
    const t0 = Date.now();
    await page.evaluate((fr) => window.__seek(fr), f);
    const file = path.join(dir, `t_${t.toFixed(2).padStart(6, '0')}.png`);
    await page.screenshot({ path: file });
    console.log(file, `${Date.now() - t0}ms`);
  }
  await browser.close();
  srv.close();
}

function encoder(out, quality) {
  const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-c:v', 'mjpeg', '-framerate', String(FPS), '-i', '-',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '12', '-pix_fmt', 'yuv420p', '-r', String(FPS), out], { stdio: ['pipe', 'inherit', 'inherit'] });
  return ff;
}

async function renderRange(port, from, to, out, quality, label) {
  const { browser, page } = await openPage(port, 1);
  const ff = encoder(out, quality);
  const done = new Promise((r) => ff.on('close', r));
  const t0 = Date.now();
  for (let f = from; f < to; f++) {
    await page.evaluate((fr) => window.__seek(fr), f);
    const buf = await page.screenshot({ type: 'jpeg', quality });
    if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
    if ((f - from) % 60 === 0) {
      const el = (Date.now() - t0) / 1000;
      console.log(`[${label}] frame ${f} (${f - from + 1}/${to - from}) ${el.toFixed(0)}s, ${((f - from + 1) / el).toFixed(2)} fps`);
    }
  }
  ff.stdin.end();
  await done;
  await browser.close();
}

async function video() {
  const from = Math.round(Number(opt('from', 0)) * FPS);
  const srv = await serve();
  const port = srv.address().port;
  let toS = opt('to', null);
  let to;
  if (toS === null) {
    const { browser, page } = await openPage(port, 1);
    to = await page.evaluate(() => window.__frames);
    await browser.close();
  } else to = Math.round(Number(toS) * FPS);
  const workers = Number(opt('workers', 2));
  const quality = Number(opt('quality', 93));
  const out = opt('out', 'out/video.mp4');
  fs.mkdirSync('out/seg', { recursive: true });
  const n = to - from;
  const chunk = Math.ceil(n / workers);
  const segs = [];
  const jobs = [];
  for (let i = 0; i < workers; i++) {
    const a = from + i * chunk, b = Math.min(to, a + chunk);
    if (a >= b) continue;
    const seg = path.resolve(`out/seg/seg_${i}.mp4`);
    segs.push(seg);
    jobs.push(renderRange(port, a, b, seg, quality, `w${i}`));
  }
  const t0 = Date.now();
  await Promise.all(jobs);
  fs.writeFileSync('out/seg/list.txt', segs.map((s) => `file '${s}'`).join('\n'));
  await new Promise((r) => spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', 'out/seg/list.txt', '-c', 'copy', out], { stdio: 'inherit' }).on('close', r));
  console.log(`done ${out} in ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  srv.close();
}

if (mode === 'stills') await stills();
else if (mode === 'video') await video();
else console.log('mode?');
