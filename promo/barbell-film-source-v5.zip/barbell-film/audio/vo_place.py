"""
Place an ElevenLabs continuous voiceover take onto the film's cues.

Inputs : words_<lang>.json  (forced-alignment word timestamps from ElevenLabs Scribe,
                             including the [pause] / [long pause] tags of the script)
         vo_<lang>_el/full.mp3 (the take)
         lines json (cues)
Output : vo_<lang>_el/placed.wav  (48 kHz mono voice track, 72 s, every line on its cue)

Steps
 1. split the take into the script's lines at the [pause] tags, snapping every cut to
    the quietest point near the tag (so no word gets clipped)
 2. tighten each line: trim the edges, shorten long internal silences
 3. choose for every line a start time (near its cue) and a tempo (1.00-1.30, pitch kept,
    rubberband) with a small dynamic programme that keeps lines from overlapping while
    staying as close to the cues and as close to natural speed as possible; headline lines
    that land on a scene change are pinned harder to their cue
"""
import json, os, sys, subprocess, tempfile
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vo_mix as V

SR = V.SR
HERE = os.path.dirname(os.path.abspath(__file__))
lang, lines_file = sys.argv[1], sys.argv[2]
MAXF = float(os.environ.get('MAXF', '1.30'))

lines = json.load(open(os.path.join(HERE, lines_file)))
words = json.load(open(os.path.join(HERE, f'words_{lang}.json')))
x = V.decode(os.path.join(HERE, f'vo_{lang}_el', 'full.mp3'))

# ---- 1. group words into lines at pause tags
groups, cur, i = [], [], 0
while i < len(words):
    t = words[i]['text']
    if t == '[pause]' or (t == '[long' and i + 1 < len(words) and words[i + 1]['text'] == 'pause]'):
        if cur: groups.append(cur); cur = []
        i += 2 if t == '[long' else 1
        continue
    if not (t.startswith('[') and t.endswith(']')):
        cur.append(words[i])
    i += 1
if cur: groups.append(cur)
assert len(groups) == len(lines), (len(groups), len(lines))

# energy envelope, 10 ms hop, 40 ms smoothing
hop = SR // 100
n = len(x) // hop
e = np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
e = np.convolve(e, np.ones(4) / 4, 'same')
quiet = np.percentile(e, 8) * 3 + 1e-5

def cut_between(a_end, b_start):
    lo, hi = min(a_end, b_start) - 0.25, max(a_end, b_start) + 0.25
    i0, i1 = max(0, int(lo * 100)), min(n - 1, int(hi * 100))
    seg = e[i0:i1 + 1]
    # longest quiet run, else the quietest frame
    q = seg < quiet
    best, bl, j = None, 0, 0
    while j < len(q):
        if q[j]:
            k = j
            while k < len(q) and q[k]: k += 1
            if k - j > bl: bl, best = k - j, (j + k) // 2
            j = k
        else: j += 1
    if best is None: best = int(np.argmin(seg))
    return (i0 + best) / 100

cuts = [max(0.0, groups[0][0]['start'] - 0.15)]
for k in range(len(groups) - 1):
    cuts.append(cut_between(groups[k][-1]['end'], groups[k + 1][0]['start']))
cuts.append(len(x) / SR)

def squeeze(c, max_gap=0.22, keep=0.16):
    """shorten internal silences longer than max_gap to keep seconds"""
    m = len(c) // hop
    if m < 3: return c
    ee = np.sqrt((c[: m * hop].reshape(m, hop) ** 2).mean(1) + 1e-12)
    th = max(quiet, ee.max() * 10 ** (-34 / 20))
    s = ee < th
    out, pos, j = [], 0, 0
    fade = int(0.006 * SR)
    while j < m:
        if s[j]:
            k = j
            while k < m and s[k]: k += 1
            if j > 0 and k < m and (k - j) / 100 > max_gap:
                a, b = j * hop, k * hop
                mid_keep = int(keep * SR) // 2
                out.append(c[pos:a + mid_keep])
                pos = b - mid_keep
            j = k
        else: j += 1
    out.append(c[pos:])
    # stitch with tiny crossfades
    y = out[0]
    for o in out[1:]:
        if len(y) > fade and len(o) > fade:
            r = np.linspace(0, 1, fade)
            y = np.concatenate([y[:-fade], y[-fade:] * (1 - r) + o[:fade] * r, o[fade:]])
        else:
            y = np.concatenate([y, o])
    return y

clips = []
for k in range(len(lines)):
    c = x[int(cuts[k] * SR): int(cuts[k + 1] * SR)]
    c = V.trim(c)
    c = squeeze(c, *( (float(os.environ.get('SQ_MAX','0.20')), float(os.environ.get('SQ_KEEP','0.14'))) if lang == 'kn' else (0.24, 0.17) ))
    clips.append(c)
dur = np.array([len(c) / SR for c in clips])
def _edge(c, a):
    w = c[:int(0.015*SR)] if a == 0 else c[-int(0.015*SR):]
    return 20*np.log10(np.sqrt((w**2).mean())+1e-9) - 20*np.log10(np.abs(c).max()+1e-9)
edges = [(_edge(c,0), _edge(c,1)) for c in clips]

# ---- 3. placement DP
FILM_END = 71.5
cue = np.array([l['t'] for l in lines])
hard_end = np.array([min(l.get('end', 99), FILM_END) for l in lines])
# headline lines that sit on a scene change / visual slam: pin harder
pin = np.ones(len(lines))
for k, l in enumerate(lines):
    if any(abs(l['t'] - s) < 0.3 for s in [8.0, 22.45, 26.25, 32.25, 36.2, 40.25, 44.2, 48.25, 52.2, 56.1, 60.0, 62.05, 63.05, 64.05, 67.15, 67.95]):
        pin[k] = 3.0
    if abs(l['t'] - 8.0) < 0.05:      # 'Guessing.' lands on the 3D slam
        pin[k] = 10.0
offs = np.round(np.arange(float(os.environ.get('OFF_LO','-0.40')), float(os.environ.get('OFF_HI','1.0'))+0.001, 0.05), 3)
tempos = np.round(np.arange(1.0, MAXF + 1e-6, 0.025), 3)
O, T = np.meshgrid(offs, tempos, indexing='ij')
O, T = O.ravel(), T.ravel()
GAP = float(os.environ.get('GAP', '0.07'))
INF = 1e9
K = len(lines)
cost = np.full((K, len(O)), INF)
back = np.zeros((K, len(O)), int)

def opt_cost(k):
    s = cue[k] + O
    en = s + dur[k] / T
    late = np.clip(O, 0, None); early = np.clip(-O, 0, None)
    c = pin[k] * (late ** 2 * 4 + early ** 2 * 6) + 30 * (T - 1) ** 2 + 4 * (T - 1)
    c = np.where(en > hard_end[k] + 1e-6, INF, c)
    c = np.where(s < 0.05, INF, c)
    return s, en, c

s0, e0, c0 = opt_cost(0)
cost[0] = c0
S, E = [s0], [e0]
for k in range(1, K):
    sk, ek, ck = opt_cost(k)
    S.append(sk); E.append(ek)
    prev_end = E[k - 1]
    ok = sk[:, None] >= prev_end[None, :] + GAP          # [cur, prev]
    tot = np.where(ok, cost[k - 1][None, :], INF)
    j = tot.argmin(1)
    cost[k] = ck + tot[np.arange(len(O)), j]
    back[k] = j
best = int(cost[-1].argmin())
if cost[-1][best] >= INF:
    raise SystemExit('no feasible placement; raise MAXF or loosen offsets')
choice = [0] * K
choice[-1] = best
for k in range(K - 1, 0, -1):
    choice[k - 1] = back[k][choice[k]]

def stretch(c, f):
    if abs(f - 1) < 1e-3: return c
    with tempfile.TemporaryDirectory() as d:
        a, b = os.path.join(d, 'a.f32'), os.path.join(d, 'b.f32')
        c.astype('<f4').tofile(a)
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'f32le', '-ar', str(SR), '-ac', '1', '-i', a,
                        '-af', f'rubberband=tempo={f:.4f}:transients=mixed:detector=soft', '-f', 'f32le', b], check=True)
        return np.fromfile(b, dtype='<f4').astype(np.float64)

voice = np.zeros(int(SR * 72.0))
fade = int(0.008 * SR)
print(f'{"line":>4} {"cue":>6} {"start":>6} {"off":>5} {"dur":>5} {"tempo":>5}  text')
for k in range(K):
    o, f = O[choice[k]], T[choice[k]]
    c = stretch(clips[k], f)
    if len(c) > 2 * fade:
        c[:fade] *= np.linspace(0, 1, fade); c[-fade:] *= np.linspace(1, 0, fade)
    st = int((cue[k] + o) * SR)
    voice[st: st + len(c)] += c[: len(voice) - st]
    print(f'{k:4d} {cue[k]:6.2f} {cue[k]+o:6.2f} {o:+5.2f} {dur[k]:5.2f} {f:5.3f}  {lines[k]["text"]}')
json.dump([{'k':k,'start':float(cue[k]+O[choice[k]]),'tempo':float(T[choice[k]]),'dur':float(dur[k]),
            'head_db':round(edges[k][0],1),'tail_db':round(edges[k][1],1)} for k in range(K)],
          open(os.path.join(HERE, f'vo_{lang}_el', 'placement.json'),'w'), indent=1)
out = os.path.join(HERE, f'vo_{lang}_el', 'placed.wav')
import wave
with wave.open(out, 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((np.clip(voice / (np.abs(voice).max() + 1e-9) * 0.95, -1, 1) * 32767).astype('<i2').tobytes())
print('wrote', out)
